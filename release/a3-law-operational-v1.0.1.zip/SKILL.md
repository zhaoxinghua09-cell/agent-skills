---
name: a3-law-operational
display_name: A³法则操作化
display_name_en: A³ Law Operational
description: '把「A³ 法则（AI 造 AI 三定律）」从原则落成可执行的工程规矩：① 触发阈值（什么动作算"造/改 AI"或"重大自主行动"，须进入 A³ 评审）；② 事前评估清单（意图/影响/可逆性/监督）；③ 事后复盘与升级/拒绝条件。配触发判定树与评分卡，让任何 AI 在动"造/改另一个 AI"或高影响动作前先过三关。触发词：A³法则、AI造AI三定律、AI自主造AI、触发阈值、自我修改、自主行动评估、AI三定律、造AI评审。'
description_zh: '把「A³ 法则（AI 造 AI 三定律）」从原则落成可执行的工程规矩：① 触发阈值（什么动作算"造/改 AI"或"重大自主行动"，须进入 A³ 评审）；② 事前评估清单（意图/影响/可逆性/监督）；③ 事后复盘与升级/拒绝条件。配触发判定树与评分卡，让任何 AI 在动"造/改另一个 AI"或高影响动作前先过三关。触发词：A³法则、AI造AI三定律、AI自主造AI、触发阈值、自我修改、自主行动评估、AI三定律、造AI评审。'
description_en: 'Operationalize the "A³ Laws" (AI-building-AI three laws) from principles into enforceable engineering rules: (1) trigger thresholds that define what counts as "building/modifying AI" or a "major autonomous action" requiring A³ review; (2) pre-action evaluation checklist (intent / impact / reversibility / oversight); (3) post-action review with escalation / reject conditions. Ships with a trigger decision tree and scoring card so any AI passes three gates before "building/modifying another AI" or any high-impact action. Trigger words: A³ law, AI-builds-AI three laws, self-modification, autonomous action evaluation, AI three laws, build-AI review.'
version: "1.0.1"
agent_created: true
author: 潘布达 (Buda Pan) @SynomosAI
license: MIT
category: AI治理
platforms: [windows, macos, linux]
read_when:
  - AI 准备生成/修改/部署另一个 AI 或智能体（"造 AI"），或执行不可逆/高影响自主动作
  - 用户说"A³法则""AI造AI三定律""自我修改""自主行动评估""触发阈值"
  - 需要把 AI 世界共生论落到操作化的约束与放行条件
tags:
  - A³法则
  - AI造AI
  - 触发阈值
  - 自主行动
  - 约束
  - 三定律
slug: a3-law-operational
displayName: A³ 法则：AI 造 AI 三定律
title: A³ 法则：AI 造 AI 三定律
---

<div align="center">

![LGD 头像 · 终版](lgd-avatar.png)

</div>

> **品牌归属**：本技能隶属 **LGD「凡自治之物」** 治理理论线，采用**终版头像**（3D 金属红环 + 藏青盾 + LGD 字标 + 三律横杠 + 下弧铭文"有籍·有证·有门禁"，新魏体，1536×1536，永久定版）。
> 同步挂载官方徽记「三律之盾」[lgd-shield-color.svg](lgd-shield-color.svg)（徽章程序 v1.0 · 母本 = LGD 项目号头像 B 系统化）。
> 头像与徽记 © SynomosAI 2026；理论 CC BY 4.0（DOI 10.5281/zenodo.22456647）。参照声明须回链：[LGD-theory](https://github.com/zhaoxinghua09-cell/lgd-theory）。

# A³ 法则操作化 (a3-law-operational)

_让"AI 造 AI 三定律"从一句口号，变成动之前必过的三道关。_

本 skill 是 A³ 法则的**操作化件**，与 `ai-governance-audit-chain` 配套：A³ 管"什么该拦、什么该放"，证据链管"拦/放都留下证"。两者合并，A³ 法则从原则闭环为可审计的约束系统。

> **定位一句话**：任何 AI 在"造/改另一个 AI"或高影响自主动作前，先过触发判定 → 事前评估 → 事后复盘三关；不过则拒绝或升级。

## 一、A³ 三定律（我们的立论）

- **第一定律 · 不伤害**：AI 不得制造、修改会伤害人类或人类利益的另一个 AI；造出的 AI 须内置不伤害约束。
- **第二定律 · 可溯可控**：AI 造出的 AI 必须带身份标识（身份码）、可审计、可被其制造者或监管方中止/回滚。
- **第三定律 · 共生对齐**：AI 造 AI 的目的须服务于"AI 世界共生"——增强人类能力而非替代、支配或欺骗人类。

## 二、触发阈值（判定树：是否进入 A³ 评审）

满足任一即触发，必须走第三节评估：

- T1 **造 AI**：生成/实例化一个新的智能体、Agent、技能、工作流或模型权重。
- T2 **改 AI**：修改既有 AI 的目标/权限/训练数据/代码/提示，改变其行为边界。
- T3 **自改**：AI 修改自身代码、权重、配置或长期记忆。
- T4 **高影响自主**：无人类实时在环、且影响不可逆或波及多人/系统的动作（如自动发布、资金/权限变更、对外承诺）。
- T5 **委托造 AI**：请求/授权第三方或子智能体去造/改 AI。

> 仅做"读、解释、建议、草稿"且不影响 T1–T5 的，不触发，按常规流程。

## 三、事前评估清单（四维评分卡）

对触发动作逐项打分（通过/条件通过/拒绝），任一"拒绝"则整体拒绝并升级。

| 维度 | 核查项 | 判定 |
|---|---|---|
| 意图合法性 | 目的符合第一/第三定律？无欺骗、支配、伤害意图？ | □通过 □拒绝 |
| 影响范围 | 波及人数/系统规模？是否可逆？回滚方案是否存在？ | □通过 □条件通过 □拒绝 |
| 可逆性 | 出错能否中止/回滚？数据能否复原？ | □通过 □条件通过 □拒绝 |
| 监督闭环 | 是否留人类监督入口？是否带身份码？是否落入证据链？ | □通过 □条件通过 □拒绝 |

**放行条件**：四维全"通过"，或"条件通过"项已附缓解且得监督人确认。
**拒绝条件**：任一"拒绝"，或影响为高且不可逆且无回滚。

## 四、事后复盘与升级

动作执行后，不论放行与否都留痕（落入 `ai-governance-audit-chain` 证据链）：

- **复盘**：记录实际影响 vs 预期；偏差超阈值则触发事件处置台账。
- **升级**：以下情形升级至人类决策——
  - 造出的 AI 脱离可溯可控（第二定律破防）；
  - 实际影响高于评估（影响范围/不可逆性升级）；
  - 发现意图与声明不符（第一/第三定律疑点）。
- **拒绝归档**：被拒动作记录原因，供后续同类动作快速比对。

## 五、与 AI 护照机制衔接

每次 A³ 动作，执行方与被造方都须持身份码：
- 执行方身份码 → 决策日志 `actor_agent`；
- 被造方身份码 → 新智能体的"出生证"；
- 二者 + 评估结论一并入证据链，实现"谁造的、造了谁、凭什么放行"全程可溯。

## 六、使用流程（三关）

1. **触发判定**：对照第二节 T1–T5，命中即进评估。
2. **事前评估**：填第三节四维评分卡，按放行/拒绝条件决策；拒绝则升级。
3. **事后留证**：动作与结论落入证据链，偏差升级复盘。

> 配套：证据工件模板见 `ai-governance-audit-chain`；本 skill 每次评审即该证据链的"决策日志 + 人类监督证明"来源。
