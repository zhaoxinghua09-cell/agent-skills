import sys, subprocess
PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
VAULT = "C:/Users/Administrator/.ucvault_local/vault.py"
HOST_USER = {"gitee.com": "stevenzhao26", "atomgit.com": "gcw_PcK6ZWCL"}
HOST_LABEL = {"gitee.com": "gitee_api_key", "atomgit.com": "atomgit_api_key"}

data = sys.stdin.read()
host = None
for line in data.splitlines():
    if line.startswith("host="):
        host = line[5:]
if host in HOST_LABEL and "fill" in data:
    tok = subprocess.run([PY, VAULT, "get", HOST_LABEL[host]], capture_output=True, text=True).stdout.strip()
    print("username=" + HOST_USER[host])
    print("password=" + tok)
