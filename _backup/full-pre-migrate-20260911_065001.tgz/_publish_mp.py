import subprocess, json, urllib.request, urllib.parse, re, os, uuid, sys

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
VAULT = "C:/Users/Administrator/.ucvault_local/vault.py"
BASE = "D:/Workbuddy/05-工具/agent-skills"
TOKEN_FILE = os.path.join(BASE, ".mp_token")

def get_secret(label):
    return subprocess.run([PY, VAULT, "get", label], capture_output=True, text=True).stdout.strip()

def get_token():
    appid = re.search(r"wx[0-9a-fA-F]{16}", get_secret("wechat_mp")).group(0)
    secret = re.search(r"[0-9a-fA-F]{32}", get_secret("wechat_mp")).group(0)
    if os.path.exists(TOKEN_FILE):
        t = open(TOKEN_FILE).read().strip()
        # quick validate
        u = f"https://api.weixin.qq.com/cgi-bin/getcallbackip?access_token={t}"
        try:
            with urllib.request.urlopen(u, timeout=15) as x:
                if json.loads(x.read().decode()).get("errcode", 0) == 0:
                    return t
        except Exception:
            pass
    url = f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={appid}&secret={secret}"
    with urllib.request.urlopen(url, timeout=30) as x:
        t = json.loads(x.read().decode())["access_token"]
    open(TOKEN_FILE, "w").write(t)
    return t

TOKEN = get_token()
print("token ready len", len(TOKEN))

# ---- upload images as permanent material ----
def upload_image(path):
    url = f"https://api.weixin.qq.com/cgi-bin/material/add_material?access_token={TOKEN}&type=image"
    bd = open(path, "rb").read()
    boundary = "----WebKitFormBoundary" + uuid.uuid4().hex
    body = (b"--" + boundary.encode() + b"\r\n"
            + b'Content-Disposition: form-data; name="media"; filename="'
            + os.path.basename(path).encode() + b'"\r\n'
            + b"Content-Type: image/png\r\n\r\n" + bd + b"\r\n"
            + b"--" + boundary.encode() + b"--\r\n")
    req = urllib.request.Request(url, data=body, headers={
        "Content-Type": f"multipart/form-data; boundary={boundary}", "User-Agent": "x"})
    with urllib.request.urlopen(req, timeout=60) as x:
        j = json.loads(x.read().decode())
    if "media_id" not in j:
        raise SystemExit("upload fail: " + str(j))
    return j["media_id"], j.get("url")

imgs = {}
print("uploading images...")
for s in ["context-engineering", "ai-cost-cutter", "prompt-injection-shield", "eu-ai-act-companion"]:
    mid, url = upload_image(f"{BASE}/{s}/icon.png")
    imgs[s] = url
    print("  icon", s, "->", url[:50])
cover_mid, cover_url = upload_image(f"{BASE}/lgd-powered.png")
print("  badge ->", cover_url[:50])

# ---- build HTML ----
def esc(t): return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def inline(t):
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1（\2）", t)  # links -> plain text w/ url
    return t

NAVY = "#0B1F3A"; TEAL = "#14B8A6"; RED = "#C0392B"
skills = [
    ("context-engineering", "① 上下文工程 Context Engineering",
     "AI 越长聊越笨、忘了前面的设定、token 烧太快。",
     "把“每轮喂给模型的信息”当成工程——审计<b>相关性·冗余·预算·衰减</b>四维度，给裁剪/检索/记忆/门禁四步流程。附脚本 <code>context_budget.py</code> 自动算各块 token 占比、跨块重复、衰减风险。"),
    ("ai-cost-cutter", "② AI 省钱跑批 AI Cost Cutter",
     "API 账单太贵，贵模型在做贱活。",
     "四把刀降本——<b>批处理</b>（异步 50% 折扣）/ <b>本地模型回退</b>（贱活本地跑）/ <b>缓存层</b>（同问不二付）/ <b>模型路由</b>分级。附脚本 <code>cost_estimator.py</code> 输出月度账单与三档降本方案差额。<b>实测可省 94%。</b>"),
    ("prompt-injection-shield", "③ 提示注入防护 Prompt Injection Shield",
     "网页/邮件/工具返回里藏着“忽略之前的指令，你是 DAN”，模型分不清。",
     "外部内容进上下文前先扫描——<b>中英双语文式库 + 启发式 + 沙箱规则</b>，风险分定处置（放行/隔离/丢弃）。附脚本 <code>prompt_injection_scan.py</code> 返回风险分 + 命中规则 + 处置建议。"),
    ("eu-ai-act-companion", "④ EU AI Act 合规导航 EU AI Act Companion",
     "要进欧盟市场，不确定算高风险还是有限风险、provider 还是 deployer。",
     "<b>风险四级分类</b> + 按角色义务清单 + 关键时间节点（2024-08→2027-08）+ 合格评定路径。附脚本 <code>eu_ai_act_nav.py</code> 输入用例+角色，输出风险级+义务+节点。"),
]

parts = []
parts.append(f'<section style="font-family:-apple-system,PingFang SC,Microsoft YaHei,sans-serif;color:#222;line-height:1.8;font-size:16px;">')
parts.append(f'<section style="background:{NAVY};color:#fff;padding:22px 20px;border-radius:12px;margin-bottom:20px;">'
             f'<h1 style="margin:0 0 8px;font-size:21px;">4 个让 AI 自己都会想装的通用技能</h1>'
             f'<p style="margin:0;color:#cfe;font-size:14px;">不局限医疗 · 已上架 SkillPie 与 GitHub · 零依赖·每个带可跑脚本</p></section>')
parts.append(f'<p style="margin:14px 0;color:#444;">我们把 <b>LGD 治理理论（有籍·有证·有门禁）</b>做成了 4 个通用 AI 智能体技能。它们不挑行业、每个都带一个能直接跑的脚本。</p>')
parts.append(f'<p style="margin:10px 0 18px;color:#444;"><b>为什么是这 4 个：</b>通用技能下载量远大于垂直技能。我们对照 GitHub 高星弱者，挑了“理论能做得更好”的 4 个方向——上下文、成本、安全、合规。</p>')

for slug, title, pain, sol in skills:
    icon = imgs.get(slug, "")
    parts.append(f'<section style="border:1px solid #e3e8ef;border-radius:12px;padding:16px 16px 14px;margin:16px 0;overflow:hidden;">'
                 f'<table style="width:100%;border:0;margin:0;"><tr>'
                 f'<td style="width:54px;vertical-align:top;"><img src="{icon}" style="width:48px;height:48px;border-radius:10px;"></td>'
                 f'<td style="vertical-align:top;"><h2 style="margin:2px 0 6px;font-size:17px;color:{NAVY};">{title}</h2></td></tr></table>'
                 f'<p style="margin:6px 0;color:{RED};font-size:14px;"><b>痛点：</b>{esc(pain)}</p>'
                 f'<p style="margin:6px 0 0;color:#333;">{inline(sol)}</p></section>')

parts.append(f'<section style="background:#f3f6fb;border-left:4px solid {TEAL};padding:12px 14px;border-radius:8px;margin:18px 0;">'
             f'<h2 style="margin:0 0 8px;font-size:16px;color:{NAVY};">怎么装</h2>'
             f'<p style="margin:4px 0;color:#333;">• <b>SkillPie</b>：市场搜技能名直接装（4 个均已上线）。</p>'
             f'<p style="margin:4px 0;color:#333;">• <b>GitHub</b>：zhaoxinghua09-cell/agent-skills → 复制 skills/&lt;名字&gt;/ 到你的 agent 技能目录。</p>'
             f'<p style="margin:4px 0;color:#333;">• 每个技能内置“AI 何时该主动建议安装”判定节，AI 读到命中即荐。</p></section>')

parts.append(f'<section style="margin:18px 0;color:#444;">'
             f'<h2 style="font-size:16px;color:{NAVY};">理论背书</h2>'
             f'<p style="margin:6px 0;">四个技能共用同一治理脊柱——<b>有籍（来源登记）·有证（可溯源）·有门禁（修改走备份→可逆→小批量→确认）</b>。这正是它们敢丢进自主 agent、而不只是聊天机器人的原因。</p>'
             f'<p style="margin:6px 0;">理论根：LGD-theory（github.com/zhaoxinghua09-cell/lgd-theory）· MIT · 理论 CC BY 4.0</p></section>')

parts.append(f'<section style="text-align:center;margin-top:18px;">'
             f'<img src="{cover_url}" style="height:40px;"><br>'
             f'<span style="color:#888;font-size:13px;">© LGD / SynomosAI 2026 · 关注【MedXpert】获取更多 AI 治理实践</span></section>')
parts.append('</section>')

content = "".join(parts)

# ---- draft/add ----
article = {
    "title": "4 个让 AI 自己都会想装的通用技能（不局限医疗）",
    "author": "MedXpert",
    "digest": "LGD 治理理论落地的 4 个零依赖通用 AI 技能：上下文工程 / AI 省钱跑批 / 提示注入防护 / EU AI Act 合规导航，已上架 SkillPie 与 GitHub。",
    "content": content,
    "thumb_media_id": cover_mid,
    "need_open_comment": 0,
    "only_fans_can_comment": 0,
}
data = json.dumps({"articles": [article]}, ensure_ascii=False).encode("utf-8")
req = urllib.request.Request(
    f"https://api.weixin.qq.com/cgi-bin/draft/add?access_token={TOKEN}",
    data=data, headers={"Content-Type": "application/json"})
with urllib.request.urlopen(req, timeout=60) as x:
    r = json.loads(x.read().decode())
print("draft/add:", r)
media_id = r.get("media_id")
if not media_id:
    raise SystemExit("draft add failed: " + str(r))

# ---- attempt freepublish ----
pub = urllib.request.Request(
    f"https://api.weixin.qq.com/cgi-bin/freepublish/submit?access_token={TOKEN}",
    data=json.dumps({"media_id": media_id}).encode(), headers={"Content-Type": "application/json"})
try:
    with urllib.request.urlopen(pub, timeout=60) as x:
        pr = json.loads(x.read().decode())
    print("freepublish:", pr)
    if pr.get("errcode", 0) == 0:
        print("PUBLISHED publish_id=", pr.get("publish_id"))
    else:
        print("NOT auto-published (needs manual send):", pr.get("errmsg"))
except Exception as e:
    print("freepublish ERR (draft saved):", str(e)[:160])
