# -*- coding: utf-8 -*-
"""lgd-hub 门户同步 81 技能 + og meta 注入 + 分享卡计数修正（本地文件）"""
import pathlib
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

HUB = pathlib.Path("D:/Workbuddy/05-工具/宣传资产/lgd-hub.html")
SHARE = pathlib.Path("D:/Workbuddy/05-工具/agent-skills/_gen_share_cards.py")

# ---- 远端 81 技能真源映射（GitHub skills/ 2026-09-08 拉取）----
HERO = {"lgd-three-laws-auditor", "lgd-certify", "agent-output-registry",
        "evidence-chain-builder", "gate-policy-generator", "lgd-fin-guard",
        "lgd-law-ethic", "lgd-gov-guard", "lgd-crypto-guard"}

GOV = ["a3-law-operational", "agent-boarding-pass", "agent-kill-switch",
       "ai-content-discloser", "ai-decision-log", "ai-incident-log",
       "ai-reply-heuristics", "ai-usage-policy", "ai-vendor-checklist",
       "aml-sentinel", "citation-coverage-check", "contract-clause-check",
       "contract-interact-checklist", "data-export-check", "data-minimizer",
       "evidence-chain-check", "fin-reg-calc", "fund-fee-calc",
       "gov-disclosure-check", "health-claim-guard", "invoice-risk-scan",
       "kyc-checklist-gen", "loan-rate-disclosure", "lgd-badge-issuer",
       "lgd-badge-verify", "model-card-generator", "prompt-injection-drill",
       "prompt-leak-scanner", "token-disclosure-check", "travel-rule-check",
       "wallet-address-check"]

ENG = ["agent-evolution", "agent-loop-guard", "agent-memory-keeper",
       "ai-cost-cutter", "api-resilience", "bias-auditor",
       "context-engineering", "eval-bench-builder", "fact-check-guard",
       "model-router", "multi-agent-conductor", "output-schema-guard",
       "prompt-compressor", "prompt-version-control", "rag-grounding-guard",
       "skill-quality-gate"]

SEC = ["agent-redteam-kit", "doc-desens-scanner", "mcp-security-scan",
       "prompt-injection-shield", "tool-call-guard", "dpapi-local-vault",
       "agent-trace-audit", "ai-policy-radar", "data-rights-guard",
       "eu-ai-act-companion"]

EFF = ["batch-renamer", "csv-slice", "dir-organizer", "disk-scan",
       "dup-finder", "hash-check", "json-tidy", "regex-sandbox",
       "text-replace", "text-stats", "github-api-push-workaround",
       "publish-quality-gate", "ai-brain-learning-memory",
       "ai-brain-learning-memory-pro", "session-continuity-protocol"]

NAMES = {
    "a3-law-operational": "A³ 法则操作化",
    "agent-evolution": "数字员工进化飞轮",
    "github-api-push-workaround": "GitHub 推送三归因排障",
    "publish-quality-gate": "发布质量闸门",
    "dpapi-local-vault": "本地 DPAPI 免口令凭据库",
    "session-continuity-protocol": "跨会话连续性协议（开局四步）",
    "ai-brain-learning-memory": "AI 大脑学习记忆方法论",
    "ai-brain-learning-memory-pro": "AI 记忆工程实战版",
}

GROUPS = [
    ("AI 治理矩阵", "有籍 · 有证 · 有门禁的全域落地", "G", GOV),
    ("AI 工程方法", "把三律做进 agent 的工程底座", "E", ENG),
    ("AI 安全 · 合规", "红队 / 去敏 / 法规导航", "S", SEC),
    ("效率 · 工作台 · 学习", "日常刚需 + 记忆方法论", "X", EFF),
]

REPO = "https://github.com/zhaoxinghua09-cell/agent-skills/tree/main/skills/%s"


def card(prefix, i, slug):
    name = NAMES.get(slug, "")
    p = "<p>%s</p>" % name if name else "<p></p>"
    return ('<div class="card"><span class="badge">%s%d</span><h3>%s</h3>%s'
            '<a href="%s" target="_blank" rel="noopener">GitHub ↗</a></div>'
            % (prefix, i, slug, p, REPO % slug))


def build_section():
    parts = ['<!-- 技能矩阵 · 全家族（81） -->',
             '<section class="matrix" id="skills-more">', '  <div class="wrap">',
             '    <div class="sec-title">技能矩阵 · 全家族 81 个零依赖技能</div>',
             '    <div class="sec-h">LGD 原生 39 + 效率工具 10 + 工程与工作台 32 · 全部 GitHub 开源 · SkillPie 一键装</div>']
    for title, sub, prefix, slugs in GROUPS:
        parts.append('    <div style="margin:26px 0 12px;font-size:17px;font-weight:700;color:var(--teal)">%s · %d</div>'
                     % (title, len(slugs)))
        parts.append('    <div class="grid">')
        for i, s in enumerate(slugs, 1):
            parts.append("      " + card(prefix, i, s))
        parts.append("    </div>")
    parts.append("  </div>")
    parts.append("</section>")
    return "\n".join(parts)


html = HUB.read_text(encoding="utf-8")
orig = html

# 1) og meta 注入（幂等）
if "og:image" not in html:
    og = ('<meta property="og:title" content="凡自治之物 · LGD 三律理论门户">\n'
          '<meta property="og:description" content="有籍·有证·有门禁 —— 81 个零依赖 AI 治理技能，一行命令安装。">\n'
          '<meta property="og:image" content="https://zhaoxinghua09-cell.github.io/lgd-hub/og-card.png">\n'
          '<meta property="og:url" content="https://zhaoxinghua09-cell.github.io/lgd-hub/">\n'
          '<meta name="twitter:card" content="summary_large_image">')
    anchor = '<meta name="description" content="LGD 全程治理论（有籍·有证·有门禁）——把 AI 治理的标准定义权做成可引用、可装、可验证的闭环。理论、技能、产品、服务一站式入口。">'
    assert anchor in html, "meta description 锚点未找到"
    html = html.replace(anchor, anchor + "\n" + og, 1)
    print("[1] og meta 注入 OK")

# 2) 计数修正
html = html.replace("9 个零依赖守门/闭环技能，SkillPie 一键装，GitHub 开源。",
                    "81 个零依赖技能全家族（治理 40 · 工程 16 · 安全合规 10 · 效率 15），SkillPie 一键装，GitHub 开源。", 1)
html = html.replace("技能矩阵 · 9 个 LGD 原生技能", "旗舰矩阵 · 9 个 LGD 原生技能", 1)
html = html.replace('SkillPie 应用市场搜索 "LGD" 或 "凡自治之物" 一键安装 · 分类：AI 治理',
                    'SkillPie 应用市场搜索 "LGD" 或 "凡自治之物" 一键安装 · 全家族 81 个 · 分类：AI 治理 / 效率工具', 1)
print("[2] 计数修正 OK")

# 3) 插入全家族 section（在 产品+服务 section 之前）
if 'id="skills-more"' not in html:
    anchor2 = "<!-- 产品 + 服务 -->"
    assert anchor2 in html, "产品锚点未找到"
    html = html.replace(anchor2, build_section() + "\n\n" + anchor2, 1)
    print("[3] 全家族 section 插入 OK（%d 卡）" % sum(len(g[3]) for g in GROUPS))

assert html != orig
HUB.write_text(html, encoding="utf-8")
print("lgd-hub.html 已更新，%d 字节" % len(html.encode("utf-8")))

# 4) 分享卡计数 39 -> 81
st = SHARE.read_text(encoding="utf-8")
st2 = st.replace("39 个零依赖 AI 治理技能", "81 个零依赖 AI 治理技能")
st2 = st2.replace("39 个零依赖技能", "81 个零依赖技能")
if st2 != st:
    SHARE.write_text(st2, encoding="utf-8")
    print("[4] 分享卡计数 39->81 OK")
else:
    print("[4] 分享卡计数无需修改")
