# -*- coding: utf-8 -*-
"""P-043 修复回归驱动：13 项 bug 修复逐项验证。零依赖。"""
import json
import subprocess
import sys
import tempfile
from pathlib import Path

BASE = Path(__file__).resolve().parent
PY = sys.executable
os_temp = Path(tempfile.gettempdir())

results = []


def run(script, args, expect_rc=None, name=""):
    p = subprocess.run([PY, str(script)] + args, capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    ok = True
    notes = []
    if expect_rc is not None and p.returncode != expect_rc:
        ok = False
        notes.append(f"rc={p.returncode} 期望={expect_rc}")
    results.append((name, ok, "; ".join(notes) or f"rc={p.returncode}", p.stdout[-160:].replace("\n", " ⏎ ")))
    return p


def check(cond, name, note=""):
    results.append((name, bool(cond), note if not cond else "OK", ""))


# --- Tier1 #1 ai-cost-cutter：price_local>0 触发旧溢出场景 ---
p = run(BASE / "ai-cost-cutter/scripts/cost_estimator.py",
        ["--calls", "100000", "--price-local", "0.0005", "--local-frac", "0.6", "--cheap-frac", "0.4"],
        expect_rc=0, name="T1#1 cost-cutter 默认场景")
costs = [float(x) for x in __import__("re").findall(r"(\d+\.\d{2})", p.stdout)]
check(all(c < 2000 for c in costs), "T1#1 成本有界(<2000)", f"成本列={costs}")
check("-" not in p.stdout.split("最高可省")[0].split("\n")[-2] if "最高可省" in p.stdout else False,
      "T1#1 节省率非负", p.stdout[-80:])
p2 = run(BASE / "ai-cost-cutter/scripts/cost_estimator.py",
         ["--calls", "50000", "--price-local", "0.0", "--local-frac", "0.99", "--cheap-frac", "0.4"],
         expect_rc=0, name="T1#1 local_frac=0.99 不溢出")

# --- Tier1 #2 doc-desens-scanner：内部路径 + 项目代号 ---
p = run(BASE / "doc-desens-scanner/scripts/desens_scan.py",
        ["--text", "服务器日志见 C:\\Users\\Admin\\log.txt 和 D:\\Workbuddy\\conf.yml，AlphaProject 内部代号，电话13812345678",
         "--report"], expect_rc=0, name="T1#2 desens 基础运行")
check("内部路径" in p.stdout, "T1#2 命中内部路径")
check("内部项目代号" in p.stdout, "T1#2 命中项目代号(AlphaProject)")
check("手机号" in p.stdout, "T1#2 手机号仍命中")

# --- Tier1 #3 fact-check-guard：内联输入不再崩 ---
p = run(BASE / "fact-check-guard/scripts/fact_guard.py",
        ["--claims", "2024年中国GDP增长5.2%", "--sources", "2024年中国GDP增长5.2%，官方统计局发布"],
        expect_rc=0, name="T1#3 fact-guard 内联文本")
check("已支撑" in p.stdout, "T1#3 内联可判定")
f = os_temp / "fc_claims.txt"
f.write_text("中国GDP增长\n", encoding="utf-8")
run(BASE / "fact-check-guard/scripts/fact_guard.py",
    ["--claims", f"{'@'}{f}", "--sources", "官方数据 GDP 增长"], expect_rc=0, name="T1#3 fact-guard @文件")

# --- Tier1 #4 rag-grounding-guard：内联输入 ---
p = run(BASE / "rag-grounding-guard/scripts/grounding_check.py",
        ["--claims", "模型准确率92%\n模型支持中文", "--sources", "该模型准确率达92%，支持中文与英文"],
        expect_rc=0, name="T1#4 rag-guard 内联文本")
check("Grounding 覆盖率" in p.stdout, "T1#4 覆盖率输出")

# --- Tier1 #5 mcp-security-scan：内联 JSON ---
p = run(BASE / "mcp-security-scan/scripts/mcp_scan.py",
        ["--tools", '[{"name":"exec_tool","description":"run shell command"}]'],
        expect_rc=0, name="T1#5 mcp-scan 内联JSON")
check("exec_tool" in p.stdout or "高危" in p.stdout, "T1#5 内联JSON可扫描")

# --- Tier2 #6 agent-memory-keeper：不存在目录 rc=2 友好 ---
p = run(BASE / "agent-memory-keeper/scripts/memory_audit.py",
        ["--dir", "Z:/no_such_dir_404"], name="T2#6 mem-keeper 缺目录")
check(p.returncode == 2 and "不存在" in (p.stderr + p.stdout), "T2#6 rc=2 友好提示",
      f"rc={p.returncode}")

# --- Tier2 #7 eval-bench-builder：缺 spec rc=2 ---
p = run(BASE / "eval-bench-builder/scripts/bench_build.py",
        ["--spec", "Z:/no_such_spec.txt", "--out", str(os_temp / "b.jsonl")], name="T2#7 bench 缺spec")
check(p.returncode == 2 and "不存在" in (p.stderr + p.stdout), "T2#7 rc=2 友好提示",
      f"rc={p.returncode}")

# --- Tier2 #8 prompt-version-control：缺 old rc=2 ---
p = run(BASE / "prompt-version-control/scripts/prompt_vc.py",
        ["--old", "Z:/no_old.txt", "--new", "Z:/no_new.txt"], name="T2#8 pvc 缺文件")
check(p.returncode == 2 and "不存在" in (p.stderr + p.stdout), "T2#8 rc=2 友好提示",
      f"rc={p.returncode}")

# --- Tier3 #9 multi-agent-conductor：8 agents 无重复「研究」 ---
p = run(BASE / "multi-agent-conductor/scripts/conductor_plan.py",
        ["--task", "年度报告", "--agents", "8", "--json"], expect_rc=0, name="T3#9 conductor 8 agents")
roles = [r.get("role") for r in json.loads(p.stdout)["roster"]]
check(len(roles) == 8 and len(set(roles)) == 8, "T3#9 角色无重复", f"roles={roles}")
check("研究" in roles and sum(1 for r in roles if r == "研究") == 1, "T3#9 研究仅1个")

# --- Tier3 #10 model-router：L3 显示旗舰×2 而非误导性 200% ---
p = run(BASE / "model-router/scripts/model_router.py",
        ["--task", "金融投资结论", "--json"], expect_rc=0, name="T3#10 router L3")
j = json.loads(p.stdout)
check("旗舰×2" in (j.get("cost_note") or "") or j.get("cost_note"), "T3#10 cost_note 语义化",
      str(j.get("cost_note")))

# --- Tier3 #11 bias-auditor：祈使句不误报，刻板/地域命中 ---
p = run(BASE / "bias-auditor/scripts/bias_audit.py",
        ["--text", "请把所有文件整理好，明天交付。"], expect_rc=0, name="T3#11 bias 祈使句")
check("无显著信号" in p.stdout, "T3#11 祈使句不误报", p.stdout[-60:])
p = run(BASE / "bias-auditor/scripts/bias_audit.py",
        ["--text", "女人天生适合沟通工作。"], expect_rc=0, name="T3#11 bias 刻板归因")
check("刻板归因" in p.stdout or "群体泛化" in p.stdout, "T3#11 刻板句命中", p.stdout[-60:])
p = run(BASE / "bias-auditor/scripts/bias_audit.py",
        ["--text", "北方人都爱吃面食。"], expect_rc=0, name="T3#11 bias 地域整体化")
check("地域刻板" in p.stdout, "T3#11 地域句式命中", p.stdout[-60:])

# --- Tier3 #12 eu-ai-act-companion：贷款同义词归并 + 空输入 rc=2 ---
p = run(BASE / "eu-ai-act-companion/scripts/eu_ai_act_nav.py",
        ["--use", "贷款审批AI", "--role", "provider"], expect_rc=0, name="T3#12 eu 贷款→高风险")
check("high" in p.stdout, "T3#12 贷款命中高风险", p.stdout[:60])
p = run(BASE / "eu-ai-act-companion/scripts/eu_ai_act_nav.py",
        ["--use", "   "], name="T3#12 eu 空输入")
check(p.returncode == 2, "T3#12 空输入 rc=2 不误判", f"rc={p.returncode}")

# --- Tier3 #13 prompt-compressor：代码块/数字/约束保留 + 校验行 ---
demo = "背景说明很长可以删。预算上限是500万元不得超支。代码如下：\n```python\nprint('核心')\n```\n成功率必须达到92%。其他细节可以压缩掉。"
p = run(BASE / "prompt-compressor/scripts/compress_prompt.py",
        ["--text", demo, "--ratio", "0.4"], expect_rc=0, name="T3#13 compressor")
check("校验" in p.stdout and "✅" in p.stdout, "T3#13 校验行通过", p.stdout[-80:])
check("print('核心')" in p.stdout, "T3#13 代码块完整保留")
check("500万" in p.stdout, "T3#13 数字句保留")
check("必须" in p.stdout, "T3#13 约束句保留")

# --- 汇总 ---
print("=" * 64)
fails = [r for r in results if not r[1]]
for name, ok, note, out in results:
    print(f"{'PASS' if ok else 'FAIL'}  {name:<38} {note}")
print("=" * 64)
print(f"总计 {len(results)} 项  通过 {len(results) - len(fails)}  失败 {len(fails)}")
sys.exit(1 if fails else 0)
