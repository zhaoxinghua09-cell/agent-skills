# -*- coding: utf-8 -*-
"""P1 分享卡生成：1200x630 总卡 + 1200x1600 清单长卡
VI 铁律：只用定版真源圆徽嵌入，不自创/重绘任何徽章；LGD 主色 #0B1F3A + 强调 #14B8A6
"""
from PIL import Image, ImageDraw, ImageFont
import pathlib

NAVY = (11, 31, 58)        # #0B1F3A 藏青
NAVY_D = (7, 22, 42)
TEAL = (20, 184, 166)      # #14B8A6 青绿
IVORY = (245, 240, 229)    # 象牙白
GREY = (150, 165, 185)
GOLD = (232, 214, 175)

F = "C:/Windows/Fonts/msyh.ttc"
FB = "C:/Windows/Fonts/msyhbd.ttc"
BADGE = pathlib.Path("D:/Workbuddy/08-理论体系/发布/徽章kit/VI套件_20260907/LGD无字圆徽_标准头像_512.png")
OUT = pathlib.Path("D:/Workbuddy/05-工具/宣传资产/sharecards")
OUT.mkdir(parents=True, exist_ok=True)


def font(sz, bold=False):
    return ImageFont.truetype(FB if bold else F, sz)


def bg_gradient(w, h):
    """藏青纵向微渐变底"""
    img = Image.new("RGB", (w, h), NAVY)
    d = ImageDraw.Draw(img)
    for y in range(h):
        t = y / h
        c = tuple(int(NAVY[i] + (NAVY_D[i] - NAVY[i]) * t) for i in range(3))
        d.line([(0, y), (w, y)], fill=c)
    return img


def paste_badge(img, size, x, y):
    b = Image.open(BADGE).convert("RGBA").resize((size, size), Image.LANCZOS)
    img.paste(b, (x, y), b)


def center(d, cx, y, text, fnt, fill):
    bb = d.textbbox((0, 0), text, font=fnt)
    d.text((cx - (bb[2] - bb[0]) / 2 - bb[0], y), text, font=fnt, fill=fill)
    return bb[3] - bb[1]


# ============ 卡1：1200x630 总卡 ============
W, Hh = 1200, 630
img = bg_gradient(W, Hh)
d = ImageDraw.Draw(img)
# 顶部青绿细线
d.rectangle([0, 0, W, 6], fill=TEAL)
# 圆徽
paste_badge(img, 150, 60, 70)
# 主标题
d.text((250, 95), "全程治理论 LGD", font=font(64, True), fill=IVORY)
d.text((255, 175), "Lifecycle Governance Doctrine", font=font(26), fill=GREY)
# 三律（青绿分隔点）
slogan = "有籍 · 有证 · 有门禁"
bb = d.textbbox((0, 0), slogan, font=font(44, True))
d.text(((W - bb[2] + bb[0]) / 2, 300), slogan, font=font(44, True), fill=TEAL)
# 数据行
stats = "81 个零依赖 AI 治理技能 ｜ 7 大行业域 ｜ 一行命令安装 ｜ MIT 开源"
bb = d.textbbox((0, 0), stats, font=font(26))
d.text(((W - bb[2] + bb[0]) / 2, 395), stats, font=font(26), fill=IVORY)
# 分隔线
d.line([(200, 470), (W - 200, 470)], fill=(40, 62, 95), width=2)
# 链接行
link = "github.com/zhaoxinghua09-cell/agent-skills"
bb = d.textbbox((0, 0), link, font=font(30, True))
d.text(((W - bb[2] + bb[0]) / 2, 505), link, font=font(30, True), fill=GOLD)
# 底部域名
hub = "lgd-hub · zhaoxinghua09-cell.github.io/lgd-hub"
bb = d.textbbox((0, 0), hub, font=font(20))
d.text(((W - bb[2] + bb[0]) / 2, 565), hub, font=font(20), fill=GREY)
img.save(OUT / "lgd_moat_card_1200x630.png", optimize=True)
print("card1 ok")

# ============ 卡2：1200x1600 清单长卡 ============
W2, H2 = 1200, 1600
img2 = bg_gradient(W2, H2)
d2 = ImageDraw.Draw(img2)
d2.rectangle([0, 0, W2, 8], fill=TEAL)
paste_badge(img2, 120, 60, 60)
d2.text((220, 72), "LGD 治理技能全家福", font=font(52, True), fill=IVORY)
d2.text((224, 140), "有籍 · 有证 · 有门禁 ｜ 81 个零依赖技能", font=font(24), fill=TEAL)
d2.line([(60, 220), (W2 - 60, 220)], fill=(40, 62, 95), width=2)

GROUPS = [
    ("旗舰核心 · 5", ["lgd-three-laws-auditor", "agent-output-registry", "evidence-chain-builder", "lgd-certify", "gate-policy-generator"]),
    ("跨域守门 · 4", ["lgd-fin-guard", "lgd-law-ethic", "lgd-gov-guard", "lgd-crypto-guard"]),
    ("纵深工具 · 5", ["fin-reg-calc", "aml-sentinel", "evidence-chain-check", "gov-disclosure-check", "travel-rule-check"]),
    ("徽章闭环 · 2", ["lgd-badge-issuer", "lgd-badge-verify"]),
    ("通用治理 · 13", ["ai-content-discloser", "agent-boarding-pass", "prompt-leak-scanner", "data-minimizer", "model-card-generator", "ai-usage-policy", "ai-incident-log", "agent-kill-switch", "ai-reply-heuristics", "citation-coverage-check", "ai-vendor-checklist", "prompt-injection-drill", "ai-decision-log"]),
    ("金融×区块链 · 10", ["loan-rate-disclosure", "kyc-checklist-gen", "invoice-risk-scan", "fund-fee-calc", "wallet-address-check", "token-disclosure-check", "contract-interact-checklist", "contract-clause-check", "health-claim-guard", "data-export-check"]),
]

y = 250
f_g = font(28, True)
f_s = font(21)
for title, slugs in GROUPS:
    d2.rounded_rectangle([60, y + 2, 68, y + 30], radius=2, fill=TEAL)
    d2.text((80, y), title, font=f_g, fill=GOLD)
    y += 44
    # slug 两列排布
    col_w = (W2 - 140) // 2
    for i, s in enumerate(slugs):
        cx = 80 + (i % 2) * col_w
        cy = y + (i // 2) * 36
        d2.ellipse([cx, cy + 10, cx + 8, cy + 18], fill=TEAL)
        d2.text((cx + 20, cy), s, font=f_s, fill=IVORY)
    y += ((len(slugs) + 1) // 2) * 36 + 18

# 底部安装块
d2.rounded_rectangle([60, y + 10, W2 - 60, y + 80], radius=12, fill=(16, 42, 76))
cmd = "npx -y agent-skills add <skill-slug>"
d2.text((90, y + 28), "安装：", font=font(22, True), fill=TEAL)
d2.text((170, y + 28), cmd, font=font(22), fill=IVORY)
y += 100
d2.line([(60, y), (W2 - 60, y)], fill=(40, 62, 95), width=2)
d2.text((80, y + 18), "github.com/zhaoxinghua09-cell/agent-skills", font=font(26, True), fill=GOLD)
d2.text((80, y + 58), "zhaoxinghua09-cell.github.io/lgd-hub", font=font(22), fill=GREY)
img2.save(OUT / "lgd_skills_list_1200x1600.png", optimize=True)
print("card2 ok, bottom_y=%d" % y)
