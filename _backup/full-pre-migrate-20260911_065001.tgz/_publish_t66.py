# -*- coding: utf-8 -*-
"""T66 收尾：lgd-theory 推 AGENTS.md + schema.jsonld + README 追加机器可读段"""
import base64
import json
import pathlib
import subprocess
import urllib.request
import urllib.error

VAULT = "C:/Users/Administrator/.ucvault_local/vault.py"
PYE = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
OWNER, REPO = "zhaoxinghua09-cell", "lgd-theory"

r = subprocess.run([PYE, VAULT, "get", "github_api_key"], capture_output=True, text=True)
tok = r.stdout.strip()
H = {"Authorization": "Bearer " + tok, "Accept": "application/vnd.github+json",
     "User-Agent": "lgd-theory-t66", "X-GitHub-Api-Version": "2022-11-28"}


def call(method, path, data=None):
    req = urllib.request.Request("https://api.github.com/" + path,
                                 data=(json.dumps(data).encode() if data else None),
                                 headers=H, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return resp.status, json.loads(resp.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode(errors="replace")[:300]


def put_bytes(content_bytes, gh_path, msg):
    st0, cur = call("GET", "repos/%s/%s/contents/%s" % (OWNER, REPO, gh_path))
    sha = cur.get("sha") if isinstance(cur, dict) else None
    data = {"message": msg, "content": base64.b64encode(content_bytes).decode()}
    if sha:
        data["sha"] = sha
    st, resp = call("PUT", "repos/%s/%s/contents/%s" % (OWNER, REPO, gh_path), data)
    print(("[OK] " if st in (200, 201) else "[FAIL] ") + gh_path + " -> " + str(st))


AGENTS_MD = """# AGENTS.md · lgd-theory

本仓库是全程治理论（LGD, Lifecycle Governance Doctrine）旗舰理论与跨域 rubric 站位件源。

## 协作约定
- 域理论扩展遵循既定纪律：先立站位件（RRM 母版锚定 + 三律本域化 rubric）→ 再产执行器 → 才发布。
- 引用一律用概念 DOI 10.5281/zenodo.22456647（自动指向最新版）。
- 品牌×术语绑定：全程治理论 / 算法护照 / 记忆锚点，CC BY 4.0 须署名。
- 密钥只走保险库；内部代号、真名、本地路径不进公开物。

## 目录
- `docs/`：旗舰论文 + 9 域理论（FIN/LAW/GOV/CRYPT/AUT/DAT/UAS/ROB/MED）
- `CITE.md`：引用包（APA/BibTeX/RIS/GB/T 7714）｜ `TLDR.md`：≤200 字机器友好摘要
- `schema.jsonld`：schema.org ScholarlyArticle 结构化引用
- `badge/`：LGD 定版徽章真源 ｜ `book/`、`newsletter/`、`promo/`、`arxiv/`：衍生物料
"""

SCHEMA_JSONLD = """{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "ScholarlyArticle",
      "headline": "Lifecycle Governance Doctrine (LGD): Registry, Evidence, and Gates for Autonomous Systems",
      "author": {
        "@type": "Person",
        "name": "Zhao Xinghua (Steven Zhao)",
        "orcid": "https://orcid.org/0009-0001-0512-1237"
      },
      "datePublished": "2026-09-06",
      "version": "1.1.0",
      "license": "https://creativecommons.org/licenses/by/4.0/",
      "publisher": { "@type": "Organization", "name": "MedXpert × SynomosAI" },
      "sameAs": "https://doi.org/10.5281/zenodo.22456647",
      "url": "https://github.com/zhaoxinghua09-cell/lgd-theory",
      "keywords": "lifecycle governance, AI governance, registry, evidence, gates, 有籍, 有证, 有门禁"
    },
    {
      "@type": "Organization",
      "name": "MedXpert × SynomosAI",
      "url": "https://medxpert.cn",
      "sameAs": ["https://github.com/zhaoxinghua09-cell/lgd-theory"]
    }
  ]
}
"""

README_APPEND = """
---

## Machine-readable metadata

- Structured citation: [`schema.jsonld`](schema.jsonld) — schema.org `ScholarlyArticle`
- Agent collaboration conventions: [`AGENTS.md`](AGENTS.md)
- Citation pack: [`CITE.md`](CITE.md) · TL;DR: [`TLDR.md`](TLDR.md)
- Concept DOI: <https://doi.org/10.5281/zenodo.22456647> · ORCID: [0009-0001-0512-1237](https://orcid.org/0009-0001-0512-1237)
"""

# 1) AGENTS.md
put_bytes(AGENTS_MD.encode("utf-8"), "AGENTS.md", "add AGENTS.md agent collaboration conventions (T66)")
# 2) schema.jsonld
put_bytes(SCHEMA_JSONLD.encode("utf-8"), "schema.jsonld", "add schema.org ScholarlyArticle JSON-LD (T66)")
# 3) README 追加机器可读段
st, cur = call("GET", "repos/%s/%s/contents/README.md" % (OWNER, REPO))
if st == 200:
    readme = base64.b64decode(cur["content"]).decode("utf-8")
    if "Machine-readable metadata" not in readme:
        readme += README_APPEND
        put_bytes(readme.encode("utf-8"), "README.md", "README: append machine-readable metadata section (T66)")
    else:
        print("[SKIP] README already has metadata section")
else:
    print("[FAIL] README fetch", st)
print("done")
