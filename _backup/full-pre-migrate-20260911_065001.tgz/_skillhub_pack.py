# -*- coding: utf-8 -*-
"""SkillHub 81家族补传备包器 (P-057)
口径照抄 SkillHub 已过审先例(a3-law-operational upload_ready):
  author: 诺声(Logos)@SynomosAI / copyright: SynomosAI / license: MIT
  zip 内含 <slug>/ 同名文件夹
铁律: 打包=AI 备包; 上传=Steven 网页点传(微信OAuth), AI 不代发。
"""
import base64
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
VAULT = "C:/Users/Administrator/.ucvault_local/vault.py"
LOCAL_SRC = Path("D:/Workbuddy/05-工具/agent-skills")
OUT_ROOT = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/SkillHub上架包_81家族_20260908")
REPO = "zhaoxinghua09-cell/agent-skills"
HOMEPAGE = "https://zhaoxinghua09-cell.github.io/lgd-hub/"
PEN = "诺声(Logos)@SynomosAI"

# 已确认在 SkillHub 的 5 个(有 skillId 记录), 不重复备包
ALREADY_UP = {
    "session-continuity-protocol",
    "dpapi-local-vault",
    "ai-brain-learning-memory",
    "agent-evolution",
    "a3-law-operational",
}

# GitHub 拉取反复断流的, 用历史就绪副本兜底
FALLBACK_SRC = {
    "ai-brain-learning-memory-pro": Path("D:/Workbuddy/2026-09-01-20-07-20/upload_ready/ai-brain-learning-memory-pro"),
}

AUTHOR_BODY_FIXES = [
    ("赵兴华 / Steven Zhao·China", "诺声(Logos)"),
    ("赵兴华 / Steven Zhao · China", "诺声(Logos)"),
    ("赵兴华（Steven Zhao）", "诺声(Logos)"),
    ("Steven Zhao (MedXpert × SynomosAI)", "诺声(Logos)"),
    ("Steven Zhao · China", "诺声(Logos)"),
    ("Steven Zhao·China", "诺声(Logos)"),
    ("Steven Zhao", "诺声(Logos)"),
    ("赵兴华", "诺声(Logos)"),
]

# FAIL 级敏感形状(命中即拒包)
FAIL_PATTERNS = [
    (r"赵兴华|Steven Zhao|xinghua06", "真名残留"),
    (r"C:\\Users|C:/Users|/c/Users|D:\\Workbuddy|D:/Workbuddy", "本地路径残留"),
    (r"\.ucvault|ucvault_local", "保险库路径残留"),
    (r"ghp_[A-Za-z0-9]{20,}|gho_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|sk-ant-|sk-proj-", "疑似密钥"),
    (r"provider-internal", "内部代号残留"),
]
EMAIL_OK = ("info@medxpert.cn", "example.com", "@github.com", "@users.noreply", "synomos.ai")
TEXT_EXT = {".md", ".txt", ".py", ".json", ".yaml", ".yml", ".sh", ".js", ".ts", ".html", ".css", ".svg"}
JUNK = {"__pycache__", ".git", ".idea", ".vscode", "node_modules", ".DS_Store"}


def gh_token():
    r = subprocess.run([PY, VAULT, "get", "github_api_key"], capture_output=True, text=True)
    return r.stdout.strip()


def gh_json(url, tok):
    req = urllib.request.Request(url, headers={"Authorization": "Bearer " + tok, "User-Agent": "skillhub-pack"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode())


def gh_fetch_dir(slug, tok, dest):
    """递归拉取远端 skills/<slug> 到 dest。"""
    def walk(api_path, disk):
        items = gh_json("https://api.github.com/repos/%s/contents/%s?ref=main" % (REPO, api_path), tok)
        disk.mkdir(parents=True, exist_ok=True)
        for it in items:
            if it["type"] == "dir":
                if it["name"] in JUNK:
                    continue
                walk(api_path + "/" + it["name"], disk / it["name"])
            else:
                if it["name"].endswith((".bak", ".pyc", ".log")) or it["name"].startswith(("_meta", "_icon", ".DS")):
                    continue
                raw = gh_json("https://api.github.com/repos/%s/contents/%s" % (REPO, it["path"]), tok)
                (disk / it["name"]).write_bytes(base64.b64decode(raw["content"]))

    walk("skills/" + slug, dest)


def load_slugs():
    tok = gh_token()
    items = gh_json("https://api.github.com/repos/%s/contents/skills?ref=main" % REPO, tok)
    remote = sorted(it["name"] for it in items)
    return tok, [s for s in remote if s not in ALREADY_UP], len(remote)


def norm_frontmatter(txt, slug, cat_default):
    m = re.match(r"^---\n(.*?)\n---\n?(.*)$", txt, re.S)
    if not m:
        return None, "frontmatter 解析失败"
    fm, body = m.group(1), m.group(2)
    lines = fm.split("\n")
    out = []
    has = lambda key: any(l.startswith(key + ":") for l in lines)

    display_name = ""
    for l in lines:
        if l.startswith("display_name:"):
            display_name = l.split(":", 1)[1].strip().strip('"')
            break
    if not display_name:
        display_name = slug

    desc_val = ""
    for l in lines:
        if l.startswith("description:"):
            desc_val = l.split(":", 1)[1].strip().strip('"')
            break
    summary = desc_val[:100]
    for cut in ("。", "；", ";"):
        if cut in summary:
            summary = summary.split(cut)[0] + cut
            break

    for l in lines:
        ls = l.strip()
        if ls.startswith("author:"):
            out.append("author: " + PEN)
        elif ls.startswith("platforms:"):
            out.append("platforms: [windows, macos, linux]")
        elif ls.startswith("license:"):
            out.append("license: MIT")
        else:
            out.append(l)
        # 插入缺省字段
        if ls.startswith("author:") and not has("copyright"):
            out.append("copyright: SynomosAI")
        if ls.startswith("display_name:") and not has("displayname") and not has("displayName"):
            out.append('displayName: "%s"' % display_name)
        if ls.startswith("description:") and not has("summary"):
            out.append('summary: "%s"' % summary.replace('"', "'"))
    if not has("license"):
        out.append("license: MIT")
    if not has("homepage"):
        out.append("homepage: " + HOMEPAGE)
    if not has("tags"):
        cat = ""
        for l in out:
            if l.startswith("category:"):
                cat = l.split(":", 1)[1].strip()
                break
        out.append("tags: [诺声, AI技能, SynomosAI, %s, %s]" % (cat or cat_default, slug))
    return "---\n" + "\n".join(out) + "\n---\n" + body, None


def fix_and_scan(stage, slug):
    """正文化替换 + 敏感扫描。返回 FAIL 清单。"""
    fails = []
    for p in sorted(stage.rglob("*")):
        if not p.is_file() or p.suffix.lower() not in TEXT_EXT:
            continue
        txt = p.read_text(encoding="utf-8", errors="replace")
        orig = txt
        for old, new in AUTHOR_BODY_FIXES:
            txt = txt.replace(old, new)
        for pat, label in FAIL_PATTERNS:
            if re.search(pat, txt):
                fails.append("%s: %s (%s)" % (label, p.relative_to(stage), slug))
        # 邮箱白名单外 → FAIL
        for em in re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", txt):
            if not any(ok in em.lower() for ok in EMAIL_OK):
                fails.append("白名单外邮箱 %s (%s)" % (em, slug))
        if txt != orig:
            p.write_text(txt, encoding="utf-8")
        else:
            p.write_text(txt, encoding="utf-8", newline="\n")  # 统一 LF, 规避平台 CRLF 兼容风险
    return fails


def make_license(stage):
    mit = """MIT License

Copyright (c) 2026 SynomosAI

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""
    (stage / "LICENSE").write_text(mit, encoding="utf-8")


def make_manifest(stage, slug, ver, cat):
    man = {
        "schema": "lgd-skill-manifest/v1",
        "name": slug,
        "slug": slug,
        "version": ver,
        "author": PEN,
        "copyright": "SynomosAI",
        "license": "MIT",
        "category": cat,
        "origin": "https://github.com/%s/tree/main/skills/%s" % (REPO, slug),
        "homepage": HOMEPAGE,
        "agent_created": True,
        "packaged_at": "2026-09-08",
    }
    (stage / "manifest.json").write_text(json.dumps(man, ensure_ascii=False, indent=2), encoding="utf-8")


def make_attestation(stage, slug):
    att = """# 权属与原创性声明 / ATTESTATION

- 技能: **%s**
- 署名: 诺声(Logos)@SynomosAI（大使笔名@组织）
- 版权与许可: © 2026 SynomosAI · MIT License
- 原创性: 本技能由 SynomosAI 智能体团队原创开发，非复制第三方作品；核心逻辑为原创实现。
- 零依赖: 仅使用语言标准库，无第三方运行时依赖（脚本类技能）。
- 安全自检: 已通过敏感信息扫描（无真名/本地路径/密钥/内部代号），发布闸门留痕。
- 权威源: https://github.com/zhaoxinghua09-cell/agent-skills/tree/main/skills/%s
- 打包日期: 2026-09-08
""" % (slug, slug)
    (stage / "ATTESTATION.md").write_text(att, encoding="utf-8")


def copy_tree(src, dst):
    dst.mkdir(parents=True, exist_ok=True)
    for root, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if d not in JUNK]
        for f in files:
            if f.endswith((".bak", ".pyc", ".log")) or f.startswith((".DS", "_meta", "_icon")):
                continue
            rp = Path(root) / f
            (dst / rp.relative_to(src)).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(rp, dst / rp.relative_to(src))


def zip_dir(stage, zip_path, slug):
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(stage.rglob("*")):
            if p.is_file():
                z.write(p, "%s/%s" % (slug, p.relative_to(stage)))


def main():
    tok, slugs, remote_total = load_slugs()
    print("远端技能 %d | 已在 SkillHub %d | 本批备包 %d" % (remote_total, len(ALREADY_UP), len(slugs)))
    OUT_ROOT.mkdir(parents=True, exist_ok=True)
    ok_rows, fail_rows = [], []

    for slug in slugs:
        src = LOCAL_SRC / slug
        stage = OUT_ROOT / "_stage" / slug
        if stage.exists():
            shutil.rmtree(stage)
        note = ""
        try:
            if src.is_dir():
                copy_tree(src, stage)
                note = "本地"
            elif slug in FALLBACK_SRC and FALLBACK_SRC[slug].is_dir():
                copy_tree(FALLBACK_SRC[slug], stage)
                note = "9/1上架包复用"
            else:
                gh_fetch_dir(slug, tok, stage)
                note = "GitHub拉取"
        except Exception as e:
            fail_rows.append((slug, "源获取失败: %s" % e))
            continue

        sk = stage / "SKILL.md"
        if not sk.exists():
            fail_rows.append((slug, "无 SKILL.md"))
            continue
        txt = sk.read_text(encoding="utf-8", errors="replace")
        fm, err = norm_frontmatter(txt, slug, "AI技能")
        if err:
            fail_rows.append((slug, err))
            continue
        sk.write_text(fm, encoding="utf-8", newline="\n")

        cat, ver = "AI技能", "1.0.0"
        for l in fm.split("\n")[:40]:
            if l.startswith("category:"):
                cat = l.split(":", 1)[1].strip()
            if l.startswith("version:"):
                ver = l.split(":", 1)[1].strip().strip('"')

        fails = fix_and_scan(stage, slug)
        if fails:
            fail_rows.append((slug, "; ".join(fails[:3])))
            shutil.rmtree(stage)
            continue

        make_license(stage)
        make_manifest(stage, slug, ver, cat)
        make_attestation(stage, slug)
        zip_dir(stage, OUT_ROOT / (slug + ".zip"), slug)
        ok_rows.append((slug, cat, ver, note))
        print("[OK] %-32s %s %s (%s)" % (slug, cat, ver, note))

    shutil.rmtree(OUT_ROOT / "_stage", ignore_errors=True)
    (OUT_ROOT / "_pack_result.json").write_text(
        json.dumps({"ok": ok_rows, "fail": fail_rows}, ensure_ascii=False, indent=2), encoding="utf-8")
    print("\n==== 完成: OK %d | FAIL %d ====" % (len(ok_rows), len(fail_rows)))
    for s, r in fail_rows:
        print("[FAIL] %s -> %s" % (s, r))


if __name__ == "__main__":
    main()
