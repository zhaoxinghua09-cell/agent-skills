import subprocess, json, urllib.request, urllib.parse

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
VAULT = "C:/Users/Administrator/.ucvault_local/vault.py"

def get_secret(label):
    r = subprocess.run([PY, VAULT, "get", label], capture_output=True, text=True)
    return r.stdout.strip()

def mask(s):
    if not s: return "<empty>"
    return s[:4] + "…" + s[-4:] if len(s) > 10 else "***"

print("=== 1) WeChat MP ===")
mp = get_secret("wechat_mp")
print("  raw type:", type(mp).__name__, "len:", len(mp))
# try parse appid:appsecret or json
appid = secret = None
try:
    d = json.loads(mp)
    appid, secret = d.get("appid"), d.get("appsecret")
except Exception:
    if ":" in mp:
        appid, secret = mp.split(":", 1)
print("  appid:", mask(appid) if appid else None, "secret:", mask(secret) if secret else None)
if appid and secret:
    url = f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={appid}&secret={secret}"
    try:
        with urllib.request.urlopen(url, timeout=30) as x:
            j = json.loads(x.read().decode())
        if "access_token" in j:
            print("  access_token OK, expires_in:", j.get("expires_in"))
        else:
            print("  MP token FAIL:", j)
    except Exception as e:
        print("  MP token ERR:", str(e)[:160])

print("=== 2) Gitee ===")
gitee = get_secret("gitee_api_key")
print("  token:", mask(gitee))
url = "https://gitee.com/api/v5/user"
req = urllib.request.Request(url, headers={"Authorization": f"token {gitee}"})
try:
    with urllib.request.urlopen(req, timeout=30) as x:
        j = json.loads(x.read().decode())
    print("  Gitee OK user:", j.get("login"), "id:", j.get("id"))
except Exception as e:
    print("  Gitee ERR:", str(e)[:160])

print("=== 3) AtomGit ===")
atom = get_secret("atomgit_api_key")
print("  token:", mask(atom))
for base in ["https://api.atomgit.com", "https://atomgit.com/api/v1", "https://atomgit.com/api/v5"]:
    try:
        req = urllib.request.Request(f"{base}/user", headers={"Authorization": f"token {atom}"})
        with urllib.request.urlopen(req, timeout=20) as x:
            j = json.loads(x.read().decode())
        print(f"  AtomGit OK ({base}):", j.get("username") or j.get("login") or j.get("name") or list(j.keys())[:3])
        break
    except Exception as e:
        print(f"  AtomGit ({base}) ERR:", str(e)[:120])
