# -*- coding: utf-8 -*-
"""Batch I → SkillHub 发布准备(干净副本 + 字段补全 + 权属五件套 + 敏感扫描)。
SkillHub CLI 拒收二进制(.png 等, 错误码 450033), 故发布副本剔除 icon.png/lgd-powered.png 及 _ 安装元数据。
不代发(本脚本只产出 staging + 终验); 实际 publish 由 _skillhub_publish_batchi.py 调用 skills_store_cli.py。
"""
import json
import os
import re
import shutil
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

SRC = Path("D:/Workbuddy/05-工具/agent-skills")
STAGE = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/SkillHub_BatchI_stage")
STAGE.mkdir(parents=True, exist_ok=True)

# SkillHub 平台类目英文 key (2026-08-28 实测)
CAT_MAP = {
    "医疗器械合规": "professional",
    "效率工具": "office-efficiency",
    "工程方法": "dev-programming",
    "安全合规": "it-ops-security",
}
SLUGS = ["udi-format-validator", "clin-eval-route-picker", "pmcf-plan-check",
         "md-link-audit", "changelog-draft-gen", "env-var-audit"]

EXCLUDE_DIRS = {"__pycache__", ".git", ".idea", ".vscode", "node_modules"}
EXCLUDE_SUFFIX = {".bak", ".pyc", ".log"}
EXCLUDE_NAMES = {".DS_Store", "Thumbs.db"}
# 二进制/安装元数据: SkillHub 拒收
EXCLUDE_BINARY = {".png", ".jpg", ".jpeg", ".gif", ".ico", ".exe", ".mp4", ".zip"}
EXCLUDE_META_PREFIX = ("_icon", "_meta", "_skillhub_meta")

AUTHOR = "zhaoxinghua09-cell"  # 与 GitHub/SkillPie 已上线口径一致(跨平台同名)
COPYRIGHT = "SynomosAI"        # LGD-Powered 家族版权归属
REPO = "zhaoxinghua09-cell/agent-skills"

# 敏感扫描 FAIL 形状(命中即拒)
FAIL_PATTERNS = [
    (r"赵兴华|Steven Zhao|xinghua06", "真名残留"),
    (r"C:\\Users|C:/Users|/c/Users|D:\\Workbuddy|D:/Workbuddy", "本地路径残留"),
    (r"\.ucvault|ucvault_local", "保险库路径残留"),
    (r"ghp_[A-Za-z0-9]{20,}|gho_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|sk-ant-|sk-proj-", "疑似密钥"),
    (r"provider-internal", "内部代号残留"),
]
EMAIL_OK = ("info@medxpert.cn", "example.com", "@github.com", "@users.noreply", "synomos.ai")
TEXT_EXT = {".md", ".txt", ".py", ".json", ".yaml", ".yml", ".sh", ".js", ".ts", ".html", ".css", ".svg"}


def copy_tree(src, dst):
    if dst.exists():
        shutil.rmtree(dst)
    dst.mkdir(parents=True, exist_ok=True)
    for root, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for f in files:
            p = Path(root) / f
            ext = p.suffix.lower()
            if ext in EXCLUDE_SUFFIX or f in EXCLUDE_NAMES:
                continue
            if ext in EXCLUDE_BINARY:
                continue
            if f.startswith(EXCLUDE_META_PREFIX):
                continue
            rel = p.relative_to(src)
            (dst / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dst / rel)


def norm_frontmatter(txt, slug):
    m = re.match(r"^---\n(.*?)\n---\n?(.*)$", txt, re.S)
    if not m:
        return None, "frontmatter 解析失败"
    fm, body = m.group(1), m.group(2)
    lines = fm.split("\n")
    out = []
    has = lambda k: any(l.startswith(k + ":") for l in lines)
    dn = next((l.split(":", 1)[1].strip().strip('"') for l in lines if l.startswith("display_name:")), slug)
    cat_cn = next((l.split(":", 1)[1].strip() for l in lines if l.startswith("category:")), "")
    cat_en = CAT_MAP.get(cat_cn, "professional")
    for l in lines:
        ls = l.strip()
        if ls.startswith("author:"):
            out.append("author: " + AUTHOR)
        elif ls.startswith("category:"):
            out.append("category: " + cat_en)
        elif ls.startswith("license:"):
            out.append("license: MIT")
        else:
            out.append(l)
        if ls.startswith("author:") and not has("copyright"):
            out.append("copyright: " + COPYRIGHT)
        if ls.startswith("display_name:") and not has("displayName") and not has("displayname"):
            out.append('displayName: "%s"' % dn)
        if ls.startswith("description:") and not has("summary"):
            d = ls.split(":", 1)[1].strip().strip('"')
            summ = d[:100]
            for cut in ("。", "；", ";"):
                if cut in summ:
                    summ = summ.split(cut)[0] + cut
                    break
            out.append('summary: "%s"' % summ.replace('"', "'"))
    if not has("license"):
        out.append("license: MIT")
    if not has("homepage"):
        out.append("homepage: https://github.com/%s/tree/main/skills/%s" % (REPO, slug))
    if not has("tags"):
        out.append("tags: [LGD-Powered, AI技能, %s, %s, SynomosAI]" % (cat_en, slug))
    return "---\n" + "\n".join(out) + "\n---\n" + body, None


def scan(stage, slug):
    fails = []
    for p in sorted(stage.rglob("*")):
        if not p.is_file() or p.suffix.lower() not in TEXT_EXT:
            continue
        txt = p.read_text(encoding="utf-8", errors="replace")
        for pat, label in FAIL_PATTERNS:
            if re.search(pat, txt):
                fails.append("%s: %s" % (label, p.relative_to(stage)))
        for em in re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", txt):
            if not any(ok in em.lower() for ok in EMAIL_OK):
                fails.append("白名单外邮箱 %s (%s)" % (em, p.relative_to(stage)))
    return fails


def make_license(stage):
    mit = """MIT License

Copyright (c) 2026 %s

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
""" % COPYRIGHT
    (stage / "LICENSE.md").write_text(mit, encoding="utf-8")


def make_manifest(stage, slug, ver, cat_en):
    man = {
        "schema": "lgd-skill-manifest/v1",
        "name": slug, "slug": slug, "version": ver,
        "author": AUTHOR, "copyright": COPYRIGHT, "license": "MIT",
        "category": cat_en,
        "origin": "https://github.com/%s/tree/main/skills/%s" % (REPO, slug),
        "homepage": "https://github.com/%s/tree/main/skills/%s" % (REPO, slug),
        "agent_created": True, "packaged_at": "2026-09-09",
    }
    (stage / "manifest.json").write_text(json.dumps(man, ensure_ascii=False, indent=2), encoding="utf-8")


def make_attestation(stage, slug):
    att = """# 权属与原创性声明 / ATTESTATION

- 技能: **%s**
- 署名: %s
- 版权与许可: © 2026 %s · MIT License
- 原创性: 本技能由 LGD-Powered 家族原创开发，非复制第三方作品；核心逻辑为原创实现。
- 零依赖: 仅使用语言标准库，无第三方运行时依赖（脚本类技能）。
- 安全自检: 已通过敏感信息扫描（无真名/本地路径/密钥/内部代号），发布闸门留痕。
- 权威源: https://github.com/%s/tree/main/skills/%s
- 打包日期: 2026-09-09
""" % (slug, AUTHOR, COPYRIGHT, REPO, slug)
    (stage / "ATTESTATION.md").write_text(att, encoding="utf-8")


def main():
    results = []
    for slug in SLUGS:
        src = SRC / slug
        stage = STAGE / slug
        if not (src / "SKILL.md").exists():
            results.append((slug, "FAIL", "源无 SKILL.md"))
            continue
        copy_tree(src, stage)
        sk = stage / "SKILL.md"
        txt = sk.read_text(encoding="utf-8")
        fm, err = norm_frontmatter(txt, slug)
        if err:
            results.append((slug, "FAIL", err))
            continue
        sk.write_text(fm, encoding="utf-8", newline="\n")
        ver = "1.0.0"
        for l in fm.split("\n")[:40]:
            if l.startswith("version:"):
                ver = l.split(":", 1)[1].strip().strip('"')
        cat_en = CAT_MAP.get(
            next((l.split(":", 1)[1].strip() for l in txt.split("\n") if l.startswith("category:")), ""),
            "professional")
        fails = scan(stage, slug)
        if fails:
            results.append((slug, "FAIL", "; ".join(fails[:3])))
            continue
        make_license(stage)
        make_manifest(stage, slug, ver, cat_en)
        make_attestation(stage, slug)
        # 文件清单核对
        files = sorted(str(p.relative_to(stage)) for p in stage.rglob("*") if p.is_file())
        print("[OK] %-22s files=%d %s" % (slug, len(files), cat_en))
        print("     " + ", ".join(files))
        results.append((slug, "OK", cat_en))
    print("\n==== 准备完成: %d OK / %d FAIL ====" % (
        sum(1 for _, s, _ in results if s == "OK"),
        sum(1 for _, s, _ in results if s == "FAIL")))
    for s, st, r in results:
        if st == "FAIL":
            print("[FAIL] %s -> %s" % (s, r))


if __name__ == "__main__":
    main()
