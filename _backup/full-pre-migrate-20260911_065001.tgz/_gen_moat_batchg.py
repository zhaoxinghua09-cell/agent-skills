# -*- coding: utf-8 -*-
"""Batch G：重要行业爆款十连发（金融4/区块链3/法律1/医疗健康1/数据出境1）
哨兵 replace 注入纪律（不用 .format，避免花括号坑）；脚本主体零依赖。
"""
import json
import os
import pathlib

BASE = pathlib.Path(__file__).resolve().parent
ICONS = ["C:/Windows/Fonts/msyh.ttc", "C:/Windows/Fonts/simhei.ttf", "C:/Windows/Fonts/arial.ttf"]

SKILLS = [
    {
        "slug": "loan-rate-disclosure", "snake": "loan_rate_disclosure",
        "dn_zh": "借贷利率披露校验器", "dn_en": "Loan Rate Disclosure Check",
        "domain": "金融", "law": "TH-LGD-015", "glyph": "¥",
        "desc": "校验借贷报价是否按年化口径披露、是否超基准利率4倍司法保护上限（零依赖）",
        "pain": "给AI/人工写借贷宣传时，不报年化、超4倍LPR红线，一眼翻车",
        "src": r'''
import argparse, json, sys

def main():
    ap = argparse.ArgumentParser(description="loan-rate-disclosure · 借贷年化利率披露校验（零依赖）")
    ap.add_argument("--rate", type=float, help="对外报价利率（百分比，如 24 表示 24%）")
    ap.add_argument("--base", type=float, default=3.85, help="参考基准利率LPR（百分比，默认3.85）")
    ap.add_argument("--text", help="披露文案（校验是否含年化口径）")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    if a.rate is None and not a.text:
        ap.error("至少提供 --rate 或 --text")
    problems, checks = [], []
    if a.text:
        ok = ("年化" in a.text)
        checks.append({"check": "披露含年化利率口径", "ok": ok})
        if not ok:
            problems.append("未按年化口径披露（监管要求明示年化利率）")
    if a.rate is not None:
        mult = a.rate / a.base if a.base else 0
        cap = 4 * a.base
        over = a.rate > cap
        checks.append({"check": "利率/基准倍数", "value": round(mult, 2), "cap_multiple": 4, "ok": not over})
        if over:
            problems.append("报价 %.2f%% 超过基准 %.2f%% 的4倍上限（%.2f%%），触及民间借贷司法保护上限风险" % (a.rate, a.base, cap))
    if a.json:
        print(json.dumps({"pass": not problems, "checks": checks, "problems": problems}, ensure_ascii=False, indent=2))
    else:
        for c in checks:
            mark = "  [PASS] " if c.get("ok") else "  [FAIL] "
            extra = "" if c.get("value") is None else "  = " + str(c["value"])
            print(mark + c["check"] + extra)
        print("  判定：" + ("PASS 可披露" if not problems else "FAIL 需整改"))
        for p in problems:
            print("    - " + p)
    sys.exit(1 if problems else 0)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "kyc-checklist-gen", "snake": "kyc_checklist_gen",
        "dn_zh": "KYC 材料齐备清单", "dn_en": "KYC Checklist Generator",
        "domain": "金融", "law": "TH-LGD-016", "glyph": "K",
        "desc": "一键生成个人/企业 KYC 必备材料清单并核算齐备度，缺项即 FAIL（零依赖）",
        "pain": "开户/接商户前不知道 KYC 要备什么材料，来回补件浪费时间",
        "src": r'''
import argparse, json, sys

LISTS = {
    "personal": ["身份证明（身份证/护照在有效期内）", "地址证明（近3个月账单）",
                 "职业与收入来源说明", "银行账户流水（视机构要求）", "税收居民身份声明（CRS）"],
    "corporate": ["营业执照与最新章程", "受益所有人（UBO）识别材料（持股≥25%）",
                  "法定代表人身份证明与授权委托书", "公司银行账户证明",
                  "业务实质与资金来源说明", "制裁名单与PEP筛查授权"],
}

def main():
    ap = argparse.ArgumentParser(description="kyc-checklist-gen · KYC 材料齐备清单（零依赖）")
    ap.add_argument("--type", choices=["personal", "corporate"], default="personal")
    ap.add_argument("--have", help="已具备材料编号，逗号分隔，如 1,2,3")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    items = LISTS[a.type]
    have = set()
    if a.have:
        for tok in a.have.split(","):
            tok = tok.strip()
            if tok.isdigit() and 1 <= int(tok) <= len(items):
                have.add(int(tok))
    missing = [i for i in range(1, len(items) + 1) if i not in have]
    score = round(100 * (len(items) - len(missing)) / len(items))
    if a.json:
        print(json.dumps({"type": a.type, "complete": not missing, "score": score,
                          "missing_no": missing, "missing": [items[i-1] for i in missing]},
                         ensure_ascii=False, indent=2))
    else:
        label = "个人" if a.type == "personal" else "企业"
        print("KYC 清单（%s）：%d/%d 齐备，完成度 %d%%" % (label, len(items) - len(missing), len(items), score))
        for i, it in enumerate(items, 1):
            print(("  [x] " if i in have else "  [ ] ") + str(i) + ". " + it)
        if missing:
            print("  判定：FAIL 缺 " + "、".join(str(i) for i in missing) + " 号材料")
        else:
            print("  判定：PASS 材料齐备")
    sys.exit(0 if not missing else 1)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "invoice-risk-scan", "snake": "invoice_risk_scan",
        "dn_zh": "发票要素风险扫描", "dn_en": "Invoice Risk Scan",
        "domain": "金融/财税", "law": "TH-LGD-017", "glyph": "票",
        "desc": "报销/入账前扫发票要素：税号格式、金额、日期合理性，异常即拦（零依赖）",
        "pain": "报销发票税号抄错一位、日期离谱，财务退单反复折腾",
        "src": r'''
import argparse, json, re, sys

TAXID = re.compile(r"^[0-9A-Z]{15}(?:[0-9A-Z]{3})?(?:[0-9A-Z]{2})?$")

def main():
    ap = argparse.ArgumentParser(description="invoice-risk-scan · 发票要素风险扫描（零依赖）")
    ap.add_argument("--taxid", help="销售方纳税人识别号")
    ap.add_argument("--amount", type=float, help="价税合计金额")
    ap.add_argument("--date", help="开票日期 YYYY-MM-DD")
    ap.add_argument("--kind", choices=["zhuan", "pu", "e"], default=None, help="专票/普票/电子")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    if a.taxid is None and a.amount is None and a.date is None:
        ap.error("至少提供 --taxid/--amount/--date 之一")
    problems, checks = [], []
    if a.taxid is not None:
        ok = bool(TAXID.match(a.taxid.strip()))
        checks.append({"check": "纳税人识别号格式(15/18/20位大写字母数字)", "ok": ok})
        if not ok:
            problems.append("税号格式不符：应为15/18/20位大写字母数字")
    if a.amount is not None:
        ok = a.amount > 0
        checks.append({"check": "金额为正", "ok": ok})
        if not ok:
            problems.append("金额必须大于0")
    if a.date is not None:
        ok = bool(re.match(r"^\d{4}-\d{2}-\d{2}$", a.date))
        if ok:
            y = int(a.date[:4])
            ok = 2000 <= y <= 2035
        checks.append({"check": "开票日期格式与年份合理", "ok": ok})
        if not ok:
            problems.append("日期需为 YYYY-MM-DD 且年份合理")
    if a.json:
        print(json.dumps({"pass": not problems, "checks": checks, "problems": problems}, ensure_ascii=False, indent=2))
    else:
        for c in checks:
            print(("  [PASS] " if c["ok"] else "  [FAIL] ") + c["check"])
        print("  判定：" + ("PASS" if not problems else "FAIL"))
        for p in problems:
            print("    - " + p)
    sys.exit(1 if problems else 0)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "fund-fee-calc", "snake": "fund_fee_calc",
        "dn_zh": "资管费率净收益试算器", "dn_en": "Fund Fee & Net Return Calc",
        "domain": "金融", "law": "TH-LGD-018", "glyph": "算",
        "desc": "试算管理/托管/销售三费总成本与净收益，宣传含保本承诺即 FAIL（零依赖）",
        "pain": "买产品只看收益率不看费率，宣传页说保本就信——资管新规明令禁止",
        "src": r'''
import argparse, json, sys

def main():
    ap = argparse.ArgumentParser(description="fund-fee-calc · 资管产品费率与净收益试算（零依赖）")
    ap.add_argument("--amount", type=float, required=True, help="本金")
    ap.add_argument("--mgmt", type=float, default=0.0, help="年管理费率(如0.015)")
    ap.add_argument("--custody", type=float, default=0.0, help="年托管费率")
    ap.add_argument("--sales", type=float, default=0.0, help="年销售服务费率")
    ap.add_argument("--years", type=float, default=1, help="持有年数")
    ap.add_argument("--yield", dest="yld", type=float, default=0.0, help="预期年化收益(仅演示)")
    ap.add_argument("--claim", help="宣传口径文本，如 保本保收益")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    if a.amount <= 0 or a.years <= 0:
        ap.error("--amount 与 --years 必须为正数")
    problems = []
    if a.claim:
        bad = [k for k in ("保本", "稳赚", "无风险", "保证收益") if k in a.claim]
        if bad:
            problems.append("宣传含" + "、".join(bad) + "——资管新规禁止保本保收益承诺")
    fee_rate = a.mgmt + a.custody + a.sales
    fees = a.amount * fee_rate * a.years
    gross = a.amount * a.yld * a.years
    net = gross - fees
    note = "预期收益仅为演示，不构成收益承诺；市场有风险，投资须谨慎"
    if a.json:
        print(json.dumps({"pass": not problems, "principal": a.amount,
                          "total_fee_rate_annual": round(fee_rate, 4), "total_fees": round(fees, 2),
                          "expected_gross": round(gross, 2), "expected_net": round(net, 2),
                          "note": note, "problems": problems}, ensure_ascii=False, indent=2))
    else:
        print("本金 %.2f · 年费率合计 %.2f%% · %g 年费用合计 %.2f" % (a.amount, fee_rate * 100, a.years, fees))
        print("演示口径预期毛收益 %.2f · 净收益 %.2f" % (gross, net))
        print("提示：" + note)
        for p in problems:
            print("  [FAIL] " + p)
        print("  判定：" + ("PASS" if not problems else "FAIL"))
    sys.exit(1 if problems else 0)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "wallet-address-check", "snake": "wallet_address_check",
        "dn_zh": "链上地址格式校验器", "dn_en": "Wallet Address Check",
        "domain": "区块链", "law": "TH-LGD-019", "glyph": "链",
        "desc": "转账前校验 EVM/BTC系/TRON 地址格式与链系归属，格式可疑即 FAIL（零依赖）",
        "pain": "转账手滑地址粘错链/抄错位，资产直接归零——先过一道格式门",
        "src": r'''
import argparse, json, re, sys

B58 = re.compile(r"^[1-9A-HJ-NP-Za-km-z]{26,35}$")
B32 = re.compile(r"^bc1[02-9ac-hj-np-z]{11,71}$")
HEX = re.compile(r"^0x[0-9a-fA-F]{40}$")

def main():
    ap = argparse.ArgumentParser(description="wallet-address-check · 链上地址格式校验（零依赖）")
    ap.add_argument("--address", required=True)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    addr = a.address.strip()
    chains, ok, notes = [], False, []
    if HEX.match(addr):
        chains.append("EVM(ETH/BSC/Polygon等)")
        if addr[2:].islower() or addr[2:].isupper():
            ok = True
        else:
            notes.append("EVM混合大小写属EIP-55校验和格式，本工具零依赖无法重算keccak，请用钱包软件复核后再转账")
    elif B32.match(addr):
        chains.append("Bitcoin(bech32/bc1)")
        ok = True
    elif B58.match(addr):
        if addr.startswith("T") and len(addr) == 34:
            chains.append("TRON(Base58)")
        else:
            chains.append("Bitcoin(Base58)等Base58系")
        ok = True
        notes.append("Base58地址未做双哈希校验和验证，大额转账请先小额试转")
    else:
        chains.append("无法识别")
        notes.append("格式不符合常见EVM/BTC系/TRON地址")
    masked = addr if len(addr) <= 12 else addr[:6] + "..." + addr[-4:]
    if a.json:
        print(json.dumps({"pass": ok, "address_masked": masked, "chains": chains, "notes": notes},
                         ensure_ascii=False, indent=2))
    else:
        print("地址：" + masked)
        print("链系：" + "、".join(chains))
        print("  判定：" + ("PASS 格式可接受" if ok else "FAIL 格式可疑，请勿直接转账"))
        for n in notes:
            print("    - " + n)
    sys.exit(0 if ok else 1)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "token-disclosure-check", "snake": "token_disclosure_check",
        "dn_zh": "代币信息披露检查器", "dn_en": "Token Disclosure Check",
        "domain": "区块链", "law": "TH-LGD-020", "glyph": "披",
        "desc": "白皮书/披露文案核查必备要素（总量/分配/锁仓/团队/风险提示），含收益承诺即 FAIL（零依赖）",
        "pain": "项目方披露缺斤少两还暗带保证收益话术，接不住监管也坑持有人",
        "src": r'''
import argparse, json, sys

REQUIRED = ["代币总量", "分配方案", "锁仓", "团队", "风险提示"]
PROMISE = ["保证收益", "稳赚", "保本", "翻倍", "无风险"]

def main():
    ap = argparse.ArgumentParser(description="token-disclosure-check · 代币信息披露完备性检查（零依赖）")
    ap.add_argument("--text", required=True, help="白皮书/披露文案全文或要点")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    t = a.text
    missing = [k for k in REQUIRED if k not in t]
    promised = [k for k in PROMISE if k in t]
    problems = []
    if missing:
        problems.append("缺少必备披露要素：" + "、".join(missing))
    if promised:
        problems.append("含收益承诺类表述（" + "、".join(promised) + "）——披露不得作收益保证")
    if a.json:
        print(json.dumps({"pass": not problems, "required": REQUIRED, "missing": missing,
                          "promise_hits": promised, "problems": problems}, ensure_ascii=False, indent=2))
    else:
        print("必备要素核查：")
        for k in REQUIRED:
            print(("  [x] " if k in t else "  [ ] ") + k)
        print("  判定：" + ("PASS 披露完备且无收益承诺" if not problems else "FAIL"))
        for p in problems:
            print("    - " + p)
    sys.exit(1 if problems else 0)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "contract-interact-checklist", "snake": "contract_interact_checklist",
        "dn_zh": "合约交互风险清单", "dn_en": "Contract Interact Checklist",
        "domain": "区块链", "law": "TH-LGD-021", "glyph": "签",
        "desc": "智能合约交互前六项风险自检（审计/地址/授权额度/撤销/私钥/小额试单），未完成即 FAIL（零依赖）",
        "pain": "无限授权、假合约、私钥贴网页——交互前没有一道标准自检流程",
        "src": r'''
import argparse, json, sys

ITEMS = ["已阅读合约源码或第三方审计报告", "确认目标地址与审计报告一致（防假合约）",
         "明确approve授权额度（拒绝无限授权）", "知悉授权可随时撤销及撤销Gas成本",
         "私钥/助记词离线保管，绝不输入任何网页", "大额操作先小额试交互"]

def main():
    ap = argparse.ArgumentParser(description="contract-interact-checklist · 智能合约交互前风险清单（零依赖）")
    ap.add_argument("--have", help="已完成项编号，逗号分隔，如 1,2,3")
    ap.add_argument("--approve", choices=["limited", "unlimited"], default=None)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    have = set()
    if a.have:
        for tok in a.have.split(","):
            tok = tok.strip()
            if tok.isdigit() and 1 <= int(tok) <= len(ITEMS):
                have.add(int(tok))
    missing = [i for i in range(1, len(ITEMS) + 1) if i not in have]
    problems = []
    if missing:
        problems.append("未完成项：" + "、".join(str(i) + ". " + ITEMS[i-1] for i in missing))
    if a.approve == "unlimited":
        problems.append("无限授权(unlimited approve)高危——建议改为按次限额授权")
    if a.json:
        print(json.dumps({"pass": not problems, "items": ITEMS, "missing_no": missing,
                          "problems": problems}, ensure_ascii=False, indent=2))
    else:
        for i, it in enumerate(ITEMS, 1):
            print(("  [x] " if i in have else "  [ ] ") + str(i) + ". " + it)
        print("  判定：" + ("PASS 可交互" if not problems else "FAIL 交互前需补齐"))
        for p in problems:
            print("    - " + p)
    sys.exit(1 if problems else 0)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "contract-clause-check", "snake": "contract_clause_check",
        "dn_zh": "合同高危条款扫描器", "dn_en": "Contract Clause Check",
        "domain": "法律", "law": "TH-LGD-022", "glyph": "法",
        "desc": "签合同前扫必备条款（违约/争议/管辖）与高危表述（最终解释权/自动续期/高违约金），缺项即 FAIL（零依赖）",
        "pain": "合同不看条款直接签，违约金30%、单方解释权、没写管辖全踩坑",
        "src": r'''
import argparse, json, re, sys

MUST = ["违约", "争议", "管辖"]
RISKY = [
    ("最终解释权", "单方保留最终解释权条款，多被认定无效且显失公平"),
    ("自动续期", "含自动续期/自动续约，注意退出窗口与通知期"),
    ("永久保密", "永久保密义务需评估对等性与期限合理性"),
    ("放弃诉讼", "放弃诉权类条款效力存疑，请律师复核"),
]

def main():
    ap = argparse.ArgumentParser(description="contract-clause-check · 合同高危条款扫描（零依赖）")
    ap.add_argument("--text", required=True, help="合同文本（可粘贴要点）")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    t = a.text
    problems, risky = [], []
    for k in MUST:
        if k not in t:
            problems.append("缺少必备条款关键词：" + k)
    for k, why in RISKY:
        if k in t:
            risky.append({"term": k, "why": why})
    penalty = re.search(r"违约金[^\d]{0,6}(\d{1,2}(?:\.\d+)?)\s*%", t)
    if penalty and float(penalty.group(1)) > 30:
        risky.append({"term": "违约金" + penalty.group(1) + "%", "why": "违约金超损失30%部分可能被法院调减（民法典585条）"})
    if a.json:
        print(json.dumps({"pass": not problems, "missing_must": problems, "risky": risky},
                         ensure_ascii=False, indent=2))
    else:
        print("必备条款：")
        for k in MUST:
            print(("  [x] " if k in t else "  [ ] ") + k)
        if risky:
            print("风险提示：")
            for r in risky:
                print("    - " + r["term"] + "：" + r["why"])
        print("  判定：" + ("PASS" if not problems else "FAIL 缺必备条款"))
        print("  免责：本工具为初筛，不构成法律意见，重要合同请律师复核。")
    sys.exit(1 if problems else 0)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "health-claim-guard", "snake": "health_claim_guard",
        "dn_zh": "健康宣称合规扫描", "dn_en": "Health Claim Guard",
        "domain": "医疗健康", "law": "TH-LGD-023", "glyph": "医",
        "desc": "保健品/食品宣传文案扫违规疗效宣称（根治/治愈/无副作用等），缺警示语即 FAIL（零依赖）",
        "pain": "带货文案随手写根治、有效率99%，广告法罚款动辄数十万",
        "src": r'''
import argparse, json, sys

BANNED = ["根治", "治愈", "疗效", "无副作用", "最安全", "包治", "药到病除", "彻底摆脱"]
NEED_NOTE = ("保健食品", "益生菌", "维生素", "鱼油", "蛋白粉")

def main():
    ap = argparse.ArgumentParser(description="health-claim-guard · 健康宣称合规扫描（零依赖）")
    ap.add_argument("--text", required=True, help="宣传文案")
    ap.add_argument("--kind", help="产品类别，如 保健食品")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    t = a.text
    hits = [k for k in BANNED if k in t]
    problems = []
    if hits:
        problems.append("违规宣称（涉疾病治疗/绝对化用语）：" + "、".join(hits))
    if a.kind and any(k in a.kind for k in NEED_NOTE):
        if "不能代替药物" not in t:
            problems.append("保健食品类宣传须含「本品不能代替药物」警示语")
    if a.json:
        print(json.dumps({"pass": not problems, "banned_hits": hits, "problems": problems},
                         ensure_ascii=False, indent=2))
    else:
        print("  判定：" + ("PASS 宣称合规" if not problems else "FAIL 需整改"))
        for p in problems:
            print("    - " + p)
        print("  依据：广告法/食品安全法禁止普通食品与保健食品宣称疾病预防治疗功能。")
    sys.exit(1 if problems else 0)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "data-export-check", "snake": "data_export_check",
        "dn_zh": "数据出境合规自检", "dn_en": "Data Export Check",
        "domain": "数据合规/政务", "law": "TH-LGD-024", "glyph": "境",
        "desc": "数据出境前五项义务自检（分级/单独同意/PIA/标准合同或安全评估/留痕），缺项即 FAIL（零依赖）",
        "pain": "用境外SaaS/云就等于数据出境，义务没走完就是监管风险",
        "src": r'''
import argparse, json, sys

ITEMS = [
    "数据分类分级完成（识别是否含个人信息/重要数据）",
    "取得个人单独同意（如涉个人信息）",
    "完成个人信息保护影响评估（PIA）并留存3年",
    "与境外接收方签订标准合同/通过安全评估（视门槛）",
    "留存出境记录与接收方合规承诺",
]

def main():
    ap = argparse.ArgumentParser(description="data-export-check · 数据出境合规自检（零依赖）")
    ap.add_argument("--have", help="已完成项编号，逗号分隔，如 1,2,3")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    have = set()
    if a.have:
        for tok in a.have.split(","):
            tok = tok.strip()
            if tok.isdigit() and 1 <= int(tok) <= len(ITEMS):
                have.add(int(tok))
    missing = [i for i in range(1, len(ITEMS) + 1) if i not in have]
    if a.json:
        print(json.dumps({"pass": not missing, "items": ITEMS, "missing_no": missing,
                          "missing": [ITEMS[i-1] for i in missing]}, ensure_ascii=False, indent=2))
    else:
        for i, it in enumerate(ITEMS, 1):
            print(("  [x] " if i in have else "  [ ] ") + str(i) + ". " + it)
        print("  判定：" + ("PASS 可进入出境流程" if not missing else "FAIL 未满足全部前置义务"))
        print("  依据：个人信息保护法第38-39条、数据出境安全评估办法、标准合同办法。")
    sys.exit(0 if not missing else 1)

if __name__ == "__main__":
    main()
''',
    },
]

SKILLMD = """---
name: __SLUG__
description: __DN__ — __DESC__
slug: __SLUG__
version: 1.0.0
display_name: __DN__
display_name_en: __DNEN__
agent_created: true
author: zhaoxinghua09-cell
license: MIT
category: AI 治理
platforms: [claude, codex, cursor, windsurf, workbuddy]
---

# __DN__ / __DNEN__

**__SLUG__** v1.0.0 · LGD 护城河家族 · 零依赖
域：__DOMAIN__ · 三律映射：__LAW__

## 痛点
__PAIN__

## 用法
```bash
python scripts/__SNAKE__.py --help
```
- 合规 PASS → rc=0；违规 FAIL → rc=1；用法错误 → rc=2
- 支持 --json 机器可读输出

## 免责
本工具为合规初筛辅助，不构成法律/投资/医疗意见；重要决策请咨询持牌专业人士。

## LGD 三律（有籍·有证·有门禁）
本技能是「LGD 三律」在 __DOMAIN__ 场景的落地件：让 AI 的每一次输出**有籍可查、有证可依、有门禁可控**。
"""

README = """# __DN__ / __DNEN__

> `__SLUG__` v1.0.0 · LGD Moat Family · Zero-dependency · Domain: __DOMAIN__ · Law-map: __LAW__

**中文**：__PAIN__ 一条命令完成初筛：合规 PASS（rc=0）/ 违规 FAIL（rc=1）/ 用法错误（rc=2），支持 `--json`。

**EN**: One-command pre-screening for __DOMAIN__. PASS (rc=0) / FAIL (rc=1) / usage error (rc=2). `--json` supported.

## Usage / 用法
```bash
python scripts/__SNAKE__.py --help
```

## Disclaimer / 免责
Screening aid only, not legal/investment/medical advice. / 合规初筛辅助，不构成专业意见。
"""

ICON_OLD = None  # placeholder

def make_icons(slug, glyph):
    from PIL import Image, ImageDraw, ImageFont
    NAVY, TEAL, WHITE = (11, 31, 58, 255), (20, 184, 166, 255), (255, 255, 255, 255)
    img = Image.new("RGBA", (512, 512), NAVY)
    d = ImageDraw.Draw(img)
    d.ellipse([36, 36, 476, 476], outline=TEAL, width=18)
    d.ellipse([76, 76, 436, 436], outline=(20, 184, 166, 90), width=6)
    font = None
    for p in ICONS:
        try:
            font = ImageFont.truetype(p, 210)
            break
        except Exception:
            continue
    if font is not None:
        try:
            bbox = d.textbbox((0, 0), glyph, font=font)
            w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
            d.text((256 - w / 2 - bbox[0], 256 - h / 2 - bbox[1]), glyph, font=font, fill=WHITE)
        except Exception:
            font = None
    if font is None:
        d.rectangle([196, 196, 316, 316], fill=TEAL)
    img.save(BASE / slug / "icon.png")
    badge = Image.new("RGBA", (256, 96), NAVY)
    b = ImageDraw.Draw(badge)
    b.rectangle([4, 4, 251, 91], outline=TEAL, width=6)
    f2 = None
    for p in ICONS:
        try:
            f2 = ImageFont.truetype(p, 40)
            break
        except Exception:
            continue
    txt = "LGD POWERED"
    if f2 is not None:
        try:
            bbox = b.textbbox((0, 0), txt, font=f2)
            w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
            b.text((128 - w / 2 - bbox[0], 48 - h / 2 - bbox[1]), txt, font=f2, fill=TEAL)
        except Exception:
            f2 = None
    if f2 is None:
        b.rectangle([40, 34, 216, 62], fill=TEAL)
    badge.save(BASE / slug / "lgd-powered.png")


def main():
    for s in SKILLS:
        d = BASE / s["slug"]
        (d / "scripts").mkdir(parents=True, exist_ok=True)
        (d / "scripts" / (s["snake"] + ".py")).write_text(s["src"].strip() + "\n", encoding="utf-8")
        md = (SKILLMD.replace("__SLUG__", s["slug"]).replace("__DN__", s["dn_zh"])
              .replace("__DNEN__", s["dn_en"]).replace("__DESC__", s["desc"])
              .replace("__DOMAIN__", s["domain"]).replace("__LAW__", s["law"])
              .replace("__PAIN__", s["pain"]).replace("__SNAKE__", s["snake"]))
        (d / "SKILL.md").write_text(md, encoding="utf-8")
        rm = (README.replace("__SLUG__", s["slug"]).replace("__DN__", s["dn_zh"])
              .replace("__DNEN__", s["dn_en"]).replace("__DOMAIN__", s["domain"])
              .replace("__LAW__", s["law"]).replace("__PAIN__", s["pain"])
              .replace("__SNAKE__", s["snake"]))
        (d / "README.md").write_text(rm, encoding="utf-8")
        make_icons(s["slug"], s["glyph"])
        print("built:", s["slug"])


if __name__ == "__main__":
    main()
