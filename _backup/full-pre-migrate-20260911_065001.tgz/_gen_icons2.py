# -*- coding: utf-8 -*-
"""生成 10 个新爆款技能的 512 图标（LGD 视觉系统 v2：藏青底 + 青绿强调）。"""
import pathlib
from PIL import Image, ImageDraw, ImageFont

OUT = pathlib.Path("D:/Workbuddy/05-工具/agent-skills")
NAVY = (11, 31, 58)        # #0B1F3A
TEAL = (20, 184, 166)      # #14B8A6
INK = (235, 240, 248)
RED = (220, 80, 80)
FONT = "C:/Windows/Fonts/msyh.ttc"

def font(sz):
    try:
        return ImageFont.truetype(FONT, sz)
    except Exception:
        return ImageFont.load_default()

def base():
    im = Image.new("RGBA", (512, 512), NAVY)
    d = ImageDraw.Draw(im)
    d.ellipse([18, 18, 494, 494], outline=TEAL, width=6)
    return im, d

def save(im, name):
    p = OUT / name / "icon.png"
    p.parent.mkdir(parents=True, exist_ok=True)
    im.convert("RGB").save(p, "PNG")
    print("saved", p)

# 1 agent-memory-keeper: 层叠记忆块
im, d = base()
for i,(y0,y1) in enumerate([(170,230),(240,300),(310,370)]):
    d.rectangle([150,y0,362,y1], outline=TEAL if i%2==0 else INK, width=5)
d.rectangle([200,150,312,200], fill=TEAL)
save(im, "agent-memory-keeper")

# 2 prompt-compressor: 漏斗/收敛箭头
im, d = base()
d.polygon([(170,170),(342,170),(300,250),(212,250)], outline=TEAL, width=6)
d.polygon([(212,270),(300,270),(280,350),(232,350)], outline=INK, width=6)
d.polygon([(232,370),(280,370),(262,430),(250,430)], fill=TEAL)
save(im, "prompt-compressor")

# 3 agent-redteam-kit: 盾 + 警示三角
im, d = base()
pts = [(256,120),(380,170),(380,300),(256,400),(132,300),(132,170)]
d.polygon(pts, outline=TEAL, width=8)
d.polygon([(256,200),(300,300),(212,300)], outline=RED, width=6)
d.line([(256,225),(256,270)], fill=RED, width=8)
d.ellipse([250,285,262,297], fill=RED)
save(im, "agent-redteam-kit")

# 4 doc-desens-scanner: 文档 + 遮罩条
im, d = base()
d.rectangle([165,140,347,380], outline=TEAL, width=6)
for y in (185,225,265,305,345):
    d.line([(190,y),(325,y)], fill=INK, width=4)
d.rectangle([190,250,325,290], fill=NAVY, outline=RED, width=4)
save(im, "doc-desens-scanner")

# 5 rag-grounding-guard: 链接环（溯源）
im, d = base()
d.ellipse([150,200,250,300], outline=TEAL, width=8)
d.ellipse([262,212,362,312], outline=INK, width=8)
d.line([(200,250),(312,262)], fill=TEAL, width=6)
d.ellipse([150,150,200,200], outline=RED, width=5)
save(im, "rag-grounding-guard")

# 6 multi-agent-conductor: 多节点连线
im, d = base()
nodes = [(256,160),(160,320),(352,320),(256,400)]
for (x,y) in nodes:
    d.ellipse([x-26,y-26,x+26,y+26], outline=TEAL, width=6, fill=NAVY)
for a in nodes[1:]:
    d.line([(256,160),a], fill=INK, width=4)
save(im, "multi-agent-conductor")

# 7 skill-quality-gate: 闸门 + 对勾
im, d = base()
d.rectangle([170,180,342,360], outline=TEAL, width=7)
d.line([(205,275),(245,320)], fill=TEAL, width=10)
d.line([(245,320),(320,225)], fill=TEAL, width=10)
save(im, "skill-quality-gate")

# 8 ai-policy-radar: 雷达同心圆 + 扫描
im, d = base()
for r in (60,110,160):
    d.ellipse([256-r,256-r,256+r,256+r], outline=TEAL if r==160 else INK, width=5)
d.polygon([(256,256),(256,110),(360,200)], fill=(20,184,166,90))
save(im, "ai-policy-radar")

# 9 agent-trace-audit: 时间线 + 留痕点
im, d = base()
d.line([(150,256),(362,256)], fill=TEAL, width=6)
for x in (170,230,290,350):
    d.ellipse([x-14,242,x+14,270], outline=INK, width=5)
d.ellipse([230,242,258,270], fill=TEAL)
save(im, "agent-trace-audit")

# 10 eval-bench-builder: 标尺
im, d = base()
d.rectangle([150,210,362,300], outline=TEAL, width=7)
for x in (170,210,250,290,330):
    d.line([(x,210),(x,240)], fill=INK, width=4)
d.line([(150,300),(362,300)], fill=TEAL, width=4)
save(im, "eval-bench-builder")

print("done 10 icons")
