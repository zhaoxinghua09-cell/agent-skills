import json, os, re, subprocess, zipfile, time, sys, shutil
from pathlib import Path

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
CLI = "C:/Users/Administrator/.skillhub/skills_store_cli.py"
ZIP_DIR = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/SkillHub上架包_81家族_20260908")
STAGE = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/SkillHub_81_stage_v2")
STAGE.mkdir(parents=True, exist_ok=True)
LOG = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/_sh_publish_81.log")

# 已上线（跳过）：81家族5 + Batch I 6
ALREADY = {
    "session-continuity-protocol","dpapi-local-vault","medxpert-brain-learning-memory",
    "agent-evolution","a3-law-operational",
    "udi-format-validator","clin-eval-route-picker","pmcf-plan-check",
    "md-link-audit","changelog-draft-gen","env-var-audit",
}
# 中文类目 -> skillhub 英文 key（2026-08-28 实测枚举）
CAT_MAP = {
    "AI 治理":"ai-agent","AI工程方法":"ai-agent","AI安全":"it-ops-security","AI合规":"ai-agent",
    "AI学习方法论":"knowledge-management","效率工具":"office-efficiency",
    "开发效率":"dev-programming","办公效率":"office-efficiency",
}
BAD_EXT = (".png",".jpg",".jpeg",".gif",".ico",".zip",".exe",".mp4",".bin")
# 精准敏感扫描：只拦真敏感数据（中文真名/本地绝对路径/真实密钥前缀/邮箱/手机号）；
# 品牌词(注册老炮/MedXpert/SynomosAI)、公开 GitHub URL、通用词(token/secret) 放行
SENS_RE = re.compile(
    r"(赵兴华|C:/Users|/Users/[\w]+|D:/Workbuddy|skh_[A-Za-z0-9]|sk-ent-[A-Za-z0-9]|AKIA[0-9A-Z]{16}"
    r"|[\w.]+@(?!medxpert\.cn)(?!skillhub\.cn)(?!example\.(?:com|org|net|cn))(?!test\.com)(?!localhost)[\w.]+\.(?:com|cn)"
    r"|1[3-9]\d{9})", re.I)
PHONE_RE = re.compile(r"1[3-9]\d{9}")

def _synthetic_phone(s):
    """合成/演示号判定：升序连号、降序连号、重复位 ≥4，或已知测试号 → 不是真实 PII。"""
    asc = sum(1 for a,b in zip(s, s[1:]) if ord(b)-ord(a) == 1)
    desc = sum(1 for a,b in zip(s, s[1:]) if ord(a)-ord(b) == 1)
    rep = cur = 1
    for a,b in zip(s, s[1:]):
        cur = cur+1 if a == b else 1
        rep = max(rep, cur)
    return asc >= 4 or desc >= 4 or rep >= 4 or s == "13800138000"

def log(msg):
    with open(LOG,"a",encoding="utf-8") as f:
        f.write(msg+"\n")
    print(msg)

def extract_clean(z, slug):
    pub = STAGE / slug
    # 全新暂存目录（每 slug 唯一，单次运行不重复），避免 rmtree 触发安全删除拦截
    pub.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(z) as zf:
        for n in zf.namelist():
            if n.endswith("/"):
                continue
            low = n.lower()
            if any(low.endswith(e) for e in BAD_EXT):
                continue
            if "__pycache__" in n or "/_" in n or n.startswith("_"):
                continue
            parts = [p for p in n.split("/") if p]
            if not parts:
                continue
            fname = parts[-1]
            # LICENSE(无扩展名) 平台拒收 -> 改名 LICENSE.md；若已有 LICENSE.md 则保留
            if fname == "LICENSE":
                lic_dir = pub / "/".join(parts[:-1])
                if (lic_dir / "LICENSE.md").exists():
                    continue
                parts[-1] = "LICENSE.md"
            tgt = pub / "/".join(parts)
            tgt.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(n) as src, open(tgt,"wb") as dst:
                dst.write(src.read())
    # 定位 SKILL.md，发布目录取其父目录（兼容任意嵌套深度）
    skill_files = list(pub.rglob("SKILL.md"))
    if not skill_files:
        return pub
    skill_files.sort(key=lambda p: len(p.parts))
    return skill_files[0].parent

def derive_description(txt):
    """从正文提取首个 H1 作为 description 兜底；找不到则回退到 slug 描述。"""
    for line in txt.splitlines():
        s = line.strip()
        if s.startswith("# "):
            return s[2:].strip()
    return None

def fix_frontmatter(pub, slug):
    sk = pub / "SKILL.md"
    if not sk.exists():
        return False, "no SKILL.md after extract"
    txt = sk.read_text(encoding="utf-8")
    m = re.match(r"^(---\s*\n)(.*?)(\n---)", txt, re.S)
    if not m:
        return False, "no frontmatter"
    pre, fm, post = m.group(1), m.group(2), m.group(3)
    fields = {}
    for line in fm.splitlines():
        if ":" in line and not line.startswith(" "):
            k,_,v = line.partition(":")
            fields[k.strip()] = v.strip().strip('"').strip("'")
    # 中文类目转英文
    cat = fields.get("category","")
    if cat in CAT_MAP:
        fields["category"] = CAT_MAP[cat]
    # description 补全：防止空值 / 裸 YAML 块指示符（>- / > / | 等）被平台拒收
    _desc = (fields.get("description") or "").strip().strip('"').strip("'")
    _block_markers = {">-", ">", ">+", "|", "|-", "|+"}
    if (not _desc) or (_desc in _block_markers) or _desc.startswith(">-") or _desc.startswith(">"):
        d = derive_description(txt)
        fields["description"] = d or f"{slug} — SynomosAI AI 治理/方法论技能（LGD-Powered）"
    # 补全字段
    fields.setdefault("name", slug)
    fields.setdefault("slug", slug)
    fields.setdefault("display_name", fields.get("displayName", fields.get("name", slug)))
    fields.setdefault("displayName", fields.get("display_name", slug))
    fields.setdefault("title", fields.get("displayName", slug))
    fields.setdefault("version", "1.0.0")
    fields.setdefault("license", "MIT")
    fields.setdefault("author", "诺声(Logos)@SynomosAI")
    if "platforms" not in fields:
        fields["platforms"] = "[skillhub, clawhub, skillpie]"
    if "tags" not in fields or not fields["tags"]:
        fields["tags"] = "[AI, 治理, 自动化, 合规]"
    # 按规范顺序写回
    order = ["name","slug","display_name","displayName","title","version","category","platforms","author","license","description","description_en","tags"]
    out = []
    for k in order:
        if k in fields:
            out.append(f"{k}: {fields[k]}")
    # 保留未列出的其他字段
    for k,v in fields.items():
        if k not in order:
            out.append(f"{k}: {v}")
    new_fm = "\n".join(out)
    sk.write_text(pre + new_fm + post + txt[m.end():], encoding="utf-8")
    return True, fields.get("category","")

def ensure_ownership(pub, slug, ver):
    # LICENSE.md
    lic = pub/"LICENSE.md"
    if not lic.exists():
        lic.write_text(
            "# MIT License\n\nCopyright (c) 2026 SynomosAI\n\n"
            "Permission is hereby granted, free of charge, to any person obtaining a copy...\n"
            "THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND.\n", encoding="utf-8")
    # manifest.json
    man = pub/"manifest.json"
    if not man.exists():
        manifest = {
            "name": slug, "version": ver, "author": "诺声(Logos)@SynomosAI",
            "license": "MIT", "copyright": "SynomosAI",
            "fingerprint_algorithm": "SHA-256",
        }
        man.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    # ATTESTATION.md
    att = pub/"ATTESTATION.md"
    if not att.exists():
        att.write_text(
            f"# 权属与发布证据 · {slug}\n\n"
            f"- 版本：{ver}\n- 著作权：©2026 SynomosAI（诺声 Logos）\n"
            "- 许可：MIT\n- 合成知识/方法论归 SynomosAI 所有，禁复制·转售·用于训练模型。\n"
            "- 本作品按「现状」(AS IS) 提供，不作任何明示或暗示担保，使用后果由使用者自负。\n",
            encoding="utf-8")

def sensitive_scan(pub):
    for root,_,files in os.walk(pub):
        for f in files:
            if f.lower().endswith((".md",".py",".json",".txt",".yaml",".yml")):
                p = os.path.join(root,f)
                try:
                    c = open(p,encoding="utf-8",errors="ignore").read()
                except Exception:
                    continue
                for m in SENS_RE.finditer(c):
                    tok = m.group(0)
                    if PHONE_RE.fullmatch(tok) and _synthetic_phone(tok):
                        continue  # 合成演示号，非真实 PII
                    return True, f"{f}: matched sensitive pattern"
    return False, ""

def publish_retry(pub, slug, ver):
    args = [PY, CLI, "publish", str(pub), "--version", ver,
            "--changelog", "81家族批量上架·质量优化版（剔二进制/英文类目/权属五件套）"]
    for attempt in range(4):
        try:
            r = subprocess.run(args, capture_output=True, text=True, timeout=180)
        except Exception as e:
            return False, f"EXC:{e}"
        out = (r.stdout + r.stderr)
        if "Published" in out or "skillId" in out:
            return True, out.strip()[-160:]
        if "already exists" in out or "已存在" in out or "冲突" in out:
            return True, "already_exists"
        if "过于频繁" in out or "429" in out or "频率" in out or "请求过于频繁" in out:
            time.sleep(120); continue
        return False, out.strip()[-300:]
    return False, "max_retry"

results = []
zips = sorted(ZIP_DIR.glob("*.zip"))
LIMIT = int(os.environ.get("SH_LIMIT", "0") or 0)
if LIMIT:
    zips = zips[:LIMIT]
total = len([z for z in zips if z.stem not in ALREADY])
done = 0
for z in zips:
    slug = z.stem
    if slug in ALREADY:
        results.append({"slug":slug,"status":"skip_already"})
        continue
    done += 1
    log(f"[{done}/{total}] === {slug} ===")
    pub = extract_clean(z, slug)
    ok, msg = fix_frontmatter(pub, slug)
    if not ok:
        log(f"  SKIP frontmatter: {msg}"); results.append({"slug":slug,"status":"err_fm","msg":msg}); continue
    ensure_ownership(pub, slug, "1.0.0")
    hit, sm = sensitive_scan(pub)
    if hit:
        log(f"  SKIP sensitive: {sm}"); results.append({"slug":slug,"status":"err_sensitive","msg":sm}); continue
    ok, pm = publish_retry(pub, slug, "1.0.0")
    log(f"  publish: ok={ok} {pm}")
    results.append({"slug":slug,"status":"ok" if ok else "err_pub","msg":pm})
    time.sleep(20)

ok_n = sum(1 for r in results if r.get("status") in ("ok",))
log(f"\nDONE. ok_publish={ok_n} total_target={total}")
Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/_sh_publish_81_result.json").write_text(
    json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")
