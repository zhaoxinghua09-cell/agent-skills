# -*- coding: utf-8 -*-
# _sh_upgrade_5.py — 5 个已上架低分技能的爆款补段升级（TRACK 弱项：antiPatternFaq/errorHandling/docQuality/stability）
# 策略：外科手术式补段（不全量重排，保留手工精修内容）；剔二进制+盾徽废弃族+__pycache__；徽章走 SVG 外链；bump 版本重发。
import json, os, re, shutil, subprocess, time, sys
from pathlib import Path

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
CLI = "C:/Users/Administrator/.skillhub/skills_store_cli.py"
GH = Path("D:/Workbuddy/2026-09-07-12-47-37/gh_repo_agent_skills/skills")
DOCX = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/SkillHub上架包/doc-extract")
STAGE = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/SkillHub_5_upgrade_v1")
STAGE.mkdir(parents=True, exist_ok=True)
LOG = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/_sh_upgrade_5.log")
RESULT = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/_sh_upgrade_5_result.json")
BADGE = "https://medxpert.cn/badge/powered/svg/lgd-powered-cn.svg"

SOURCES = {
    "a3-law-operational": GH/"a3-law-operational",
    "agent-evolution": GH/"agent-evolution",
    "dpapi-local-vault": GH/"dpapi-local-vault",
    "session-continuity-protocol": GH/"session-continuity-protocol",
    "doc-extract": DOCX,
}
CAT_MAP = {"AI治理":"ai-agent","AI工程":"ai-agent","AI安全":"it-ops-security",
           "安全工具":"it-ops-security","通用技能":"productivity","开发工具":"dev-programming"}

# ---- 敏感扫描（与 _sh_upgrade_81.py 修复版一致；不可 import 81 脚本——其主循环在模块级）----
SENS_RE = re.compile(
    r"(赵兴华|C:/Users|/Users/[\w]+|D:/Workbuddy|skh_[A-Za-z0-9]|sk-ent-[A-Za-z0-9]|AKIA[0-9A-Z]{16}"
    r"|[\w.]+@(?!medxpert\.cn)(?!skillhub\.cn)(?!example\.(?:com|org|net|cn))(?!test\.com)(?!localhost)[\w.]+\.(?:com|cn)"
    r"|1[3-9]\d{9})", re.I)
PHONE_RE = re.compile(r"1[3-9]\d{9}")

def _synthetic_phone(s):
    asc = sum(1 for a,b in zip(s, s[1:]) if ord(b)-ord(a) == 1)
    desc = sum(1 for a,b in zip(s, s[1:]) if ord(a)-ord(b) == 1)
    rep = cur = 1
    for a,b in zip(s, s[1:]):
        cur = cur+1 if a == b else 1
        rep = max(rep, cur)
    return asc >= 4 or desc >= 4 or rep >= 4 or s == "13800138000"

def sensitive_scan(pub):
    for root,_,files in os.walk(pub):
        for f in files:
            if f.lower().endswith((".md",".py",".json",".txt",".yaml",".yml")):
                p = os.path.join(root,f)
                try: c = open(p,encoding="utf-8",errors="ignore").read()
                except Exception: continue
                for m in SENS_RE.finditer(c):
                    tok = m.group(0)
                    if PHONE_RE.fullmatch(tok) and _synthetic_phone(tok):
                        continue
                    return True, f"{f}: matched sensitive pattern"
    return False, ""

def log(msg):
    with open(LOG,"a",encoding="utf-8") as f:
        f.write(msg+"\n")
    print(msg, flush=True)

def bump_version(v):
    m = re.match(r"(\d+)\.(\d+)\.(\d+)", str(v).strip().strip('"\''))
    if not m: return "1.1.0"
    return f"{m.group(1)}.{int(m.group(2))+1}.0"

def stage_copy(slug, src):
    pub = STAGE/slug
    if pub.exists(): shutil.rmtree(pub, ignore_errors=True)
    shutil.copytree(src, pub,
        ignore=shutil.ignore_patterns("__pycache__","*.pyc",".git*",
            "icon.*","lgd-avatar.png","lgd-shield-*",".DS_Store"))
    # LICENSE 无扩展名 → SkillHub 拒收；重命名
    lic = pub/"LICENSE"
    if lic.exists() and not (pub/"LICENSE.md").exists():
        lic.rename(pub/"LICENSE.md")
    return pub

def read_md(p):
    return p.read_text(encoding="utf-8")

def write_md(p, t):
    p.write_text(t, encoding="utf-8")

def fix_frontmatter(pub, slug):
    md_path = pub/"SKILL.md"
    txt = read_md(md_path)
    m = re.match(r"^---\n(.*?)\n---\n", txt, re.S)
    if not m:
        return None, None
    fm = m.group(1)
    fields = {}
    for line in fm.splitlines():
        km = re.match(r"^([A-Za-z_]+):\s*(.*)$", line)
        if km: fields[km.group(1)] = km.group(2).strip()
    ver = bump_version(fields.get("version","1.0.0"))
    # 类目英文化（SkillHub 平台约定）
    cat = fields.get("category","")
    new_fm = fm
    if cat in CAT_MAP:
        new_fm = re.sub(rf"^category:\s*{re.escape(cat)}\s*$", f"category: {CAT_MAP[cat]}", new_fm, flags=re.M)
    # version 覆写
    new_fm = re.sub(r"^version:\s*.*$", f'version: "{ver}"', new_fm, flags=re.M)
    # slug 兜底
    if "slug" not in fields:
        new_fm += f"\nslug: {slug}"
    txt = txt.replace(fm, new_fm, 1)
    write_md(md_path, txt)
    return ver, fields.get("name")

TAIL_PAT = re.compile(r"^## .*(版权|许可|免责|Disclaimer|署名|License|©)", re.M)

def has_section(body, kw):
    return re.search(rf"^## .*{kw}", body, re.M) is not None

def upgrade_body(pub, slug, ver):
    md_path = pub/"SKILL.md"
    txt = read_md(md_path)
    m = re.match(r"^(---\n.*?\n---\n)(.*)$", txt, re.S)
    fm, body = (m.group(1), m.group(2)) if m else ("", txt)
    new_sections = []

    # ① 能力边界（仅缺边界类段落的包）
    if not has_section(body,"边界") and not has_section(body,"红线") and not has_section(body,"禁止") and not has_section(body,"何时不用"):
        new_sections.append(BOUNDARY.get(slug,""))

    # ② 错误处理 / 退出码
    if not has_section(body,"错误") and not has_section(body,"退出码") and not has_section(body,"失败"):
        new_sections.append(ERRORS.get(slug,""))

    # ③ 反模式 FAQ（核心弱项）
    if not has_section(body,"FAQ"):
        new_sections.append(FAQS.get(slug,""))

    insert = "\n".join(s for s in new_sections if s)

    # ④ 插入位置：版权/许可/署名段之前；无则文末
    tail_m = TAIL_PAT.search(body)
    if tail_m:
        body = body[:tail_m.start()] + insert + "\n" + body[tail_m.start():]
    else:
        body = body.rstrip() + "\n\n" + insert + "\n"

    # ⑤ LGD 徽章 + 安装矩阵（幂等）
    if BADGE not in body:
        footer = f"\n---\n\n[![LGD-Powered · 凡自治之物]({BADGE})](https://medxpert.cn)\n\n> © 2026 SynomosAI（诺声 Logos 署名体系）· MIT License · 按现状（AS IS）提供，不作任何明示或暗示担保\n"
        body = body.rstrip() + "\n" + INSTALL_MATRIX.format(slug=slug) + footer
    write_md(md_path, fm + body)

BOUNDARY = {
"a3-law-operational": """## 能力边界
- 不做：代替评审本身——判定树只回答"是否进入 A³ 评审"，评审由人或治理 agent 执行。
- 不做：替代平台自带权限与安全策略；A³ 是叠加治理层，不是替代层。
- 不做：存储敏感明文；评分卡与复盘记录只保留判定结论与证据引用。
- 受监管/高风险决策：A³ 评审通过 ≠ 合规批准，监管事项必须转人工签核。""",

"session-continuity-protocol": """## 能力边界
- 不做：自动改写用户记忆/档案内容——开局回灌只读；写路径（补充种子）须用户确认。
- 不做：保证 localmem 语义召回 100% 命中——纯中文概念查询召回偏弱是已知短板，兜底靠文件层 SSOT。
- 不做：跨账号自动同步——跨账号以共享盘文件为唯一真源，粘贴 _SYNC_OPENING.md 全文即生效。
- 不做：替代用户决策——连续性回灌只还原事实，不替用户拍板。""",

"agent-evolution": "",  # 已有「红线」段
"dpapi-local-vault": "",  # 已有「何时不用」段
"doc-extract": "",  # 已有「禁止行为」段
}

ERRORS = {
"dpapi-local-vault": """## 退出码与错误输出
| 场景 | 输出 | 退出码 | 处置 |
|---|---|---|---|
| 取回时 label 不存在 | `NOT_FOUND: <vault路径>` | 2 | 先用 store_secret.py 写入，或核对 label 拼写 |
| 写入时 stdin 为空 | `MISSING_INPUT` | 2 | 检查管道输入：两行 = id+key，一行 = 单值 |
| 跨机器/换用户解密失败 | DPAPI 异常（非零退出） | ≠0 | DPAPI 绑定当前 Windows 用户+机器；跨机需提前导出，未导出不可恢复（设计内行为） |
| --show 与 --raw 混淆 | --show 输出带 `value: ` 前缀（人读格式） | 0 | 脚本取值必须用 `--raw`（裸值），禁止对 --show 输出做字符串截取 |""",

"doc-extract": """## 错误处理与失败模式
| 失败模式 | 表现 | 处置 |
|---|---|---|
| 加密文档 | zipfile 抛 RuntimeError / 请求口令 | 先解密再抽取，勿硬解析 |
| 图片型 PDF / 扫描件 | 抽出正文为空 | 走 OCR 路线；本工具只处理文本层 |
| 超大文件 | 内存/耗时超限 | 按页（PDF）/按节（Office）分段抽取，设置超时上限 |
| 复杂合并单元格表格 | 表格错位 | 先转 CSV 核对边界，再交给下游消费 |""",

"a3-law-operational": """## 失败模式与处置
| 失败模式 | 判定 | 处置 |
|---|---|---|
| 判定树歧义（动作落在两分支之间） | 无法明确归类"造/改 AI" | 一律按"进入评审"处理（保守原则） |
| 评分卡某维缺数据 | 意图/影响/可逆性/监督任一维无法评分 | 该维按最保守档计分，并在复盘标注数据缺口 |
| 复盘缺证据 | 事后无法还原当时评分依据 | 标记"证据不足"，不强行归因；把证据留存纳入下次事前清单 |""",

"agent-evolution": """## 失败模式与处置
| 失败模式 | 判定 | 处置 |
|---|---|---|
| SkillManage 写入失败 | 技能创建/修改报错 | 降级写入 memory 并标注「待固化」，下次复盘优先补 |
| 查重失败（无法确认经验是否已沉淀） | 技能目录/记忆检索超时 | 手动 grep 技能目录确认后再写入 |
| 经验既非动作型也非信息型 | 一句话判据不适用 | 丢弃，不强行沉淀（防注水） |""",

"session-continuity-protocol": """## 失败模式与处置
| 失败模式 | 表现 | 处置 |
|---|---|---|
| localmem 召回为空 | search_memory 无结果 | 立即改读文件层 SSOT（_ACTIVE_PROJECTS.md / _SYNC_OPENING.md） |
| 文件层 SSOT 缺失 | 真源文件不存在 | 请用户粘贴 _SYNC_OPENING.md 或提供项目根路径 |
| 召回结果与文件层冲突 | 语义记忆 vs 文件记录不一致 | 以文件层为准，并把不一致当面摆清给用户 |""",
}

FAQS = {
"a3-law-operational": """## 反模式 FAQ
**Q：日常调用子 agent 也算"造/改 AI"吗？**
不算。只读查询、执行既定流程、不改变 agent 能力边界的日常调用不触发。凡涉及写系统提示词、改工具清单、改权限边界、改变自主度的动作，都算"造/改 AI"，必须进评审。

**Q：四维评分卡全过，事后还是出事故了？**
事前评估不豁免事后复盘。复盘要回溯是哪一维判分失真，修订的是阈值和评分依据，而不是无脑加审批层。

**Q：父 agent 已过评审，子 agent 还要再过吗？**
同类动作不重复评审；但子 agent 擅自扩大动作范围（改权限/改提示词）时必须重新进评审。

**Q：紧急情况来不及过三关怎么办？**
"先斩后奏"仅限可逆动作，且事后 24 小时内必须补复盘；不可逆动作没有豁免通道。""",

"agent-evolution": """## 反模式 FAQ
**Q：复盘写成流水账算固化吗？**
不算。固化产物必须是可复用的规则/技能/检查项。"下次注意"不是沉淀，是敷衍。

**Q：什么进 skill、什么进 memory？**
一句话判据：新会话能否直接照做。能照做的步骤/脚本/流程 → SkillManage（动作型）；只是事实/偏好/状态 → memory（信息型）。

**Q：同一条经验被反复沉淀多次怎么办？**
先查重（技能名+关键词），已存在就修订原文而不是新建，防技能库碎片化。

**Q：一次排错的过程能直接固化成技能吗？**
不能只记这一次的命令行。排错结论要泛化成"判据+处置"才够格进 skill；不满足泛化条件的进 memory。""",

"dpapi-local-vault": """## 反模式 FAQ
**Q：换电脑/重装系统后解不开了，是 bug 吗？**
不是，是设计内行为。DPAPI 绑定当前 Windows 用户+机器；跨机迁移必须提前导出，没导出就不可恢复。

**Q：能把保险库目录放进网盘同步吗？**
密文 blob 可以同步做灾备存档，但跨机器解不开（见上条）。别指望网盘当跨机传输通道。

**Q：--show 输出直接给脚本解析为什么出错？**
--show 是人读格式，带 `value: ` 前缀；脚本取值必须用 --raw。禁止对 --show 输出做字符串截取。

**Q：多脚本并发读写同一凭据安全吗？**
读操作无竞争；写操作（store/rotate）要串行，轮换时先禁用旧 key 再写入新 key。""",

"session-continuity-protocol": """## 反模式 FAQ
**Q：localmem 语义召回搜不到想要的上下文？**
纯中文概念查询召回偏弱是已知短板。不要盲信召回结果，立即改读文件层 SSOT。

**Q：文件层和 localmem 召回冲突听谁的？**
文件层优先（真源层级设计如此）；localmem 只是兜底，冲突时以文件为准并把不一致摆给用户。

**Q：新会话上来就说"我不知道"行不行？**
不行，违反本协议。必须先跑开局四步再回答；答不出先读 SSOT，禁止直接答"不知道"。

**Q：种子越写越多怎么办？**
定期蒸馏：30 天前的日志按主题合并进 MEMORY.md，重复种子修订合并，不新建。""",

"doc-extract": """## 反模式 FAQ
**Q：抽取出来是乱码/空内容？**
先判断文档类型：加密件需要口令；图片型扫描件没有文本层，要走 OCR。不要对硬骨头做无效重试。

**Q：超大文件直接读会怎样？**
容易内存超限/卡死。按页/按节分段抽取，设置超时上限。

**Q：提取的表格为什么错位？**
复杂合并单元格直接抽文本流会丢列对齐信息；先转 CSV 核对边界再消费。

**Q：抽取的原文会被上传或记日志吗？**
不会。全程本机解析零云依赖；不要把完整原文写入日志或外发，交付只保留用户要的片段。""",
}

INSTALL_MATRIX = """## 安装与使用矩阵
| 宿主 | 安装位置 | 方式 |
|---|---|---|
| Claude Code / CodeBuddy | `~/.claude/skills/{slug}/` | 复制本目录即可 |
| OpenCode | `~/.config/opencode/skills/{slug}/` | 复制本目录即可 |
| 通用 Agent Skill 加载器 | `~/.agents/skills/{slug}/` | 复制本目录即可 |"""

def ensure_ownership(pub, slug, ver):
    lic = pub/"LICENSE.md"
    if not lic.exists():
        lic.write_text("MIT License\n\nCopyright (c) 2026 SynomosAI\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the \"Software\"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:\n\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\n", encoding="utf-8")
    man = pub/"manifest.json"
    data = {}
    if man.exists():
        try: data = json.loads(man.read_text(encoding="utf-8"))
        except Exception: data = {}
    data.update({"name": slug, "version": ver, "author": "潘布达 (Buda Pan) @SynomosAI",
                 "license": "MIT", "ownership": "SynomosAI", "fingerprint_algorithm": "SHA-256"})
    man.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    att = pub/"ATTESTATION.md"
    att.write_text(
        f"# 权属与发布证据 · {slug}\n\n"
        f"- 版本：{ver}\n- 著作权：©2026 SynomosAI（诺声 Logos）\n"
        "- 许可：MIT\n- 合成知识/方法论归 SynomosAI 所有，禁复制·转售·用于训练模型。\n"
        "- 本作品按「现状」(AS IS) 提供，不作任何明示或暗示担保，使用后果由使用者自负。\n",
        encoding="utf-8")

def publish_retry(pub, slug, ver, attempt_ver):
    args = [PY, CLI, "publish", str(pub), "--version", attempt_ver,
            "--changelog", "爆款优化·补反模式FAQ+错误处理/失败模式+能力边界+LGD徽章+安装矩阵（评测弱项修复）"]
    for attempt in range(4):
        try:
            r = subprocess.run(args, capture_output=True, text=True, timeout=180)
        except Exception as e:
            return False, f"EXC:{e}", attempt_ver
        out = (r.stdout + r.stderr)
        if "Published" in out or "skillId" in out:
            return True, out.strip()[-160:], attempt_ver
        if "already exists" in out or "已存在" in out or "冲突" in out:
            return "exists", out.strip()[-120:], attempt_ver
        if "过于频繁" in out or "429" in out or "频率" in out:
            time.sleep(120); continue
        return False, out.strip()[-300:], attempt_ver
    return False, "max_retry", attempt_ver

results = []
for slug, src in SOURCES.items():
    log(f"=== {slug} ===")
    if not src.exists():
        log(f"  SKIP missing source: {src}"); results.append({"slug":slug,"status":"err_src"}); continue
    pub = stage_copy(slug, src)
    ver, _ = fix_frontmatter(pub, slug)
    if not ver:
        log(f"  SKIP frontmatter fail"); results.append({"slug":slug,"status":"err_fm"}); continue
    ensure_ownership(pub, slug, ver)
    upgrade_body(pub, slug, ver)
    hit, sm = sensitive_scan(pub)
    if hit:
        log(f"  SKIP sensitive: {sm}"); results.append({"slug":slug,"status":"err_sensitive","msg":sm}); continue
    if os.environ.get("SH_DRY"):
        log(f"  DRY: upgraded v{ver} -> {pub}"); results.append({"slug":slug,"status":"dry","ver":ver}); continue
    attempt_ver = ver
    for round_i in range(3):  # 版本冲突时自动再 bump 一次重试
        ok, pm, used = publish_retry(pub, slug, ver, attempt_ver)
        if ok is True:
            log(f"  publish v{used}: ok=True {pm}"); results.append({"slug":slug,"status":"ok","ver":used,"msg":pm}); break
        if ok == "exists":
            log(f"  v{used} already_exists -> bump retry")
            attempt_ver = bump_version(used); continue
        log(f"  publish v{used}: ok=False {pm}"); results.append({"slug":slug,"status":"err_pub","ver":used,"msg":pm}); break
    else:
        log(f"  publish: version conflict persists"); results.append({"slug":slug,"status":"err_verconflict"})
    time.sleep(20)

ok_n = sum(1 for r in results if r.get("status")=="ok")
log(f"\nDONE. ok_publish={ok_n} total={len(results)}")
RESULT.write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")
