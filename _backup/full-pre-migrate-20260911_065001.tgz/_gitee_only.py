# -*- coding: utf-8 -*-
"""仅补推 Gitee（vault token，header 不内联 URL）。"""
import base64, json, pathlib, subprocess, urllib.request, urllib.error

BASE = pathlib.Path("D:/Workbuddy/05-工具/agent-skills")
VAULT_PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
SLUGS = ["lgd-three-laws-auditor", "lgd-certify", "agent-output-registry", "evidence-chain-builder"]
TOK = subprocess.run([VAULT_PY, "get", "gitee_api_key"], capture_output=True, text=True).stdout.strip()
HEAD = {"User-Agent": "moat-push", "Accept": "application/json"}

def call(method, path, data=None):
    # Gitee v5：access_token 走查询参数(GET)/请求体(PUT)，不进 URL 路径，避免明文泄漏
    url = f"https://gitee.com/api/v5/repos/stevenzhao26/agent-skills/contents/{path}"
    if method == "GET":
        url += f"?access_token={TOK}"
    body = json.dumps(data).encode() if data else None
    if data is not None:
        data = dict(data); data["access_token"] = TOK
        body = json.dumps(data).encode()
    req = urllib.request.Request(url, data=body, headers=HEAD, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.status, json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        return e.code, {"error": e.read().decode(errors="replace")[:240]}

def gh_files(slug):
    fs = ["SKILL.md", "README.md", "icon.png", "lgd-powered.png"]
    fs += [f"scripts/{p.name}" for p in (BASE/slug/"scripts").glob("*.py")]
    return fs

cnt = 0
for slug in SLUGS:
    for f in gh_files(slug):
        local = BASE/slug/f
        st0, cur = call("GET", f"skills/{slug}/{f}")
        sha = cur.get("sha") if isinstance(cur, dict) else None
        data = {"message": f"add {slug}/{f} (LGD moat skills)", "content": base64.b64encode(local.read_bytes()).decode()}
        if sha: data["sha"] = sha
        st, _ = call("PUT", f"skills/{slug}/{f}", data)
        cnt += st in (200, 201)
        print(f"  [{'OK' if st in (200,201) else 'FAIL'}] {st} skills/{slug}/{f}")
for f in ["README.md", "lgd-powered.png"]:
    local = BASE/f
    st0, cur = call("GET", f)
    sha = cur.get("sha") if isinstance(cur, dict) else None
    data = {"message": f"update {f} (LGD moat skills index)", "content": base64.b64encode(local.read_bytes()).decode()}
    if sha: data["sha"] = sha
    st, _ = call("PUT", f, data)
    cnt += st in (200, 201)
    print(f"  [{'OK' if st in (200,201) else 'FAIL'}] {st} {f}")
print("Gitee 推送文件数：", cnt)
