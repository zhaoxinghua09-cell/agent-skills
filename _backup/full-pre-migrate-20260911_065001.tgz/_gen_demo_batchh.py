# -*- coding: utf-8 -*-
"""Batch H 演示卡生成器：10 款效率工具真机演示终端卡
每卡 = 临时沙箱 + 真实命令 + 真实输出渲染（绝不做假输出）。
VI 铁律：藏青 #0B1F3A + 青绿 #14B8A6，徽章只用定版 lgd-powered.png，不自创。
"""
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile

from PIL import Image, ImageDraw, ImageFont

sys.stdout.reconfigure(encoding="utf-8")

BASE = pathlib.Path(__file__).resolve().parent
PY = sys.executable
OUT = pathlib.Path("D:/Workbuddy/05-工具/宣传资产/demo-cards")
OUT.mkdir(parents=True, exist_ok=True)

NAVY = (11, 31, 58)
NAVY_D = (7, 22, 42)
TEAL = (20, 184, 166)
GREY = (110, 126, 148)
LGREY = (214, 224, 236)
IVORY = (245, 240, 229)
DIM = (120, 138, 160)
PAPER = (247, 246, 242)
PAPER_D = (236, 235, 228)
INK = (23, 42, 66)
DOTS = [(255, 95, 87), (254, 188, 46), (40, 200, 64)]

MSYH = "C:/Windows/Fonts/msyh.ttc"
MSYHB = "C:/Windows/Fonts/msyhbd.ttc"
CONS = "C:/Windows/Fonts/consola.ttf"
CONSB = "C:/Windows/Fonts/consolab.ttf"
BADGE = pathlib.Path("D:/Workbuddy/08-理论体系/发布/徽章kit/VI套件_20260907/LGD无字圆徽_标准头像_512.png")
REPO = "github.com/zhaoxinghua09-cell/agent-skills"

CJK = re.compile(r"[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]")

W, H = 1240, 780
TX0, TX1 = 92, W - 92          # 终端内文字区
MAX_OUT_LINES = 12


def f_msyh(sz, b=False):
    return ImageFont.truetype(MSYHB if b else MSYH, sz)


def f_cons(sz, b=False):
    return ImageFont.truetype(CONSB if b else CONS, sz)


def sh(slug, snake, args, cwd, stdin=None):
    r = subprocess.run([PY, str(BASE / slug / "scripts" / (snake + ".py"))] + list(args),
                       capture_output=True, text=True, input=stdin,
                       encoding="utf-8", cwd=str(cwd))
    return (r.stdout or "").strip("\n")


# ---------------- 沙箱场景 ----------------
def setup_photos(d):
    for c in "abc":
        (d / ("shot_%s.jpg" % c)).write_text("x", encoding="utf-8")


def setup_docs(d):
    (d / "合同扫描件.txt").write_text("same-content-here", encoding="utf-8")
    (d / "合同备份.txt").write_text("same-content-here", encoding="utf-8")
    (d / "会议纪要.txt").write_text("different!", encoding="utf-8")


def setup_downloads(d):
    for n in ["发票.png", "报告.pdf", "素材.zip", "录音.mp3", "安装包.exe"]:
        (d / n).write_text("x", encoding="utf-8")


def setup_proj(d):
    sub = d / "node_modules" / "cache"
    sub.mkdir(parents=True)
    (d / "model.bin").write_bytes(b"\0" * (3 * 1024 * 1024))
    (d / "数据集.csv").write_bytes(b"\0" * (512 * 1024))
    (sub / "chunk.dat").write_bytes(b"\0" * (256 * 1024))


def setup_json(d):
    (d / "data.json").write_text('{"b":1,"a":[1,2],"c":{"z":true,"y":null}}', encoding="utf-8")


def setup_csv(d):
    (d / "users.csv").write_text(
        "name,city,age\n张三,北京,30\n李四,上海,25\n王五,北京,40\n", encoding="utf-8")


def setup_notes(d):
    nd = d / "notes"
    nd.mkdir()
    (nd / "周报.md").write_text("本周上线 old v1 版本，old v1 已验证。", encoding="utf-8")
    (nd / "待办.md").write_text("没有匹配内容", encoding="utf-8")


def setup_article(d):
    (d / "article.txt").write_text(
        "人工智能正在改变世界。人工智能与治理是关键。\n治理先行，合规先行。", encoding="utf-8")


SCENARIOS = [
    {"slug": "batch-renamer", "cn": "批量重命名", "tag": "文件管理",
     "one": "前缀 / 序号 / 查找替换，先预览再执行",
     "cmds": [[["--dir", "photos", "--start", "1"]]],
     "setup": setup_photos, "cwd": "photos"},
    {"slug": "dup-finder", "cn": "重复文件查找", "tag": "文件管理",
     "one": "三级哈希（大小→首块→SHA-1），秒级找出冗余副本",
     "cmds": [[["--dir", "docs"]]],
     "setup": setup_docs, "cwd": "docs"},
    {"slug": "dir-organizer", "cn": "目录整理", "tag": "文件管理",
     "one": "把杂乱目录按类型归到 图片 / 文档 / 音频… 子目录",
     "cmds": [[["--dir", "downloads"]]],
     "setup": setup_downloads, "cwd": "downloads"},
    {"slug": "disk-scan", "cn": "磁盘占用分析", "tag": "空间治理",
     "one": "Top N 大文件 + 子目录排行，定位空间杀手",
     "cmds": [[["--dir", "proj", "--top", "5"]]],
     "setup": setup_proj, "cwd": "proj"},
    {"slug": "json-tidy", "cn": "JSON 整理", "tag": "数据处理",
     "one": "格式化 / 压缩 / 键排序，报错精确定位到行列",
     "cmds": [[["data.json", "--sort"]]],
     "setup": setup_json, "cwd": "."},
    {"slug": "csv-slice", "cn": "CSV 切片", "tag": "数据处理",
     "one": "取列 / 筛选 / 去重 / 计数，不用打开 Excel",
     "cmds": [[["--file", "users.csv", "--cols", "1,2", "--where", "2=北京"]]],
     "setup": setup_csv, "cwd": "."},
    {"slug": "text-replace", "cn": "跨文件替换", "tag": "文本处理",
     "one": "字面量或正则批量替换，自动 .bak 备份",
     "cmds": [[["--glob", "notes/*.md", "--old", "old v1", "--new", "new v2"]]],
     "setup": setup_notes, "cwd": "."},
    {"slug": "text-stats", "cn": "文本统计", "tag": "文本处理",
     "one": "字数 / 词频 TopN / 阅读时长，目录批量汇总",
     "cmds": [[["--file", "article.txt", "--top", "3"]]],
     "setup": setup_article, "cwd": "."},
    {"slug": "regex-sandbox", "cn": "正则沙盒", "tag": "文本处理",
     "one": "正则即写即测：匹配 / 分组 / 替换，先看后用",
     "cmds": [[["--pattern", r"(\d{4})-(\d{2})", "--text", "2026-09-08 and 2025-01-01", "--replace", r"\2/\1"]]],
     "setup": None, "cwd": None},
    {"slug": "hash-check", "cn": "哈希校验", "tag": "完整性",
     "one": "目录 SHA-256 清单生成 / 校验，防篡改验交付",
     "cmds": [["gen", "--dir", "release"], ["check", "--dir", "release"]],
     "setup": None, "cwd": None},
]


def display_cmd(snake, args):
    parts = ["python %s.py" % snake]
    for a in args:
        if a.startswith("--") or a in ("gen", "check"):
            parts.append(a)
        else:
            v = a
            if not (v.startswith("photos") or v.startswith("docs") or v.startswith("downloads")
                    or v.startswith("proj") or v.startswith("notes") or v.startswith("release")
                    or v.endswith(".json") or v.endswith(".csv") or v.endswith(".txt")
                    or v.endswith(".md") or "=" in v or v.isdigit()):
                v = '"%s"' % v
            parts.append(v)
    return " ".join(parts)


def draw_mixed(d, xy, text, mono_f, cjk_f, fill):
    """中英混排绘制：非 CJK 用等宽字体，CJK 段切雅黑。"""
    x, y = xy
    buf = ""
    buf_cjk = False

    def flush():
        nonlocal x, buf
        if buf:
            f = cjk_f if buf_cjk else mono_f
            d.text((x, y), buf, font=f, fill=fill)
            x += d.textlength(buf, font=f)
            buf = ""

    for ch in text:
        is_c = bool(CJK.search(ch))
        if buf and is_c != buf_cjk:
            flush()
        buf += ch
        buf_cjk = is_c
    flush()


def wrap_cmd(d, text, fnt, maxw):
    """命令过长时按空格折行。返回行列表。"""
    words = text.split(" ")
    lines, cur = [], ""
    for wd in words:
        trial = (cur + " " + wd).strip()
        if d.textlength(trial, font=fnt) <= maxw or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = "  " + wd
    if cur:
        lines.append(cur)
    return lines


def trim_line(d, text, fnt, maxw):
    if d.textlength(text, font=fnt) <= maxw:
        return text
    while text and d.textlength(text + "…", font=fnt) > maxw:
        text = text[:-1]
    return text + "…"


def render_card(sc, blocks, path):
    """blocks: [ (kind, text) ]  kind in {'cmd','out'}"""
    img = Image.new("RGB", (W, H), PAPER)
    d = ImageDraw.Draw(img)
    for y in range(H):
        t = y / H
        c = tuple(int(PAPER[i] + (PAPER_D[i] - PAPER[i]) * t) for i in range(3))
        d.line([(0, y), (W, y)], fill=c)
    d.rectangle([0, 0, W, 6], fill=TEAL)

    # ---- 头部 ----
    d.rectangle([70, 44, 84, 76], fill=TEAL)
    d.text((102, 40), sc["cn"], font=f_msyh(34, True), fill=INK)
    tw = d.textlength(sc["slug"], font=f_cons(20))
    d.text((W - 78 - tw, 52), sc["slug"], font=f_cons(20), fill=GREY)
    d.text((102, 88), "%s ｜ %s" % (sc["tag"], sc["one"]), font=f_msyh(20), fill=GREY)

    # ---- 终端窗 ----
    tTop, tBot = 138, 660
    for y in range(tTop, tBot):
        t = (y - tTop) / (tBot - tTop)
        c = tuple(int(NAVY[i] + (NAVY_D[i] - NAVY[i]) * t) for i in range(3))
        d.line([(60, y), (W - 60, y)], fill=c)
    d.rounded_rectangle([60, tTop, W - 60, tBot], radius=14, outline=NAVY_D, width=2)
    # 标题栏
    for i, col in enumerate(DOTS):
        d.ellipse([88 + i * 26, tTop + 14, 100 + i * 26, tTop + 26], fill=col)
    ttl = "终端 · Windows / macOS / Linux 通用"
    tw = d.textlength(ttl, font=f_msyh(15))
    d.text(((W - tw) / 2, tTop + 13), ttl, font=f_msyh(15), fill=DIM)
    d.line([60, tTop + 40, W - 60, tTop + 40], fill=(30, 52, 84), width=1)

    # ---- 内容 ----
    y = tTop + 58
    lh = 26
    shown = 0
    omitted = 0
    for kind, text in blocks:
        if shown >= MAX_OUT_LINES:
            omitted += 1
            continue
        if kind == "cmd":
            lines = wrap_cmd(d, text, f_cons(17), TX1 - TX0 - 16)
            for i, ln in enumerate(lines):
                if shown >= MAX_OUT_LINES:
                    omitted += 1
                    continue
                if i == 0:
                    d.text((TX0, y), "$", font=f_cons(17, True), fill=TEAL)
                draw_mixed(d, (TX0 + 20, y), ln, f_cons(17), f_msyh(16),
                           IVORY if i == 0 else (198, 210, 224))
                y += lh
                shown += 1
            y += 4
        else:
            fnt = f_msyh(16) if CJK.search(text) else f_cons(16)
            d.text((TX0 + 20, y), trim_line(d, text, fnt, TX1 - TX0 - 20), font=fnt, fill=LGREY)
            y += lh
            shown += 1
    if omitted:
        d.text((TX0 + 20, y), "…（其余 %d 行略）" % omitted, font=f_msyh(15), fill=DIM)

    # ---- 页脚 ----
    if BADGE.exists():
        b = Image.open(BADGE).convert("RGBA").resize((36, 36), Image.LANCZOS)
        img.paste(b, (60, H - 74), b)
        d.text((108, H - 67), "LGD-Powered · 全程治理论", font=f_msyh(17), fill=GREY)
    tw = d.textlength(REPO, font=f_cons(16))
    d.text((W - 60 - tw, H - 68), REPO, font=f_cons(16), fill=GREY)

    img.save(path, "PNG")


def main():
    tmp = tempfile.mkdtemp(prefix="batchh_demo_")
    done = 0
    try:
        for sc in SCENARIOS:
            slug, snake = sc["slug"], sc["slug"].replace("-", "_")
            # 沙箱：cwd 恒为 tmp 根，目标子目录由 setup 创建
            cwd = pathlib.Path(tmp)
            if sc["setup"]:
                if sc["cwd"] == ".":
                    sc["setup"](cwd)
                else:
                    sd = cwd / sc["cwd"]
                    sd.mkdir(exist_ok=True)
                    sc["setup"](sd)
            elif slug == "hash-check":
                rd = cwd / "release"
                rd.mkdir(exist_ok=True)
                (rd / "app_v1.0.zip").write_bytes(b"PK\x03\x04" + os.urandom(64))
                (rd / "checksums.txt").write_text("app_v1.0.zip\n", encoding="utf-8")

            blocks = []
            for args_list in sc["cmds"]:
                if args_list and isinstance(args_list[0], list):  # 兼容多余嵌套
                    args_list = args_list[0]
                out = sh(slug, snake, args_list, cwd)
                blocks.append(("cmd", display_cmd(snake, args_list)))
                ol = [l for l in out.split("\n") if l.strip()]
                blocks.extend(("out", l) for l in ol)
                blocks.append(("out", ""))
            if blocks and blocks[-1][1] == "":
                blocks.pop()

            p = OUT / ("%s_demo_1240x780.png" % slug)
            render_card(sc, blocks, p)
            done += 1
            print("[OK] %s -> %s" % (slug, p.name))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("完成 %d/10 张" % done)


if __name__ == "__main__":
    main()
