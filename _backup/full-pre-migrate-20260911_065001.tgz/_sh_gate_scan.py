# -*- coding: utf-8 -*-
"""
_sh_gate_scan.py — SkillHub 发布闸门敏感扫描器（独立版，禁止 import 流水线脚本！）

用法:
  python _sh_gate_scan.py <包目录或暂存根目录> [更多目录...]
    - 传入包目录(含 SKILL.md): 扫该包
    - 传入暂存根目录: 自动扫其下每个子目录(视为一个包)

规则与 _sh_upgrade_81.py / _sh_stage_publish_81.py 中的 SENS_RE 保持同步。
血泪教训: _sh_upgrade_81.py 主循环在模块顶层，import 即触发发布！
本脚本自包含规则，永远不要 import 流水线脚本。
"""
import os
import re
import sys

SENS_RE = re.compile(
    r"(赵兴华|C:/Users|/Users/[\w]+|D:/Workbuddy|skh_[A-Za-z0-9]|sk-ent-[A-Za-z0-9]|AKIA[0-9A-Z]{16}"
    r"|[\w.]+@(?!medxpert\.cn)(?!skillhub\.cn)(?!example\.(?:com|org|net|cn))(?!test\.com)(?!localhost)[\w.]+\.(?:com|cn)"
    r"|1[3-9]\d{9})", re.I)
PHONE_RE = re.compile(r"1[3-9]\d{9}")


def _synthetic_phone(s):
    """合成/演示号判定：升序连号、降序连号、重复位 ≥4，或已知测试号 → 不是真实 PII。"""
    asc = sum(1 for a, b in zip(s, s[1:]) if ord(b) - ord(a) == 1)
    desc = sum(1 for a, b in zip(s, s[1:]) if ord(a) - ord(b) == 1)
    rep = cur = 1
    for a, b in zip(s, s[1:]):
        cur = cur + 1 if a == b else 1
        rep = max(rep, cur)
    return asc >= 4 or desc >= 4 or rep >= 4 or s == "13800138000"


def sensitive_scan(pub):
    """扫描单个包目录，返回 (hit:bool, msg:str)。扫描 .md/.py/.json/.txt/.yaml/.yml。"""
    for root, _, files in os.walk(pub):
        for f in files:
            if f.lower().endswith((".md", ".py", ".json", ".txt", ".yaml", ".yml")):
                p = os.path.join(root, f)
                try:
                    c = open(p, encoding="utf-8", errors="ignore").read()
                except Exception:
                    continue
                for m in SENS_RE.finditer(c):
                    tok = m.group(0)
                    if PHONE_RE.fullmatch(tok) and _synthetic_phone(tok):
                        continue  # 合成演示号，非真实 PII
                    return True, f"{f}: matched sensitive pattern"
    return False, ""


def main():
    targets = sys.argv[1:]
    if not targets:
        print("用法: python _sh_gate_scan.py <包目录或暂存根目录> [更多...]")
        return 2
    total_hit = 0
    pkgs = 0
    for t in targets:
        t = os.path.abspath(t)
        if not os.path.isdir(t):
            print(f"[warn] 不存在或非目录，跳过: {t}")
            continue
        # 判断是"包目录"还是"暂存根目录"
        if os.path.exists(os.path.join(t, "SKILL.md")):
            cands = [t]
        else:
            cands = sorted(os.path.join(t, d) for d in os.listdir(t))
            cands = [c for c in cands if os.path.isdir(c)]
            # 若子目录是 <slug>/<slug> 嵌套结构，剥一层
            flat = []
            for c in cands:
                if os.path.exists(os.path.join(c, "SKILL.md")):
                    flat.append(c)
                else:
                    inner = sorted(os.path.join(c, d) for d in os.listdir(c))
                    flat += [i for i in inner if os.path.isdir(i) and os.path.exists(os.path.join(i, "SKILL.md"))]
            cands = flat
        for pub in cands:
            pkgs += 1
            slug = os.path.basename(pub)
            hit, msg = sensitive_scan(pub)
            total_hit += hit
            print(f"{slug}: {'❌ HIT - ' + msg if hit else '✅ clean'}")
    print(f"\nTOTAL: {pkgs} 包, {total_hit} 命中")
    return 1 if total_hit else 0


if __name__ == "__main__":
    sys.exit(main())
