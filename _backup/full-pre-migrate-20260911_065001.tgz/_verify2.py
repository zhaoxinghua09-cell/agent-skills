import subprocess, json, urllib.request, urllib.parse, re

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
VAULT = "C:/Users/Administrator/.ucvault_local/vault.py"

def get_secret(label):
    r = subprocess.run([PY, VAULT, "get", label], capture_output=True, text=True)
    return r.stdout.strip()

def mask(s):
    return s[:4] + "…" + s[-4:] if len(s) > 10 else "***"

print("=== WeChat MP (regex parse) ===")
mp = get_secret("wechat_mp")
appid = re.search(r"wx[0-9a-fA-F]{16}", mp)
secret = re.search(r"[0-9a-fA-F]{32}", mp)
appid = appid.group(0) if appid else None
secret = secret.group(0) if secret else None
print("  appid:", appid, "secret:", mask(secret) if secret else None)
if appid and secret:
    url = f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={appid}&secret={secret}"
    try:
        with urllib.request.urlopen(url, timeout=30) as x:
            j = json.loads(x.read().decode())
        if "access_token" in j:
            print("  access_token OK expires_in:", j.get("expires_in"))
            open("D:/Workbuddy/05-工具/agent-skills/.mp_token", "w").write(j["access_token"])
        else:
            print("  MP token FAIL:", j)
    except Exception as e:
        print("  MP token ERR:", str(e)[:160])

print("=== AtomGit (auth styles) ===")
atom = get_secret("atomgit_api_key")
print("  token:", mask(atom))
paths = ["/api/v5/user", "/api/v5/user/info", "/api/v1/user"]
styles = [
    ("token", lambda t: {"Authorization": f"token {t}"}),
    ("Bearer", lambda t: {"Authorization": f"Bearer {t}"}),
    ("query", None),
]
for base in ["https://atomgit.com"]:
    for p in paths:
        for name, hdr in styles:
            if name == "query":
                u = f"{base}{p}?access_token={urllib.parse.quote(atom)}"
                h = {}
            else:
                u = f"{base}{p}"
                h = hdr(atom)
            try:
                req = urllib.request.Request(u, headers=h)
                with urllib.request.urlopen(req, timeout=15) as x:
                    j = json.loads(x.read().decode())
                print(f"  OK base={base} path={p} auth={name} ->", j.get("username") or j.get("login") or j.get("name") or list(j.keys())[:3])
                raise SystemExit
            except SystemExit:
                break
            except Exception as e:
                print(f"  ERR {base}{p} auth={name}:", str(e)[:80])
