---
name: ai-reply-heuristics
description: ai-reply-heuristics — 启发式估计一段文字的 AI 痕迹强度：套话密度/破折号频率/句长均匀度/排比结构 → 0-100 分与三档区间（启发式，不构成判定，附免责）。
slug: ai-reply-heuristics
version: 1.0.0
display_name: AI痕迹启发式检查器
display_name_en: AI Reply Heuristics
agent_created: true
author: 诺声(Logos)@SynomosAI
license: MIT
category: AI 治理
platforms: [claude-code, codebuddy, workbuddy, openai-agents]
copyright: SynomosAI
---
# AI痕迹启发式检查器（AI Reply Heuristics）

LGD 广谱爆款系列：把"有籍·有证·有门禁"做成人人天天用得上的工具。

## 解决什么痛点

收到一篇『不知道是不是 AI 写的』文字：全文照信有风险，全盘怀疑也不公平——需要一个提示器而非审判器。

## 功能

启发式估计一段文字的 AI 痕迹强度：套话密度/破折号频率/句长均匀度/排比结构 → 0-100 分与三档区间（启发式，不构成判定，附免责）。

## 用法

见 `scripts/` 下脚本 `--help`。零依赖（stdlib only），Windows/Linux/macOS 均可运行。

## 对应理论

- LGD-II 有证（出处存疑要有提示） · 域码 TH-LGD-010

## 免责声明

本工具为治理辅助框架，口径以监管官方最新文本为准，不构成法律意见。

---
© MedXpert × SynomosAI · LGD-Powered

## 安装与使用矩阵

```bash
# 一键获取（skills CLI）
npx skills add zhaoxinghua09-cell/agent-skills -g

# 或手动：克隆后拷贝本技能到你的 Agent 技能目录
git clone https://github.com/zhaoxinghua09-cell/agent-skills.git
cp -r agent-skills/skills/ai-reply-heuristics ~/.claude/skills/
```

| Agent | 技能目录 | 运行示例 |
|---|---|---|
| Claude Code | `~/.claude/skills/ai-reply-heuristics/` | 让 Claude 按本技能 SKILL.md 工作流调用 `scripts/` |
| Codex CLI / Cursor / WorkBuddy | 各自 skills 目录 | 同上，SKILL.md 即操作规程 |
| 直接命令行 | 任意位置 | `python scripts/ai_reply_heuristics.py --help` |
