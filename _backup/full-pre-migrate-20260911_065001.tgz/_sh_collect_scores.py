import json, subprocess, os
from pathlib import Path

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
CLI = "C:/Users/Administrator/.skillhub/skills_store_cli.py"

SLUGS = [
    # 81-family 已传(5)
    "session-continuity-protocol","dpapi-local-vault","medxpert-brain-learning-memory","agent-evolution","a3-law-operational",
    # Batch I 已传(6)
    "udi-format-validator","clin-eval-route-picker","pmcf-plan-check","md-link-audit","changelog-draft-gen","env-var-audit",
    # 25 医械 MCP 候选（测是否真上线+有评测）
    "reg-calc","reg-path","udi-check","vigil-timer","med-glossary","samd-classifier","ai-dsf-change","intended-use-check",
    "pccp-planner","eu-ai-act-check","clin-evidence","eu-clin-eval","data-card","ai-transparency","device-classifier",
    "risk-14971","pms-planner","iso13485-audit","design-control","device-retire","secure-vault","desens-scan","leak-sentinel","web-fetch-pro","doc-extract",
]

def walk_scores(o, acc):
    if isinstance(o, dict):
        for k, v in o.items():
            if k == "score" and isinstance(v, (int, float)):
                acc.append(v)
            walk_scores(v, acc)
    elif isinstance(o, list):
        for v in o:
            walk_scores(v, acc)

out = []
for s in SLUGS:
    rec = {"slug": s, "evaluated": False}
    raw = None
    for ns in [None, "user_8a3569c1"]:
        args = [PY, CLI, "skill", "evaluation", s, "--json"]
        if ns:
            args += ["--namespace", ns]
        try:
            r = subprocess.run(args, capture_output=True, text=True, timeout=30)
            if r.returncode == 0 and r.stdout.strip():
                d = json.loads(r.stdout)
                ev = d.get("evaluation")
                if ev and ev.get("dimensions"):
                    raw = d; rec["ns"] = ns; break
        except Exception as e:
            rec["exc"] = str(e)
    if raw:
        ev = raw["evaluation"]
        scores = []
        walk_scores(ev, scores)
        rec["overall"] = round(sum(scores)/len(scores), 2) if scores else None
        rec["n_items"] = len(scores)
        rec["evaluated"] = True
        rec["dim_avgs"] = {dn: (round(sum(it["score"] for it in dv.get("items",{}).values() if isinstance(it,dict) and "score" in it)/max(1,len([1 for it in dv.get("items",{}).values() if isinstance(it,dict) and "score" in it])),2)) for dn,dv in ev.get("dimensions",{}).items() if isinstance(dv,dict)}
    out.append(rec)

print("=== 有评测分 ===")
for r in out:
    if r["evaluated"]:
        flag = "<4.6 需优化" if (r.get("overall") or 9) < 4.6 else "ok(>=4.6)"
        print(f'{r["slug"]:32} 总分={r.get("overall")} 维数={r.get("n_items")} ns={r.get("ns")} {flag}')
print("\n=== 无评测/未上线 ===")
for r in out:
    if not r["evaluated"]:
        print(r["slug"], "->", r.get("ns") or "无namespace命中", "| exc:", r.get("exc",""))

Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/_sh_scores.json").write_text(
    json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
print("\nwrote _sh_scores.json")
