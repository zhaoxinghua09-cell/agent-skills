# -*- coding: utf-8 -*-
"""通过 GitHub Contents API 推送 10 个新技能到 zhaoxinghua09-cell/agent-skills/skills/。
密钥经 vault.py 在子进程内获取，绝不进入对话/打印。"""
import base64, json, pathlib, subprocess, urllib.request

VAULT_PY = "C:/Users/Administrator/.ucvault_local/vault.py"
PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
OWNER = "zhaoxinghua09-cell"
REPO = "agent-skills"
BRANCH = "main"
BASE = pathlib.Path("D:/Workbuddy/05-工具/agent-skills")

TOKEN = subprocess.run([PY, VAULT_PY, "get", "github_api_key"], capture_output=True, text=True).stdout.strip()
HEAD = {"Authorization": f"Bearer {TOKEN}", "Accept": "application/vnd.github+json",
        "User-Agent": "agent-skills-push", "X-GitHub-Api-Version": "2022-11-28"}

def api(method, url, data=None):
    req = urllib.request.Request(url, data=json.dumps(data).encode() if data else None, headers=HEAD, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return resp.status, json.loads(resp.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        return e.code, {"error": e.read().decode(errors="replace")[:300]}

st, me = api("GET", "https://api.github.com/user")
print("connectivity:", st, me.get("login", me.get("error", "")))
if st != 200:
    raise SystemExit(1)

def put_file(gh_path, content_bytes):
    url = f"https://api.github.com/repos/{OWNER}/{REPO}/contents/{gh_path}"
    st0, cur = api("GET", url)
    sha = cur.get("sha") if st0 == 200 else None
    body = base64.b64encode(content_bytes).decode()
    data = {"message": f"add {gh_path} (agent-skills hit skills batch2)", "content": body, "branch": BRANCH}
    if sha:
        data["sha"] = sha
    st, resp = api("PUT", url, data)
    ok = st in (200, 201)
    print(f"  {'OK' if ok else 'FAIL'} {st} {gh_path}")
    return ok

skills = {
    "agent-memory-keeper": "scripts/memory_audit.py",
    "prompt-compressor": "scripts/compress_prompt.py",
    "agent-redteam-kit": "scripts/redteam_scan.py",
    "doc-desens-scanner": "scripts/desens_scan.py",
    "rag-grounding-guard": "scripts/grounding_check.py",
    "multi-agent-conductor": "scripts/conductor_plan.py",
    "skill-quality-gate": "scripts/quality_gate.py",
    "ai-policy-radar": "scripts/policy_radar.py",
    "agent-trace-audit": "scripts/trace_audit.py",
    "eval-bench-builder": "scripts/bench_build.py",
}
count = 0
for slug, script in skills.items():
    for f in ["SKILL.md", "README.md", "icon.png", "lgd-powered.png", script]:
        local = BASE / slug / f
        gh = f"skills/{slug}/{f}"
        if f.endswith(".png"):
            if put_file(gh, local.read_bytes()): count += 1
        else:
            if put_file(gh, local.read_text(encoding="utf-8").encode("utf-8")): count += 1
print(f"\n推送完成文件数：{count}")
