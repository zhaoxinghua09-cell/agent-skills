import subprocess, json, re, os, urllib.request, uuid

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
VAULT = "C:/Users/Administrator/.ucvault_local/vault.py"
BASE = os.path.dirname(os.path.abspath(__file__))
TOKEN_FILE = os.path.join(BASE, ".mp_token")

def get_secret(label):
    return subprocess.run([PY, VAULT, "get", label], capture_output=True, text=True).stdout.strip()

def get_token():
    raw = get_secret("wechat_mp")
    appid = re.search(r"wx[0-9a-fA-F]{16}", raw).group(0)
    secret = re.search(r"[0-9a-fA-F]{32}", raw).group(0)
    if os.path.exists(TOKEN_FILE):
        t = open(TOKEN_FILE).read().strip()
        try:
            with urllib.request.urlopen(f"https://api.weixin.qq.com/cgi-bin/getcallbackip?access_token={t}", timeout=15) as x:
                if json.loads(x.read().decode()).get("errcode", 0) == 0:
                    return t
        except Exception:
            pass
    with urllib.request.urlopen(f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={appid}&secret={secret}", timeout=30) as x:
        t = json.loads(x.read().decode())["access_token"]
    open(TOKEN_FILE, "w").write(t)
    return t

TOKEN = get_token()
print("token len", len(TOKEN))

def mp_raw(path, data_bytes, ctype="application/json; charset=utf-8"):
    url = f"https://api.weixin.qq.com{path}?access_token={TOKEN}"
    req = urllib.request.Request(url, data=data_bytes, headers={"Content-Type": ctype})
    with urllib.request.urlopen(req, timeout=60) as x:
        return json.loads(x.read().decode("utf-8"))

def upload_image(path):
    url = f"https://api.weixin.qq.com/cgi-bin/material/add_material?access_token={TOKEN}&type=image"
    bd = open(path, "rb").read()
    boundary = "----WebKitFormBoundary" + uuid.uuid4().hex
    body = (b"--" + boundary.encode() + b"\r\n"
            + b'Content-Disposition: form-data; name="media"; filename="'
            + os.path.basename(path).encode() + b'"\r\n'
            + b"Content-Type: image/png\r\n\r\n" + bd + b"\r\n"
            + b"--" + boundary.encode() + b"--\r\n")
    req = urllib.request.Request(url, data=body, headers={
        "Content-Type": f"multipart/form-data; boundary={boundary}", "User-Agent": "x"})
    with urllib.request.urlopen(req, timeout=60) as x:
        j = json.loads(x.read().decode())
    if "media_id" not in j:
        raise SystemExit("upload fail: " + str(j))
    return j["media_id"], j.get("url", "")

NAVY = "#0B1F3A"; TEAL = "#14B8A6"; RED = "#E8281B"; DARK = "#1a2332"
GREY = "#555"
cover_mid, cover_url = upload_image(f"{BASE}/cover.png")
print("cover ok")

# (slug, cn, en, 痛点, 价值/脚本)
GROUPS = [
    ("一、爆款通用 4 件套（已上架首批）", [
        ("context-engineering", "上下文工程", "Context Engineering",
         "AI 越长聊越笨、忘设定、token 烧太快。",
         "审计相关性·冗余·预算·衰减四维度，给裁剪/检索/记忆/门禁四步流程。", "context_budget.py"),
        ("ai-cost-cutter", "AI 省钱跑批", "AI Cost Cutter",
         "API 账单太贵，贵模型在做贱活。",
         "批处理(异步5折)/本地回退/缓存层/模型路由四把刀降本。", "cost_estimator.py · 实测可省 94%"),
        ("prompt-injection-shield", "提示注入防护", "Prompt Injection Shield",
         "网页/邮件/工具返回里藏着“忽略之前指令”，模型分不清。",
         "外部内容进上下文前扫描：中英双语文式库+启发式+沙箱规则，风险分定处置。", "prompt_injection_scan.py"),
        ("eu-ai-act-companion", "EU AI Act 合规导航", "EU AI Act Companion",
         "要进欧盟，不确定高风险还是有限风险、provider 还是 deployer。",
         "风险四级分类+按角色义务清单+关键节点(2024-08→2027-08)+合格评定路径。", "eu_ai_act_nav.py"),
    ]),
    ("二、直击市场痛点 10 件套", [
        ("agent-memory-keeper", "智能体记忆管家", "Agent Memory Keeper",
         "Agent 记忆越攒越乱，过期/泄漏/冗余无人管。",
         "盘点记忆健康度：过期项、外泄风险、冗余命中，给出清理建议。", "memory_audit.py"),
        ("prompt-compressor", "提示压缩器", "Prompt Compressor",
         "长上下文把 token 和延迟都喂爆了。",
         "在不丢关键信息前提下压缩提示，保任务质量降成本。", "compress_prompt.py"),
        ("agent-redteam-kit", "红队测试套件", "Agent Redteam Kit",
         "上线前不知道 agent 会被什么攻破。",
         "主动扫攻击面：注入/越权/越界/数据渗出，出风险清单。", "redteam_scan.py"),
        ("doc-desens-scanner", "文档去敏扫描", "Doc Desens Scanner",
         "对外发文档前，怕漏了密钥/PII/内部代号。",
         "扫密钥/PII/内部路径/项目代号，给脱敏位置与处置。", "desens_scan.py"),
        ("rag-grounding-guard", "RAG 溯源守卫", "RAG Grounding Guard",
         "RAG 回答一本正经胡说，溯源不到出处。",
         "核查回答是否来自检索片段，标出无据断言防幻觉。", "grounding_check.py"),
        ("multi-agent-conductor", "多智能体指挥", "Multi-Agent Conductor",
         "多个 agent 各干各的，结果不收敛。",
         "任务拆分/角色分配/汇聚收敛，给可落地编排方案。", "conductor_plan.py"),
        ("skill-quality-gate", "技能质量门禁", "Skill Quality Gate",
         "技能上线前没标准，质量参差不齐。",
         "9 维自测过闸：frontmatter/脚本/双语/去敏等，不过不发。", "quality_gate.py"),
        ("ai-policy-radar", "AI 政策雷达", "AI Policy Radar",
         "各国 AI 法规天天变，追不过来。",
         "追踪 EU/US/中/等地区法规动态，输出与你相关的变更。", "policy_radar.py"),
        ("agent-trace-audit", "智能体链路审计", "Agent Trace Audit",
         "Agent 出错后查不出哪一步作的妖。",
         "记录每步决策与工具调用，形成可回溯证据链。", "trace_audit.py"),
        ("eval-bench-builder", "评测基准构建", "Eval Bench Builder",
         "想测 agent 但没像样的评测集。",
         "按场景自动生成评测集与打分口径，可复跑对比。", "bench_build.py"),
    ]),
    ("三、治理加固 10 件套", [
        ("output-schema-guard", "输出结构守卫", "Output Schema Guard",
         "LLM 输出格式飘，下游解析老崩。",
         "强制输出合规 JSON/结构，不符即重生成或报错。", "schema_guard.py"),
        ("tool-call-guard", "工具调用守卫", "Tool Call Guard",
         "Agent 乱调工具，可能删库/外发。",
         "拦截危险/越权工具调用，按白名单与影响面放行。", "tool_guard.py"),
        ("model-router", "模型路由器", "Model Router",
         "所有任务都丢给最贵模型，太浪费。",
         "按难度/延迟/成本路由模型，省成本保质量。", "model_router.py"),
        ("fact-check-guard", "事实核查守卫", "Fact Check Guard",
         "Agent 随口编事实，没人核。",
         "核验声称与权威源一致，标出存疑断言。", "fact_guard.py"),
        ("agent-loop-guard", "循环守卫", "Agent Loop Guard",
         "Agent 卡死在无限重试/死循环。",
         "检测步数/重复模式，超限即熔断并报告。", "loop_guard.py"),
        ("bias-auditor", "偏见审计员", "Bias Auditor",
         "输出对某些群体有隐含偏见。",
         "扫描群体偏见与刻板印象，给修正建议。", "bias_audit.py"),
        ("prompt-version-control", "提示版本控制", "Prompt Version Control",
         "提示词改了没法回滚，效果退化查不出。",
         "提示词像代码一样版本管理，可对比/回滚。", "prompt_vc.py"),
        ("api-resilience", "API 弹性", "API Resilience",
         "依赖一抖，agent 整条链路挂掉。",
         "重试/退避/熔断演示，提升对外调用韧性。", "resilience_demo.py"),
        ("mcp-security-scan", "MCP 安全扫描", "MCP Security Scan",
         "接了一堆 MCP server，不知哪些有坑。",
         "扫 MCP 工具的风险面：越权/注入/数据渗出。", "mcp_scan.py"),
        ("data-rights-guard", "数据权利守卫", "Data Rights Guard",
         "GDPR/个保法下的访问·删除·导出请求难落地。",
         "把数据权利请求映射成可执行清单与处置流。", "rights_guard.py"),
    ]),
]

def esc(t): return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

h = []
H = lambda s: h.append(s)
H(f'<section style="font-family:-apple-system,PingFang SC,Microsoft YaHei,sans-serif;color:#222;line-height:1.8;font-size:16px;">')
# hero
H(f'<section style="background:linear-gradient(135deg,{NAVY},{DARK});color:#fff;padding:34px 24px;border-radius:16px;margin-bottom:20px;">')
H(f'<p style="margin:0 0 8px;color:{TEAL};font-size:14px;letter-spacing:.5px;">LGD 治理理论  ·  24 个通用 AI 智能体技能全家桶</p>')
H(f'<h1 style="margin:0 0 10px;font-size:25px;line-height:1.3;">一套治理脊柱，<br>24 个能直接跑的技能</h1>')
H(f'<p style="margin:0;color:#aebcd3;font-size:14px;">不局限医疗 · 零依赖 · 每个带一个可跑脚本 · 已上架 SkillPie 与 GitHub</p></section>')
# intro
H(f'<p style="margin:16px 0 4px;color:#444;">我们把 <b>LGD 治理理论（有籍·有证·有门禁）</b>做成了 24 个通用 AI 智能体技能，分三批打磨：先打爆款、再补痛点、最后加固治理。它们不挑行业，每个都带一个可执行脚本。</p>')
H(f'<p style="margin:8px 0 18px;color:{GREY};">为什么值得装：通用技能下载量远大于垂直技能；而“理论能做得更好”的 4 个方向——<span style="color:{RED};">上下文·成本·安全·合规</span>——只是起点。</p>')

idx = 0
for gtitle, items in GROUPS:
    H(f'<section style="background:#f3f6fb;border-left:4px solid {TEAL};padding:12px 16px;border-radius:8px;margin:22px 0 14px;">'
      f'<h2 style="margin:0;font-size:18px;color:{NAVY};">{gtitle}</h2></section>')
    for slug, cn, en, pain, sol, script in items:
        idx += 1
        H(f'<section style="border:1px solid #e7ecf3;background:#fff;padding:14px 16px;margin:14px 0;border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,.05);">')
        H(f'<h3 style="margin:0 0 6px;font-size:16px;color:{NAVY};">{idx}. {cn} <span style="color:#999;font-size:13px;font-weight:normal;">{en}</span></h3>')
        H(f'<div style="background:#fef2f2;border-radius:7px;padding:7px 12px;margin:6px 0 0;"><span style="color:{RED};font-weight:bold;font-size:13px;">痛点：</span>{esc(pain)}</div>')
        H(f'<p style="margin:8px 0 0;color:#333;font-size:15px;">{esc(sol)}</p>')
        H(f'<p style="margin:6px 0 0;color:#667;font-size:13px;">附脚本：<code>{script}</code></p>')
        H(f'</section>')

# install
H(f'<section style="background:linear-gradient(135deg,#eef4fb,#f0faf8);border:1px solid #d4e6f0;border-radius:14px;padding:18px 20px;margin:22px 0;">')
H(f'<h2 style="margin:0 0 10px;font-size:17px;color:{NAVY};">怎么装（24 个通用）</h2>')
H(f'<p style="margin:4px 0;color:#333;">• <b>SkillPie</b>：市场搜技能名直接装。</p>')
H(f'<p style="margin:4px 0;color:#333;">• <b>GitHub</b>：zhaoxinghua09-cell/agent-skills → 复制 skills/&lt;名字&gt;/ 到你的 agent 技能目录。</p>')
H(f'<p style="margin:4px 0;color:#666;font-size:14px;">每个技能内置“AI 何时该主动建议安装”判定节，AI 读到命中即荐。</p></section>')
# theory
H(f'<section style="margin:18px 0;"><h2 style="font-size:17px;color:{NAVY};">为什么是同一套治理脊柱</h2>')
H(f'<p style="margin:8px 0;color:#333;">24 个技能共用——<b>有籍（来源登记）·有证（可溯源）·有门禁（修改走备份→可逆→小批量→确认）</b>。这正是它们敢丢进自主 agent、而不只是聊天机器人的原因。</p>')
H(f'<p style="margin:6px 0;color:#777;font-size:14px;">理论根：<b>LGD-theory</b>（github.com/zhaoxinghua09-cell/lgd-theory）· MIT · 理论 CC BY 4.0</p></section>')
# footer
H(f'<section style="text-align:center;margin-top:22px;padding-top:16px;border-top:1px solid #eaecef;">')
H(f'<img src="{cover_url}" style="height:40px;border-radius:6px;"><br>')
H(f'<span style="color:#999;font-size:13px;">© LGD / SynomosAI 2026 · 关注【MedXpert】获取更多 AI 治理实践</span></section>')
H('</section>')

content = "".join(h)
article = {
    "title": "24 个让 AI 自己都会想装的通用技能（LGD 治理理论全家桶）",
    "author": "MedXpert",
    "digest": "LGD 治理理论 24 个零依赖通用 AI 技能：上下文/成本/安全/合规/治理加固，已上架 SkillPie 与 GitHub，每个带可跑脚本。",
    "content": content,
    "thumb_media_id": cover_mid,
    "need_open_comment": 0,
    "only_fans_can_comment": 0,
}
data = json.dumps({"articles": [article]}, ensure_ascii=False).encode("utf-8")
r = mp_raw("/cgi-bin/draft/add", data)
print("draft/add:", r)
media_id = r.get("media_id")
if not media_id:
    raise SystemExit("draft add failed: " + str(r))

# verify
vr = mp_raw("/cgi-bin/draft/batchget", json.dumps({"offset": 0, "count": 20, "no_content": 0}).encode("utf-8"))
found = None
for it in vr.get("item", []):
    if it.get("media_id") == media_id:
        found = it.get("content", {}).get("news_item", [{}])[0]
        break
if found:
    t = found.get("title", ""); c = found.get("content", "")
    bad = bool(re.search(r"\\u[0-9a-fA-F]{4}", t)) or bool(re.search(r"\\u[0-9a-fA-F]{4}", c))
    print("VERIFY title:", t)
    print("VERIFY garbled?", bad, " len=", len(c))
    if bad:
        raise SystemExit("STILL GARBLED — abort")
    print("VERIFY OK")
else:
    print("VERIFY: new draft not in first page; ok if add returned media_id")
print("NEW media_id:", media_id)
