# -*- coding: utf-8 -*-
"""通用 SkillPie 发布器（skillpie.cn）——独立于 SkillHub 限频通道。
用法: python _sh_publish_skillpie.py [group...]    # group: low5 / ind6 / all
幂等: 已发布成功的包会显示"已存在/更新"类结果, 记录不重复计数由人工判读。
密钥: 无需显式传 (AppKey 已存 ~/.config/skillpie/config.json)。
"""
import json, pathlib, re, subprocess, sys, time

NODE = "C:/Users/Administrator/.workbuddy/binaries/node/versions/node24/node.exe"
CLI = "C:/Users/Administrator/.workbuddy/skills/skillpie/scripts/cli.js"
BASE = pathlib.Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划")
LOG = BASE / "_sh_publish_skillpie.log"
RESULT = BASE / "_sh_publish_skillpie_result.json"

GROUPS = {
    "low5": ["a3-law-operational", "agent-evolution", "dpapi-local-vault",
             "session-continuity-protocol", "doc-extract"],
    "ind6": ["uas-ops-checker", "aut-grade-checker", "data-grade-checker",
             "hgrac-route-checker", "fin-ai-classifier", "evid-four-check"],
    "p066b1": ["eu-ai-act-tier-check", "udi-cn-validator", "china-algo-filing-check",
               "ai-disclosure-gen", "model-data-trace-check"],
}
ROOTS = {
    "low5": BASE / "SkillHub_5_upgrade_v1",
    "ind6": BASE / "SkillHub_industry6_v1",
    "all81": BASE / "SkillHub_81_upgrade_v2",
    "p066b1": BASE / "P066b_batch1_v1",
}


def discover_all81():
    """自动发现 SkillHub_81_upgrade_v2 下所有含 SKILL.md 的包（兼容嵌套结构）。"""
    found = []
    for child in sorted(ROOTS["all81"].iterdir()):
        if not child.is_dir():
            continue
        sd = find_pkg_dir(ROOTS["all81"], child.name)
        if sd is not None:
            found.append(child.name)
    return found


def log(msg):
    line = f"{time.strftime('%H:%M:%S')} {msg}"
    print(line, flush=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def find_pkg_dir(root, slug):
    """兼容 <root>/<slug>/ 扁平 与 <root>/<slug>/<slug>/ 嵌套。"""
    flat = root / slug
    nested = flat / slug
    if (flat / "SKILL.md").exists():
        return flat
    if (nested / "SKILL.md").exists():
        return nested
    return None


def get_title(sd):
    t = (sd / "SKILL.md").read_text(encoding="utf-8", errors="ignore")
    m = re.search(r'display_name:\s*"?([^"\n]+?)"?\s*$', t, re.M)
    if m:
        return m.group(1).strip().strip('"')
    m2 = re.search(r'name:\s*"?([^"\n]+?)"?\s*$', t, re.M)
    if m2:
        return m2.group(1).strip().strip('"')
    return sd.name


def submit_one(sd, title):
    for attempt in (1, 2):
        try:
            r = subprocess.run([NODE, CLI, "submit", str(sd), "--title", title],
                               cwd=str(sd.parent), capture_output=True, text=True,
                               encoding="utf-8", errors="replace", timeout=300)
            out = (r.stdout or "") + (r.stderr or "")
        except subprocess.TimeoutExpired:
            out = "TIMEOUT"
        except Exception as e:
            out = f"EXC:{e}"
        low = out.lower()
        good = ("发布成功" in out) or ("submitted" in low) or ("成功" in out and "skillpie" in low)
        if good:
            return "ok", out[-200:].strip()
        if "已存在" in out or "重名" in out or "已占用" in out or "conflict" in low or "already" in low:
            return "exists", out[-200:].strip()
        if attempt == 1 and ("网络" in out or "timeout" in low or "TIMEOUT" in out or "ECONN" in out):
            time.sleep(15)
            continue
        return "fail", out[-200:].strip()


def main():
    args = sys.argv[1:] or ["all"]
    results = []
    for g in args:
        if g == "all":
            for gg in ("low5", "ind6", "all81"):
                main_group(gg, results)
        else:
            main_group(g, results)
    ok_n = sum(1 for r in results if r["status"] == "ok")
    ex_n = sum(1 for r in results if r["status"] == "exists")
    fail_n = sum(1 for r in results if r["status"] == "fail")
    log(f"\nDONE. ok={ok_n} exists={ex_n} fail={fail_n} total={len(results)}")
    RESULT.write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")


def main_group(g, results):
    slugs = discover_all81() if g == "all81" else GROUPS[g]
    log(f"===== 组 {g} ({len(slugs)} 包) =====")
    for slug in slugs:
        sd = find_pkg_dir(ROOTS[g], slug)
        if sd is None:
            log(f"  [SKIP] {slug}: 未找到包目录 ({ROOTS[g]/slug})")
            results.append({"group": g, "slug": slug, "status": "missing"})
            continue
        title = get_title(sd)
        log(f"  --> {slug} (title={title})")
        st, msg = submit_one(sd, title)
        log(f"  [{st.upper()}] {slug}  {msg}")
        results.append({"group": g, "slug": slug, "title": title, "status": st, "msg": msg[-160:]})
        time.sleep(4)


if __name__ == "__main__":
    main()
