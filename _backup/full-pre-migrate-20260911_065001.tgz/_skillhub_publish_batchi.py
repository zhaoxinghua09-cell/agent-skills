# -*- coding: utf-8 -*-
"""Batch I 6 技能 → SkillHub 正式发布(调用 skills_store_cli.py, 用缓存凭据代发)。
带频率限流(429/过于频繁)重试: 命中后等 120s 重试, 最多 2 次。
后台运行: run_in_background=True; 完成后 TaskOutput 取全量。
"""
import subprocess
import sys
import time
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
CLI = "C:/Users/Administrator/.skillhub/skills_store_cli.py"
STAGE = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/SkillHub_BatchI_stage")

SLUGS = ["udi-format-validator", "clin-eval-route-picker", "pmcf-plan-check",
         "md-link-audit", "changelog-draft-gen", "env-var-audit"]

CHANGELOG = {
    "udi-format-validator": "UDI 格式校验器 v1.0.0: GS1 Mod10 校验位 + NMPA 三类(2022-06-01)/二类(2024-06-01) + EU Basic UDI-DI/EUDAMED 判定; 零依赖确定性输出(JSON IR + 修复回执)",
    "clin-eval-route-picker": "临床评价路径选择器 v1.0.0: NMPA 73号通告三路(免临床目录/同品种/临床试验) + EU MDCG 2020-6 WET 判定树; 矛盾输入检测",
    "pmcf-plan-check": "PMCF 计划完整性检查器 v1.0.0: MDCG 2020-7 Annex I 十要素 + MDCG 2019-8 核对; weak 项正则判定",
    "md-link-audit": "Markdown 链接体检器 v1.0.0: 默认离线锚点核对(GitHub 口径) + --net 才 HEAD 校验外链(8s 超时)",
    "changelog-draft-gen": "更新日志草稿生成器 v1.0.0: conventional commits 归类 + 原子写(os.replace); 确定性输出 rc=0/1/2",
    "env-var-audit": "环境变量审计器 v1.0.0: 硬编码密钥扫描 + .env.example 账目(used/undocumented/unused); 零依赖",
}


def publish_one(slug):
    d = str(STAGE / slug)
    cmd = [PY, CLI, "publish", d, "--version", "1.0.0", "--changelog", CHANGELOG[slug]]
    for attempt in range(3):
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8")
        out = (r.stdout + r.stderr).strip()
        if r.returncode == 0 and "Published" in out:
            return True, out
        if "过于频繁" in out or "频率过高" in out or "429" in out or "Too Many" in out:
            wait = 120
            print("[RATE] %s 触发限流, 等 %ds 重试(%d/2)" % (slug, wait, attempt + 1), flush=True)
            time.sleep(wait)
            continue
        # 其他失败(非限流)
        return False, out
    return False, "重试耗尽仍限流"


def main():
    print("== SkillHub 发布 Batch I (6) ==", flush=True)
    ok, fail = [], []
    for i, slug in enumerate(SLUGS):
        print("\n[%d/%d] %s" % (i + 1, len(SLUGS), slug), flush=True)
        good, out = publish_one(slug)
        print(out[:600], flush=True)
        if good:
            ok.append(slug)
            # 间隔, 降低连发限流概率
            if i < len(SLUGS) - 1:
                print("  ... 间隔 20s", flush=True)
                time.sleep(20)
        else:
            fail.append((slug, out[:200]))
    print("\n==== 发布完成: OK %d / FAIL %d ====" % (len(ok), len(fail)), flush=True)
    for s in ok:
        print("  [OK] " + s, flush=True)
    for s, e in fail:
        print("  [FAIL] %s -> %s" % (s, e), flush=True)


if __name__ == "__main__":
    main()
