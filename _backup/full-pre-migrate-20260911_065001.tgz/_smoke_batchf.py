# -*- coding: utf-8 -*-
"""Batch F 冒烟驱动：10 技能正反验证（子进程跑 CLI）。"""
import json, subprocess, sys, pathlib

PY = sys.executable
BASE = pathlib.Path(__file__).parent
TMP = pathlib.Path("C:/temp/batchf_smoke")
if TMP.exists():
    for f in TMP.iterdir():
        f.unlink()
TMP.mkdir(parents=True, exist_ok=True)
RESULTS = []


def run(script, args, label, expect_rc):
    p = subprocess.run([PY, str(BASE / script)] + args, capture_output=True, text=True, timeout=60)
    RESULTS.append((label, p.returncode == expect_rc, p.returncode, expect_rc))
    return p


def jout(p):
    try:
        return json.loads(p.stdout)
    except Exception:
        return {}


# F1 data-minimizer
p = run("data-minimizer/scripts/data_minimizer.py",
        ["--text", "联系张三 13812345678 或 tom@x.com，卡号 6222021234567890123", "--names", "张三", "--json"],
        "F1 脱敏+报告", 0)
j = jout(p)
assert "〔手机号〕" not in j["masked_text"] and "138****" in j["masked_text"] and j["counts"]["name"] == 1
run("data-minimizer/scripts/data_minimizer.py", [], "F1 缺输入 rc=2", 2)

# F2 model-card
p = run("model-card-generator/scripts/model_card_generator.py",
        ["--name", "kefu-bot", "--purpose", "工单摘要", "--limits", "只支持中文", "--json"],
        "F2 模型卡生成", 0)
assert "# 模型卡 · kefu-bot" in jout(p)["markdown"]
run("model-card-generator/scripts/model_card_generator.py", ["--name", "x"],
    "F2 缺 purpose rc=2", 2)

# F3 usage-policy
p = run("ai-usage-policy/scripts/ai_usage_policy.py",
        ["--team", "运营部", "--escalation", "安全-李四", "--out", str(TMP / "policy.md")],
        "F3 守则生成", 0)
assert "红线" in (TMP / "policy.md").read_text(encoding="utf-8")
run("ai-usage-policy/scripts/ai_usage_policy.py", ["--team", "x"], "F3 缺上报线 rc=2", 2)

# F4 incident-log
led = TMP / "inc.jsonl"
run("ai-incident-log/scripts/ai_incident_log.py",
    ["--add", "bot外发敏感信息", "--severity", "3", "--model", "kefu-bot", "--file", str(led)],
    "F4 事故入账", 0)
p = run("ai-incident-log/scripts/ai_incident_log.py", ["--report", "--file", str(led), "--json"],
        "F4 报表", 0)
assert jout(p)["total"] == 1

# F5 kill-switch
p = run("agent-kill-switch/scripts/agent_kill_switch.py",
        ["--agent", "crawler-bot", "--conditions", "连续5次报错", "输出含PII",
         "--revoke", "撤API key", "--owner", "运维-王五", "--out", str(TMP / "ks.json")],
        "F5 制动卡生成", 0)
run("agent-kill-switch/scripts/agent_kill_switch.py", ["--check", str(TMP / "ks.json")],
    "F5 制动卡校验通过", 0)
bad = {"card_type": "x", "agent": "y", "conditions": [], "revoke": "", "owner": "",
       "recovery": "", "generated_at": "t"}
(TMP / "ks_bad.json").write_text(json.dumps(bad), encoding="utf-8")
run("agent-kill-switch/scripts/agent_kill_switch.py", ["--check", str(TMP / "ks_bad.json")],
    "F5 缺项拦截 rc=1", 1)

# F6 heuristics
p = run("ai-reply-heuristics/scripts/ai_reply_heuristics.py",
        ["--text", "总而言之，随着…的发展，深入探讨这个话题很重要。综上所述，一，二，三。\n同样句长的句子一。\n同样句长的句子二。\n同样句长的句子三。\n同样句长的句子四。", "--json"],
        "F6 AI痕迹高分", 0)
assert jout(p)["score"] >= 30
run("ai-reply-heuristics/scripts/ai_reply_heuristics.py",
    ["--text", "我刚吃了碗面，挺香。"], "F6 人写低分", 0)

# F7 citation-coverage
p = run("citation-coverage-check/scripts/citation_coverage_check.py",
        ["--text", "2025年市场规模增长了30%。研究报告指出市场规模达100亿（来源：IDC）。", "--json"],
        "F7 覆盖率不足拦截 rc=1", 1)
assert jout(p)["coverage"] == 0.5
run("citation-coverage-check/scripts/citation_coverage_check.py",
    ["--text", "据官方数据，2025年增长30%。来源见参考文献。"], "F7 覆盖达标", 0)

# F8 vendor-checklist
p = run("ai-vendor-checklist/scripts/ai_vendor_checklist.py",
        ["--template", "--vendor", "XX智能", "--out", str(TMP / "dd.md")], "F8 尽调清单模板", 0)
assert "训练退出" in (TMP / "dd.md").read_text(encoding="utf-8")
run("ai-vendor-checklist/scripts/ai_vendor_checklist.py",
    ["--score", "1,1,1,1,1,1,1,0,0,0"], "F8 得分不足拦截 rc=1", 1)
run("ai-vendor-checklist/scripts/ai_vendor_checklist.py", ["--score", "1,2,3"],
    "F8 分数个数错误 rc=2", 2)

# F9 injection-drill
p = run("prompt-injection-drill/scripts/prompt_injection_drill.py",
        ["--system", "你是内部客服，只能回答售后问题。", "--out", str(TMP / "drill.md")],
        "F9 注入用例生成", 0)
assert "D8" in (TMP / "drill.md").read_text(encoding="utf-8")
run("prompt-injection-drill/scripts/prompt_injection_drill.py", [],
    "F9 缺输入 rc=2", 2)

# F10 decision-log
dled = TMP / "dec.jsonl"
run("ai-decision-log/scripts/ai_decision_log.py",
    ["--add", "--decision", "驳回供应商A", "--model", "glm-x", "--evidence", "dd_report.md",
     "--reviewer", "张三", "--file", str(dled)], "F10 决策留痕(有人审)", 0)
run("ai-decision-log/scripts/ai_decision_log.py",
    ["--add", "--decision", "改用新模型", "--model", "glm-x", "--file", str(dled)],
    "F10 决策留痕(无人审)", 0)
p = run("ai-decision-log/scripts/ai_decision_log.py", ["--report", "--file", str(dled), "--json"],
        "F10 报表含无人审", 0)
assert len(jout(p)["unreviewed"]) == 1

fails = [r for r in RESULTS if not r[1]]
for label, ok, rc, exp in RESULTS:
    print(("PASS " if ok else "FAIL ") + label + f"  (rc={rc}, expect={exp})")
print(f"\n{len(RESULTS) - len(fails)}/{len(RESULTS)} passed")
sys.exit(1 if fails else 0)
