# -*- coding: utf-8 -*-
"""给 39 个 LGD 护城河技能的 SKILL.md 统一补「安装与使用矩阵」小节（幂等）。"""
import pathlib

BASE = pathlib.Path(__file__).resolve().parent

SLUGS = [
    # 旗舰 5（P-044）
    "lgd-three-laws-auditor", "agent-output-registry", "evidence-chain-builder",
    "lgd-certify", "gate-policy-generator",
    # 跨域守门 4（P-045）
    "lgd-fin-guard", "lgd-law-ethic", "lgd-gov-guard", "lgd-crypto-guard",
    # 跨域纵深 5（P-046）
    "fin-reg-calc", "aml-sentinel", "evidence-chain-check",
    "gov-disclosure-check", "travel-rule-check",
    # 闭环徽章 2（P-048）
    "lgd-badge-issuer", "lgd-badge-verify",
    # 广谱爆款 3（P-049）
    "ai-content-discloser", "agent-boarding-pass", "prompt-leak-scanner",
    # 广谱 F 10（P-050）
    "data-minimizer", "model-card-generator", "ai-usage-policy", "ai-incident-log",
    "agent-kill-switch", "ai-reply-heuristics", "citation-coverage-check",
    "ai-vendor-checklist", "prompt-injection-drill", "ai-decision-log",
    # 行业 G 10（P-051）
    "loan-rate-disclosure", "kyc-checklist-gen", "invoice-risk-scan", "fund-fee-calc",
    "wallet-address-check", "token-disclosure-check", "contract-interact-checklist",
    "contract-clause-check", "health-claim-guard", "data-export-check",
]

SECTION = """
## 安装与使用矩阵

```bash
# 一键获取（skills CLI）
npx skills add zhaoxinghua09-cell/agent-skills -g

# 或手动：克隆后拷贝本技能到你的 Agent 技能目录
git clone https://github.com/zhaoxinghua09-cell/agent-skills.git
cp -r agent-skills/skills/{slug} ~/.claude/skills/
```

| Agent | 技能目录 | 运行示例 |
|---|---|---|
| Claude Code | `~/.claude/skills/{slug}/` | 让 Claude 按本技能 SKILL.md 工作流调用 `scripts/` |
| Codex CLI / Cursor / WorkBuddy | 各自 skills 目录 | 同上，SKILL.md 即操作规程 |
| 直接命令行 | 任意位置 | `python scripts/{snake}.py --help` |
""".format


def section_for(slug, snake):
    return SECTION(slug=slug, snake=snake)


def main():
    patched, skipped = [], []
    for slug in SLUGS:
        p = BASE / slug / "SKILL.md"
        if not p.is_file():
            skipped.append(slug)
            continue
        text = p.read_text(encoding="utf-8")
        if "安装与使用矩阵" in text:
            skipped.append(slug + " (has)")
            continue
        # 找该技能脚本名
        scripts = list((BASE / slug / "scripts").glob("*.py"))
        snake = scripts[0].stem if scripts else slug.replace("-", "_")
        p.write_text(text.rstrip() + "\n" + section_for(slug, snake), encoding="utf-8")
        patched.append(slug)
    print("patched:", len(patched))
    for s in patched:
        print("  +", s)
    if skipped:
        print("skipped:", len(skipped), skipped)


if __name__ == "__main__":
    main()
