# -*- coding: utf-8 -*-
"""Batch H：广谱效率工具十连发（调研驱动的爆款品类：文件管理/去重/整理/磁盘/JSON/CSV/替换/统计/正则/哈希）
哨兵 replace 注入纪律；脚本零依赖；破坏性操作默认 dry-run（--apply 才执行）。
品类依据：awesome-cli-apps 高星分布（f2/fclones/dust/sd/gron/csv-toolkit/scc 类目）。
"""
import json
import os
import pathlib

BASE = pathlib.Path(__file__).resolve().parent
ICONS = ["C:/Windows/Fonts/msyhbd.ttc", "C:/Windows/Fonts/msyh.ttc", "C:/Windows/Fonts/simhei.ttf"]

SKILLS = [
    {
        "slug": "batch-renamer", "snake": "batch_renamer",
        "dn_zh": "批量重命名器", "dn_en": "Batch File Renamer",
        "glyph": "名",
        "desc": "规则式批量重命名：前缀/后缀/序号/查找替换/扩展名过滤，默认预览 --apply 才执行（零依赖）",
        "pain": "几十个文件要加前缀改序号，手动改到怀疑人生，还怕改错",
        "src": r'''
import argparse, json, os, sys

def plan_renames(files, a):
    plan = []
    for i, f in enumerate(files):
        name = os.path.basename(f)
        if a.start is not None:
            # 序号模式：prefix 或原stem + 补零序号 + suffix + 扩展名（保证不丢原名）
            stem = os.path.splitext(name)[0]
            base = a.prefix if a.prefix else stem
            ext = os.path.splitext(name)[1]
            new = "%s%0*d%s%s" % (base, max(2, len(str(a.start + len(files) - 1))), a.start + i, a.suffix or "", ext)
        else:
            new = name
            if a.replace:
                old, new_s = a.replace.split("|", 1) if "|" in a.replace else (a.replace, "")
                new = new.replace(old, new_s)
            if a.prefix:
                new = a.prefix + new
            if a.suffix:
                r, e = os.path.splitext(new)
                new = r + a.suffix + e
        if new != name:
            plan.append((f, os.path.join(os.path.dirname(f), new)))
    return plan

def main():
    ap = argparse.ArgumentParser(description="batch-renamer · 规则式批量重命名（默认预览，--apply 才执行）")
    ap.add_argument("--dir", required=True)
    ap.add_argument("--prefix"), ap.add_argument("--suffix")
    ap.add_argument("--replace", help="查找替换，格式 旧|新")
    ap.add_argument("--start", type=int, help="按序号重命名（起始编号）")
    ap.add_argument("--ext", help="只处理该扩展名，如 .jpg")
    ap.add_argument("--apply", action="store_true", help="执行（缺省只预览）")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    if not os.path.isdir(a.dir):
        print("目录不存在: %s" % a.dir); sys.exit(2)
    files = sorted(os.path.join(a.dir, f) for f in os.listdir(a.dir)
                   if os.path.isfile(os.path.join(a.dir, f))
                   and (not a.ext or f.lower().endswith(a.ext.lower())))
    plan = plan_renames(files, a)
    if a.json:
        print(json.dumps({"mode": "apply" if a.apply else "dry-run", "count": len(plan),
                          "plan": [{"from": os.path.basename(x), "to": os.path.basename(y)} for x, y in plan]},
                         ensure_ascii=False, indent=2))
    else:
        print("模式: %s ｜ 计划重命名 %d 个" % ("APPLY" if a.apply else "DRY-RUN 预览", len(plan)))
        for x, y in plan:
            print("  %s -> %s" % (os.path.basename(x), os.path.basename(y)))
    if a.apply and plan:
        for x, y in plan:
            os.rename(x, y)
        print("已执行 %d 项" % len(plan))
    elif not a.apply:
        print("预览完成，加 --apply 执行")
    sys.exit(0)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "dup-finder", "snake": "dup_finder",
        "dn_zh": "重复文件查找器", "dn_en": "Duplicate File Finder",
        "glyph": "重",
        "desc": "三级哈希（大小→首块→全量SHA1）找重复文件，默认只报告 --apply 删多余保留首个（零依赖）",
        "pain": "下载夹/相册里同名副本堆成山，占几个G不知道从哪清",
        "src": r'''
import argparse, hashlib, json, os, sys

def sha_of(path, full):
    h = hashlib.sha1()
    with open(path, "rb") as f:
        h.update(f.read(65536) if not full else f.read())
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser(description="dup-finder · 重复文件查找（默认只报告，--apply 删多余）")
    ap.add_argument("--dir", required=True)
    ap.add_argument("--min-size", type=int, default=0, help="忽略小于该KB的文件")
    ap.add_argument("--apply", action="store_true", help="删除每组重复（保留首个）")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    if not os.path.isdir(a.dir):
        print("目录不存在: %s" % a.dir); sys.exit(2)
    by_size = {}
    for root, _, files in os.walk(a.dir):
        for f in files:
            p = os.path.join(root, f)
            try:
                sz = os.path.getsize(p)
            except OSError:
                continue
            if sz >= a.min_size * 1024:
                by_size.setdefault(sz, []).append(p)
    cand = [ps for ps in by_size.values() if len(ps) > 1]
    groups = []
    for ps in cand:
        by_head = {}
        for p in ps:
            by_head.setdefault(sha_of(p, False), []).append(p)
        for ps2 in by_head.values():
            if len(ps2) > 1:
                by_full = {}
                for p in ps2:
                    by_full.setdefault(sha_of(p, True), []).append(p)
                for ps3 in by_full.values():
                    if len(ps3) > 1:
                        groups.append(sorted(ps3))
    waste = sum(os.path.getsize(g[i]) for g in groups for i in range(1, len(g)))
    removed = 0
    if a.apply:
        for g in groups:
            for p in g[1:]:
                try:
                    os.remove(p); removed += 1
                except OSError:
                    pass
    if a.json:
        print(json.dumps({"groups": len(groups), "waste_bytes": waste,
                          "removed": removed,
                          "detail": [[os.path.relpath(p, a.dir) for p in g] for g in groups]},
                         ensure_ascii=False, indent=2))
    else:
        print("重复组: %d ｜ 可释放: %.1f MB%s" % (len(groups), waste / 1048576,
              " ｜ 已删 %d 个" % removed if a.apply else "（默认只报告，--apply 删多余保留首个）"))
        for g in groups:
            print("  [组] " + g[0])
            for p in g[1:]:
                print("        dup " + p)
    sys.exit(1 if groups and not a.apply else 0)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "dir-organizer", "snake": "dir_organizer",
        "dn_zh": "文件夹整理器", "dn_en": "Directory Organizer",
        "glyph": "整",
        "desc": "按扩展名把杂乱目录归类到 图片/文档/表格/音视频/压缩包/代码/其他 子目录，默认预览 --apply 才移动（零依赖）",
        "pain": "下载夹几百个文件混在一起，找东西全靠搜，归类又懒得手动拖",
        "src": r'''
import argparse, json, os, shutil, sys

MAP = {
    "图片": [".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg", ".ico", ".heic"],
    "文档": [".pdf", ".doc", ".docx", ".txt", ".md", ".rtf", ".odt", ".epub"],
    "表格": [".xls", ".xlsx", ".csv", ".ods"],
    "演示": [".ppt", ".pptx", ".key"],
    "音频": [".mp3", ".wav", ".flac", ".aac", ".m4a", ".ogg"],
    "视频": [".mp4", ".mkv", ".avi", ".mov", ".flv", ".webm"],
    "压缩包": [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2"],
    "代码": [".py", ".js", ".ts", ".java", ".c", ".cpp", ".go", ".rs", ".sh", ".html", ".css", ".json", ".xml", ".yaml", ".yml", ".sql"],
}

def cat_of(ext):
    for cat, exts in MAP.items():
        if ext in exts:
            return cat
    return "其他"

def main():
    ap = argparse.ArgumentParser(description="dir-organizer · 按类型整理目录（默认预览，--apply 才移动）")
    ap.add_argument("--dir", required=True)
    ap.add_argument("--apply", action="store_true", help="执行移动（缺省只预览）")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    if not os.path.isdir(a.dir):
        print("目录不存在: %s" % a.dir); sys.exit(2)
    plan = []
    for f in sorted(os.listdir(a.dir)):
        p = os.path.join(a.dir, f)
        if not os.path.isfile(p):
            continue
        cat = cat_of(os.path.splitext(f)[1].lower())
        plan.append((p, os.path.join(a.dir, cat, f)))
    moved = 0
    if a.apply:
        for src, dst in plan:
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.move(src, dst); moved += 1
    if a.json:
        print(json.dumps({"mode": "apply" if a.apply else "dry-run", "moved": moved,
                          "plan": [{"file": os.path.basename(s), "to": os.path.basename(os.path.dirname(d))} for s, d in plan]},
                         ensure_ascii=False, indent=2))
    else:
        print("模式: %s ｜ 计划归类 %d 个文件" % ("APPLY" if a.apply else "DRY-RUN 预览", len(plan)))
        for s, d in plan:
            print("  %s -> %s/" % (os.path.basename(s), os.path.basename(os.path.dirname(d))))
        if not a.apply:
            print("预览完成，加 --apply 执行（文件只移动不删除）")
    sys.exit(0)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "disk-scan", "snake": "disk_scan",
        "dn_zh": "磁盘占用扫描", "dn_en": "Disk Usage Scan",
        "glyph": "盘",
        "desc": "只读扫描目录占用：Top N 大文件 + 各子目录大小排行，快速定位空间杀手（零依赖）",
        "pain": "盘满了不知道谁吃的空间，资源管理器算半天还看不清",
        "src": r'''
import argparse, json, os, sys

def dir_size(path):
    total = 0
    for root, _, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total

def main():
    ap = argparse.ArgumentParser(description="disk-scan · 目录占用扫描（只读不删）")
    ap.add_argument("--dir", required=True)
    ap.add_argument("--top", type=int, default=15)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    if not os.path.isdir(a.dir):
        print("目录不存在: %s" % a.dir); sys.exit(2)
    files = []
    subdirs = {}
    for root, dirs, fs in os.walk(a.dir):
        rel = os.path.relpath(root, a.dir)
        if rel != ".":
            subdirs[rel] = dir_size(root)
        for f in fs:
            p = os.path.join(root, f)
            try:
                files.append((os.path.getsize(p), p))
            except OSError:
                pass
    files.sort(reverse=True)
    subs = sorted(subdirs.items(), key=lambda kv: -kv[1])[:a.top]
    total = dir_size(a.dir)
    if a.json:
        print(json.dumps({"total_bytes": total,
                          "top_files": [{"path": os.path.relpath(p, a.dir), "bytes": s} for s, p in files[:a.top]],
                          "top_dirs": [{"path": k, "bytes": v} for k, v in subs]},
                         ensure_ascii=False, indent=2))
    else:
        print("总占用: %.2f MB ｜ Top %d 大文件:" % (total / 1048576, min(a.top, len(files))))
        for s, p in files[:a.top]:
            print("  %8.2f MB  %s" % (s / 1048576, os.path.relpath(p, a.dir)))
        print("Top %d 子目录:" % len(subs))
        for k, v in subs:
            print("  %8.2f MB  %s" % (v / 1048576, k))
        print("（只读扫描，删除请自行判断或配合 dup-finder）")
    sys.exit(0)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "json-tidy", "snake": "json_tidy",
        "dn_zh": "JSON 整形器", "dn_en": "JSON Tidy",
        "glyph": "{}",
        "desc": "JSON 格式化/压缩/键排序，解析错误精确定位行列，管道可用（零依赖）",
        "pain": "接口返回的JSON压成一行没法看，报错只说invalid不知道错在哪",
        "src": r'''
import argparse, json, sys

def main():
    ap = argparse.ArgumentParser(description="json-tidy · JSON 格式化/压缩/校验（零依赖）")
    ap.add_argument("--file", help="JSON 文件路径（缺省读 stdin）")
    ap.add_argument("--minify", action="store_true", help="压缩为单行")
    ap.add_argument("--sort", action="store_true", help="键排序")
    ap.add_argument("--out", help="写出文件（缺省打印）")
    a = ap.parse_args()
    raw = open(a.file, encoding="utf-8-sig").read() if a.file else sys.stdin.read()
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        lines = raw.splitlines()
        line = lines[e.lineno - 1] if e.lineno - 1 < len(lines) else ""
        col = max(0, e.colno - 1)
        print("JSON 解析失败: 第%d行第%d列 %s" % (e.lineno, e.colno, e.msg))
        print("  " + line[:col] + "[HERE]" + line[col:col + 30])
        sys.exit(1)
    out = json.dumps(data, ensure_ascii=False,
                     indent=None if a.minify else 2,
                     separators=(",", ":") if a.minify else None,
                     sort_keys=a.sort)
    if a.out:
        open(a.out, "w", encoding="utf-8").write(out)
        print("已写出 %s（%d bytes）" % (a.out, len(out)))
    else:
        print(out)
    sys.exit(0)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "csv-slice", "snake": "csv_slice",
        "dn_zh": "CSV 切片器", "dn_en": "CSV Slice",
        "glyph": "列",
        "desc": "CSV 快速查看/取列/去重/条件筛选/统计行数，纯标准库 csv 模块（零依赖）",
        "pain": "想看下CSV前几行某几列，打开Excel卡半天，写pandas又太重",
        "src": r'''
import argparse, csv, json, sys

def main():
    ap = argparse.ArgumentParser(description="csv-slice · CSV 快速查看/筛选/去重（零依赖）")
    ap.add_argument("--file", required=True)
    ap.add_argument("--head", type=int, help="只看前N行")
    ap.add_argument("--cols", help="只取这些列（序号从1起，逗号分隔，如 1,3）")
    ap.add_argument("--where", help="条件筛选，格式 列号=值，如 2=北京")
    ap.add_argument("--dedup", action="store_true", help="整行去重")
    ap.add_argument("--count", action="store_true", help="只统计行数")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    try:
        rows = list(csv.reader(open(a.file, encoding="utf-8-sig", newline="")))
    except Exception as e:
        print("读取失败: %s" % e); sys.exit(2)
    if not rows:
        print("空文件"); sys.exit(1)
    hdr, body = rows[0], rows[1:]
    if a.where and "=" in a.where:
        ci, val = a.where.split("=", 1)
        ci = int(ci) - 1
        body = [r for r in body if ci < len(r) and r[ci] == val]
    if a.dedup:
        seen, out = set(), []
        for r in body:
            k = tuple(r)
            if k not in seen:
                seen.add(k); out.append(r)
        removed = len(body) - len(out)
        body = out
    else:
        removed = 0
    cols = None
    if a.cols:
        cols = [int(c) - 1 for c in a.cols.split(",")]
        hdr = [hdr[i] for i in cols if i < len(hdr)]
        body = [[r[i] for i in cols if i < len(r)] for r in body]
    if a.json:
        print(json.dumps({"header": hdr, "rows": body[:a.head] if a.head else body,
                          "total": len(body), "dedup_removed": removed},
                         ensure_ascii=False, indent=2))
        sys.exit(0)
    if a.count:
        print("数据行: %d（不含表头）%s" % (len(body), "｜去重删除 %d 行" % removed if removed else ""))
        sys.exit(0)
    print(" | ".join(hdr))
    for r in (body[:a.head] if a.head else body):
        print(" | ".join(r))
    tail = "（前%d行/共%d行）" % (a.head, len(body)) if a.head and len(body) > a.head else "（共%d行）" % len(body)
    print(tail + ("｜去重删除 %d 行" % removed if removed else ""))
    sys.exit(0)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "text-replace", "snake": "text_replace",
        "dn_zh": "跨文件批量替换", "dn_en": "Bulk Text Replace",
        "glyph": "换",
        "desc": "多文件批量查找替换（字面量/正则），默认统计命中不写盘 --apply 才改，改前自动 .bak 备份（零依赖）",
        "pain": "改名/改版本号/改接口地址，几十个文件一个个开编辑器改到眼瞎",
        "src": r'''
import argparse, glob, json, os, re, shutil, sys

def main():
    ap = argparse.ArgumentParser(description="text-replace · 跨文件批量查找替换（默认统计，--apply 才写入）")
    ap.add_argument("--glob", required=True, help='文件通配，如 "src/**/*.py" 或 "docs/*.md"')
    ap.add_argument("--old", required=True)
    ap.add_argument("--new", required=True)
    ap.add_argument("--regex", action="store_true", help="按正则解释 old")
    ap.add_argument("--apply", action="store_true", help="写入（缺省只统计；写入前每文件生成 .bak）")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    files = [f for f in glob.glob(a.glob, recursive=True) if os.path.isfile(f)]
    pat = re.compile(a.old) if a.regex else None
    results, total = [], 0
    for f in files:
        try:
            txt = open(f, encoding="utf-8").read()
        except (UnicodeDecodeError, OSError):
            continue
        n = len(pat.findall(txt)) if pat else txt.count(a.old)
        if n:
            total += n
            results.append((f, n))
            if a.apply:
                shutil.copy2(f, f + ".bak")
                open(f, "w", encoding="utf-8").write(pat.sub(a.new, txt) if pat else txt.replace(a.old, a.new))
    if a.json:
        print(json.dumps({"mode": "apply" if a.apply else "dry-run", "files": len(results),
                          "total_hits": total, "detail": [{"file": f, "hits": n} for f, n in results]},
                         ensure_ascii=False, indent=2))
    else:
        print("模式: %s ｜ 命中 %d 个文件 / %d 处" % ("APPLY 已替换(.bak已备份)" if a.apply else "DRY-RUN 仅统计", len(results), total))
        for f, n in results:
            print("  %4d  %s" % (n, f))
    sys.exit(0)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "text-stats", "snake": "text_stats",
        "dn_zh": "文本统计器", "dn_en": "Text Stats",
        "glyph": "字",
        "desc": "文本/代码统计：字数/行数/词频TopN/阅读时长，支持目录批量汇总（零依赖）",
        "pain": "投稿限字数、稿费按字算、报告要篇幅，数来数去还数错",
        "src": r'''
import argparse, glob, json, os, re, sys
from collections import Counter

def main():
    ap = argparse.ArgumentParser(description="text-stats · 文本统计（字数/行数/词频/阅读时长）")
    ap.add_argument("--file"), ap.add_argument("--dir")
    ap.add_argument("--ext", default=".txt,.md", help="目录模式下的扩展名（逗号分隔）")
    ap.add_argument("--top", type=int, default=10, help="词频TopN")
    ap.add_argument("--cjk-chars", type=int, default=400, help="每分钟阅读字数")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    if not a.file and not a.dir:
        ap.error("需要 --file 或 --dir")
    files = ([a.file] if a.file else
             [f for e in a.ext.split(",") for f in glob.glob(os.path.join(a.dir, "**", "*" + e), recursive=True)])
    chars = words = lines = 0
    freq = Counter()
    for f in files:
        try:
            txt = open(f, encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        chars += len(txt.replace(" ", "").replace("\n", ""))
        lines += txt.count("\n") + (0 if txt.endswith("\n") or not txt else 1)
        words += len(re.findall(r"[A-Za-z0-9_]+", txt))
        freq.update(w for w in re.findall(r"[\u4e00-\u9fff]{2,6}|[A-Za-z][A-Za-z0-9_]+", txt) if len(w) > 1)
    minutes = max(1, round(chars / a.cjk_chars))
    if a.json:
        print(json.dumps({"files": len(files), "chars": chars, "words": words, "lines": lines,
                          "read_minutes": minutes,
                          "top": freq.most_common(a.top)}, ensure_ascii=False, indent=2))
    else:
        print("文件: %d ｜ 字符: %d ｜ 英文词: %d ｜ 行: %d ｜ 预计阅读: %d 分钟" % (len(files), chars, words, lines, minutes))
        print("词频 Top %d: %s" % (a.top, ", ".join("%s(%d)" % kv for kv in freq.most_common(a.top))))
    sys.exit(0)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "regex-sandbox", "snake": "regex_sandbox",
        "dn_zh": "正则沙盒", "dn_en": "Regex Sandbox",
        "glyph": ".*",
        "desc": "正则即写即测：匹配/分组捕获/替换预览/标志位，无匹配给 rc=1，调正则不用来回跑脚本（零依赖）",
        "pain": "调正则全靠改代码重跑，写错一次 debug 半天",
        "src": r'''
import argparse, json, re, sys

def main():
    ap = argparse.ArgumentParser(description="regex-sandbox · 正则即写即测（零依赖）")
    ap.add_argument("--pattern", required=True)
    ap.add_argument("--text", help="待测文本（缺省读 stdin）")
    ap.add_argument("--file", help="从文件读文本")
    ap.add_argument("--replace", help="替换模板（如 <b>\\1</b>）")
    ap.add_argument("--flags", default="", help="标志位组合 i(忽略大小写) m(多行) s(点匹配换行)")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    f = 0
    for c in a.flags:
        f |= {"i": re.I, "m": re.M, "s": re.S}.get(c, 0)
    try:
        pat = re.compile(a.pattern, f)
    except re.error as e:
        print("正则编译失败: %s" % e); sys.exit(2)
    text = open(a.file, encoding="utf-8").read() if a.file else (a.text if a.text is not None else sys.stdin.read())
    ms = list(pat.finditer(text))
    if a.json:
        print(json.dumps({"matches": len(ms),
                          "groups": [{"span": list(m.span()), "match": m.group(0),
                                      "groups": list(m.groups())} for m in ms],
                          "replaced": pat.sub(a.replace, text) if a.replace is not None else None},
                         ensure_ascii=False, indent=2))
    else:
        print("匹配 %d 处" % len(ms))
        for m in ms[:50]:
            extra = "  组:" + str(list(m.groups())) if m.groups() else ""
            print("  [%d:%d] %r%s" % (m.start(), m.end(), m.group(0), extra))
        if a.replace is not None:
            print("---替换结果---")
            print(pat.sub(a.replace, text))
    sys.exit(0 if ms else 1)

if __name__ == "__main__":
    main()
''',
    },
    {
        "slug": "hash-check", "snake": "hash_check",
        "dn_zh": "文件哈希校验", "dn_en": "File Hash Check",
        "glyph": "#",
        "desc": "生成/校验目录 SHA-256 清单：下载验 integrity、传输前后比对、防篡改留证（零依赖）",
        "pain": "下载的文件不知道完不完整，传给同事再传回来不确定有没有被改",
        "src": r'''
import argparse, hashlib, json, os, sys

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def scan(root):
    out = {}
    for r, _, fs in os.walk(root):
        for f in fs:
            p = os.path.join(r, f)
            out[os.path.relpath(p, root).replace("\\", "/")] = sha256(p)
    return out

def main():
    ap = argparse.ArgumentParser(description="hash-check · SHA-256 清单生成/校验（零依赖）")
    ap.add_argument("mode", choices=["gen", "check"], help="gen=生成清单 check=校验")
    ap.add_argument("--dir", required=True)
    ap.add_argument("--manifest", default="manifest.sha256")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    if not os.path.isdir(a.dir):
        print("目录不存在: %s" % a.dir); sys.exit(2)
    cur = scan(a.dir)
    if a.mode == "gen":
        mpath = os.path.join(a.dir, a.manifest)
        with open(mpath, "w", encoding="utf-8") as f:
            for k in sorted(cur):
                f.write("%s  %s\n" % (cur[k], k))
        print("已生成 %s（%d 个文件）" % (mpath, len(cur)))
        sys.exit(0)
    mpath = os.path.join(a.dir, a.manifest)
    if not os.path.isfile(mpath):
        print("清单不存在: %s（先运行 gen）" % mpath); sys.exit(2)
    base = {}
    for line in open(mpath, encoding="utf-8"):
        if line.strip():
            h, k = line.split(None, 1)
            base[k.strip()] = h
    missing = sorted(set(base) - set(cur))
    added = sorted(set(cur) - set(base))
    changed = sorted(k for k in set(base) & set(cur) if base[k] != cur[k])
    ok = not missing and not changed
    if a.json:
        print(json.dumps({"ok": ok, "checked": len(base), "missing": missing,
                          "added": added, "changed": changed}, ensure_ascii=False, indent=2))
    else:
        print("校验: %d/%d 一致%s" % (len(base) - len(changed), len(base), " ｜ PASS" if ok else " ｜ FAIL"))
        for k in changed:
            print("  [改动] " + k)
        for k in missing:
            print("  [缺失] " + k)
        for k in added:
            print("  [新增] " + k)
    sys.exit(0 if ok else 1)

if __name__ == "__main__":
    main()
''',
    },
]

SKILLMD = """---
name: __SLUG__
description: __DN__ — __DESC__
slug: __SLUG__
version: 1.0.0
display_name: __DN__
display_name_en: __DNEN__
agent_created: true
author: zhaoxinghua09-cell
license: MIT
category: 效率工具
platforms: [claude, codex, cursor, windsurf, workbuddy]
---

# __DN__ / __DNEN__

**__SLUG__** v1.0.0 · LGD-Powered 效率工具家族 · 零依赖

## 痛点
__PAIN__

## 用法
```bash
python scripts/__SNAKE__.py --help
```
- 成功 → rc=0；发现问题 → rc=1；用法错误 → rc=2
- 支持 `--json` 机器可读输出
- 涉及写盘的操作默认 **dry-run 预览**，加 `--apply` 才执行（text-replace/dup-finder 还会先备份）

## 安全设计
- 只移动/重命名，不删除内容文件（dup-finder 的 --apply 仅删除与首个完全同哈希的副本）
- 写盘前自动备份（text-replace 生成 .bak；batch-renamer/organizer 可用 --json 记录计划回滚）

## LGD-Powered
本技能是「LGD 三律」效率家族件：把高频文件操作做成**可预览、可回滚、有留痕**的确定性工具。

## 免责
本工具为效率辅助；对重要数据请先备份并在预览确认后再 --apply。
"""

README = """# __DN__ / __DNEN__

> `__SLUG__` v1.0.0 · LGD-Powered Utility Family · Zero-dependency

**中文**：__PAIN__ 一条命令搞定；默认 dry-run 预览、`--apply` 才执行、`--json` 机器可读；成功 rc=0 / 发现问题 rc=1 / 用法错误 rc=2。

**EN**: One command for daily file/text chores. Dry-run by default, `--apply` to execute, `--json` for machines. rc=0 ok / rc=1 findings / rc=2 usage.

## Usage / 用法
```bash
python scripts/__SNAKE__.py --help
```

## Disclaimer / 免责
Efficiency aid only — back up important data before --apply. / 效率辅助，--apply 前请备份重要数据。
"""


def make_icons(slug, glyph):
    from PIL import Image, ImageDraw, ImageFont
    NAVY, TEAL, WHITE = (11, 31, 58, 255), (20, 184, 166, 255), (255, 255, 255, 255)
    img = Image.new("RGBA", (512, 512), NAVY)
    d = ImageDraw.Draw(img)
    d.ellipse([36, 36, 476, 476], outline=TEAL, width=18)
    d.ellipse([76, 76, 436, 436], outline=(20, 184, 166, 90), width=6)
    size = 170 if len(glyph) > 1 else 210
    font = None
    for p in ICONS:
        try:
            font = ImageFont.truetype(p, size)
            break
        except Exception:
            continue
    if font is not None:
        try:
            bbox = d.textbbox((0, 0), glyph, font=font)
            w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
            d.text((256 - w / 2 - bbox[0], 256 - h / 2 - bbox[1]), glyph, font=font, fill=WHITE)
        except Exception:
            font = None
    if font is None:
        d.rectangle([196, 196, 316, 316], fill=TEAL)
    img.save(BASE / slug / "icon.png")
    badge = Image.new("RGBA", (256, 96), NAVY)
    b = ImageDraw.Draw(badge)
    b.rectangle([4, 4, 251, 91], outline=TEAL, width=6)
    f2 = None
    for p in ICONS:
        try:
            f2 = ImageFont.truetype(p, 40)
            break
        except Exception:
            continue
    txt = "LGD POWERED"
    if f2 is not None:
        try:
            bbox = b.textbbox((0, 0), txt, font=f2)
            w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
            b.text((128 - w / 2 - bbox[0], 48 - h / 2 - bbox[1]), txt, font=f2, fill=TEAL)
        except Exception:
            f2 = None
    if f2 is None:
        b.rectangle([40, 34, 216, 62], fill=TEAL)
    badge.save(BASE / slug / "lgd-powered.png")


def main():
    for s in SKILLS:
        d = BASE / s["slug"]
        (d / "scripts").mkdir(parents=True, exist_ok=True)
        (d / "scripts" / (s["snake"] + ".py")).write_text(s["src"].strip() + "\n", encoding="utf-8")
        md = (SKILLMD.replace("__SLUG__", s["slug"]).replace("__DN__", s["dn_zh"])
              .replace("__DNEN__", s["dn_en"]).replace("__DESC__", s["desc"])
              .replace("__PAIN__", s["pain"]).replace("__SNAKE__", s["snake"]))
        (d / "SKILL.md").write_text(md, encoding="utf-8")
        rm = (README.replace("__SLUG__", s["slug"]).replace("__DN__", s["dn_zh"])
              .replace("__DNEN__", s["dn_en"]).replace("__PAIN__", s["pain"])
              .replace("__SNAKE__", s["snake"]))
        (d / "README.md").write_text(rm, encoding="utf-8")
        make_icons(s["slug"], s["glyph"])
        print("built:", s["slug"])


if __name__ == "__main__":
    main()
