#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
本地大模型全量实战测试台（MedXpert 24 技能）

流程（每个技能）：
  1. 校验 SKILL.md frontmatter 8 字段（确定性）
  2. py_compile 脚本（确定性，捕获语法错误）
  3. 本地模型 qwen3.5:4b 读 SKILL.md+脚本 → 生成一条实战测试命令
  4. 真实执行该命令（subprocess，60s 超时，沙箱 cwd=脚本目录）
  5. 本地模型 qwen3.5:9b 读 源码+执行结果 → 找问题点（崩溃/逻辑错/边界/虚假声明/安全）
  6. 逐条落 _llm_test_results.jsonl（增量持久化）

用法：
  python _llm_test.py              # 全量 24 技能
  python _llm_test.py context-engineering prompt-injection-shield   # 指定 pilot
"""
import os, json, re, glob, subprocess, urllib.request, sys

BASE = r"D:\Workbuddy\05-工具\agent-skills"
PY = r"C:\Users\Administrator\.workbuddy\binaries\python\versions\3.13.12\python.exe"
GEN_MODEL = "qwen3.5:4b"
REV_MODEL = "qwen3.5:9b"
OLLAMA = "http://localhost:11434/api/generate"
OUT = os.path.join(BASE, "_llm_test_results.jsonl")

REQUIRED_FM = ["name", "description", "slug", "version",
               "display_name", "display_name_en"]


def ollama(model, prompt, n=700, timeout=200, think=False):
    body = json.dumps({"model": model, "prompt": prompt, "stream": False, "think": think,
                       "options": {"num_predict": n, "temperature": 0.3}}).encode()
    req = urllib.request.Request(OLLAMA, data=body, headers={"Content-Type": "application/json"})
    r = json.loads(urllib.request.urlopen(req, timeout=timeout).read())
    return r.get("response", "").strip()


def find_skills():
    out = []
    for d in sorted(os.listdir(BASE)):
        sk = os.path.join(BASE, d, "SKILL.md")
        if os.path.isfile(sk):
            scripts = glob.glob(os.path.join(BASE, d, "scripts", "*.py"))
            out.append((d, sk, scripts[0] if scripts else None))
    return out


def validate_frontmatter(sk_path):
    txt = open(sk_path, encoding="utf-8").read()
    m = re.match(r"^---\s*\n(.*?)\n---", txt, re.S)
    fields = {}
    if m:
        for line in m.group(1).splitlines():
            if ":" in line and not line.strip().startswith("#"):
                k, v = line.split(":", 1)
                fields[k.strip()] = v.strip()
    missing = [f for f in REQUIRED_FM if f not in fields]
    return fields, missing


def norm_cmd(cmd, script_path):
    if not cmd:
        return ""
    cmd = cmd.strip().strip("`").strip()
    cmd = re.sub(r"^[$>\s]+", "", cmd)
    if cmd.lower().startswith("python "):
        cmd = '"' + PY + '" ' + cmd[7:].lstrip()
    elif cmd.lower().startswith("python"):
        cmd = '"' + PY + '" ' + cmd[6:].lstrip()
    # 安全：必须包含该技能脚本的绝对路径或文件名
    if script_path:
        norm = script_path.replace("\\", "/")
        if norm not in cmd.replace("\\", "/") and os.path.basename(script_path) not in cmd:
            return ""
    return cmd


def gen_command(skill_dir, sk_path, script_path):
    sk = open(sk_path, encoding="utf-8").read()
    src = open(script_path, encoding="utf-8").read() if script_path else ""
    prompt = (
        "你是一名资深 QA 工程师。下面是一个 AI Agent 技能（SKILL.md 与配套 Python 脚本）。\n"
        "请生成【一条】可在 Windows 命令行直接运行的、用于实战测试该脚本主功能的命令。\n"
        "要求：\n"
        "1. 命令必须以 python 开头，且 python 后第一个参数是脚本绝对路径：" + script_path + "\n"
        "2. 必须提供真实合理的示例参数（提示词/URL/样本文本/数字等），让脚本真正执行主逻辑而非仅打印帮助；"
        "先读脚本的 argparse/参数定义，给出能触发核心功能的调用。\n"
        "3. 若需要文件输入，用 heredoc 或 echo 重定向在命令内联创建临时文件再引用。\n"
        "4. 只输出命令本身，不要 markdown 代码块、不要解释、不要多余文字。\n\n"
        "===== SKILL.md =====\n" + sk[:3000] + "\n\n===== SCRIPT =====\n" + src[:4000]
    )
    return norm_cmd(ollama(GEN_MODEL, prompt, n=400, timeout=120), script_path)


def run_cmd(cmd, cwd):
    if not cmd:
        return {"ok": False, "error": "未生成有效命令", "rc": None, "out": "", "err": ""}
    try:
        r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True, timeout=60,
                           encoding="utf-8", errors="replace", stdin=subprocess.DEVNULL)
        return {"ok": r.returncode == 0, "rc": r.returncode,
                "out": (r.stdout or "")[:3000], "err": (r.stderr or "")[:2000]}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "timeout", "rc": None, "out": "", "err": "执行超时60s"}
    except Exception as e:
        return {"ok": False, "error": str(e)[:200], "rc": None, "out": "", "err": ""}


def review(skill_dir, sk_path, script_path, cmd, exec_res):
    sk = open(sk_path, encoding="utf-8").read()
    src = open(script_path, encoding="utf-8").read() if script_path else ""
    ex = json.dumps(exec_res, ensure_ascii=False)
    prompt = (
        "你是一名严格的代码审计与 QA 专家。请基于以下信息，找出该 AI 技能的【问题点】。\n"
        "重点关注：\n"
        "- 脚本能否真正运行（结合执行结果）；\n"
        "- 逻辑错误 / 崩溃 / 未捕获异常；\n"
        "- 边界情况缺失（空输入、超长、特殊字符、编码、Windows 路径）；\n"
        "- 与 SKILL.md 描述不符的虚假声明；\n"
        "- 安全隐患（命令注入、路径穿越、eval/exec 任意代码）；\n"
        "- 可维护性（硬编码、无错误处理、无依赖声明）。\n"
        "若无明显问题，只回复 NONE。否则用中文要点列表（每条一行，最多 8 条），具体可执行。\n\n"
        "===== SKILL.md =====\n" + sk[:3000] + "\n\n===== SCRIPT =====\n" + src[:5000] +
        "\n\n===== 测试命令 =====\n" + cmd + "\n\n===== 执行结果 =====\n" + ex
    )
    return ollama(REV_MODEL, prompt, n=700, timeout=200)


def process(skill_dir, sk_path, script_path):
    rec = {"skill": skill_dir}
    fields, missing = validate_frontmatter(sk_path)
    rec["frontmatter_missing"] = missing
    if not script_path:
        rec["error"] = "无脚本"
        return rec
    try:
        subprocess.run([PY, "-m", "py_compile", script_path], check=True,
                       capture_output=True, timeout=30, encoding="utf-8", errors="replace")
        rec["compile"] = "ok"
    except subprocess.CalledProcessError as e:
        rec["compile"] = "FAIL"
        rec["compile_err"] = (e.stderr or "")[:1500]
    cmd = gen_command(skill_dir, sk_path, script_path)
    rec["cmd"] = cmd
    ex = run_cmd(cmd, os.path.dirname(script_path))
    rec["exec"] = ex
    rec["review"] = review(skill_dir, sk_path, script_path, cmd, ex)
    return rec


def main():
    only = sys.argv[1:]
    skills = find_skills()
    if only:
        skills = [s for s in skills if s[0] in only]
    with open(OUT, "w", encoding="utf-8") as f:  # 覆盖式开始
        pass
    for skill_dir, sk_path, script_path in skills:
        print(f"[*] {skill_dir}", flush=True)
        rec = process(skill_dir, sk_path, script_path)
        with open(OUT, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        print(f"    compile={rec.get('compile')} exec_ok={rec.get('exec',{}).get('ok')} "
              f"fm_missing={rec.get('frontmatter_missing')}", flush=True)
    print("DONE", len(skills), flush=True)


if __name__ == "__main__":
    main()
