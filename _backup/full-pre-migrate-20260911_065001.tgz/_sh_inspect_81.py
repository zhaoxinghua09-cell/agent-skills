import json, os, re, subprocess, zipfile, shutil, sys
from pathlib import Path

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
CLI = "C:/Users/Administrator/.skillhub/skills_store_cli.py"
ZIP_DIR = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/SkillHub上架包_81家族_20260908")
STAGE = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/SkillHub_81_stage")
STAGE.mkdir(parents=True, exist_ok=True)

# 已上线，跳过（5 + Batch I 6）
ALREADY = {
    "session-continuity-protocol","dpapi-local-vault","medxpert-brain-learning-memory",
    "agent-evolution","a3-law-operational",
    "udi-format-validator","clin-eval-route-picker","pmcf-plan-check",
    "md-link-audit","changelog-draft-gen","env-var-audit",
}

zips = sorted(ZIP_DIR.glob("*.zip"))
results = []
for z in zips:
    slug = z.stem
    if slug in ALREADY:
        results.append({"slug": slug, "skip": "already_on_skillhub"})
        continue
    dest = STAGE / slug
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(z) as zf:
        zf.extractall(dest)
    # 找 SKILL.md（可能在子目录）
    skill_md = None
    for root, _, files in os.walk(dest):
        if "SKILL.md" in files:
            skill_md = Path(root) / "SKILL.md"
            break
    rec = {"slug": slug, "zip": z.name}
    if not skill_md:
        rec["error"] = "no_SKILL.md_in_zip"
        results.append(rec); continue
    # 二进制检测
    bins = []
    for root, _, files in os.walk(dest):
        for f in files:
            if f.lower().endswith((".png",".jpg",".jpeg",".gif",".ico",".zip")):
                bins.append(os.path.relpath(os.path.join(root,f), dest))
    rec["binaries"] = bins
    # frontmatter
    txt = skill_md.read_text(encoding="utf-8")
    fm = {}
    m = re.search(r"^---\s*\n(.*?)\n---", txt, re.S)
    if m:
        for line in m.group(1).splitlines():
            if ":" in line and not line.startswith(" "):
                k,_,v = line.partition(":")
                fm[k.strip()] = v.strip().strip('"').strip("'")
    rec["author"] = fm.get("author","")
    rec["name"] = fm.get("name","")
    rec["displayName"] = fm.get("displayName","")
    rec["category"] = fm.get("category","")
    rec["has_license"] = (dest / "LICENSE.md").exists() or (dest / "LICENSE").exists()
    rec["has_manifest"] = (dest / "manifest.json").exists()
    rec["has_attest"] = (dest / "ATTESTATION.md").exists()
    # dry-run
    try:
        r = subprocess.run([PY, CLI, "publish", str(dest), "--dry-run", "--json"],
                           capture_output=True, text=True, timeout=120)
        out = (r.stdout + r.stderr)
        try:
            j = json.loads(r.stdout)
            rec["dryrun_ok"] = j.get("ok") or j.get("success") or ("error" not in j)
            rec["dryrun_msg"] = j.get("message") or j.get("error") or ""
        except Exception:
            rec["dryrun_ok"] = ("error" not in out.lower()) and ("失败" not in out)
            rec["dryrun_msg"] = out[:300]
    except Exception as e:
        rec["dryrun_ok"] = False
        rec["dryrun_msg"] = f"EXC:{e}"
    results.append(rec)

# 汇总
ok = [r for r in results if r.get("dryrun_ok")]
needfix = [r for r in results if "skip" not in r and not r.get("dryrun_ok")]
binned = [r["slug"] for r in results if r.get("binaries")]
print("TOTAL zips:", len(zips))
print("SKIP(already):", sum(1 for r in results if r.get("skip")))
print("DRYRUN OK:", len(ok))
print("NEED FIX:", len(needfix))
print("HAVE BINARIES:", len(binned), binned)
print("\n--- NEED FIX ---")
for r in needfix:
    print(r["slug"], "|", r.get("dryrun_msg","")[:200])
print("\n--- category values seen ---")
cats = {}
for r in results:
    if "category" in r:
        cats[r["category"]] = cats.get(r["category"],0)+1
print(json.dumps(cats, ensure_ascii=False))
Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/_sh_inspect_81.json").write_text(
    json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")
print("\nwrote _sh_inspect_81.json")
