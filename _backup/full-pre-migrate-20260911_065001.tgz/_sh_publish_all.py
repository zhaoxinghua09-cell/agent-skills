# -*- coding: utf-8 -*-
"""
_sh_publish_all.py — SkillHub 总发布编排器（2026-09-09 全量发布日）

价值优先序:
  A. 5 个已上架低分技能升级包 (SkillHub_5_upgrade_v1, 评测 4.6 以下修复)
  B. 行业 6 包判定器首发   (SkillHub_industry6_v1, P-065 大使×理论宣传载体)
  C. 81 家族扫尾           (subprocess 直跑 _sh_upgrade_81.py, 两阶段轮次扫荡, 幂等)
     ⚠️ A/B 组零成功(窗口未开)时自动跳过 C, 不空烧。

节奏设计( lessons learned 2026-09-09 ):
  - 轮内固定 PACING=90s 包间隔, 不做指数退避(关窗时指数退避会拖成十几小时)
  - 轮间 PASS_GAP 起步 600s, 零进展轮 ×2 (cap 1800s), 有进展重置
  - 连续 EARLY_STOP 轮零进展早停; 单包最多 MAX_TRY 次
  - 环境变量可覆盖: SH_MAX_PASSES / SH_MAX_TRY / SH_PASS_GAP
发布前复跑独立闸门扫描 _sh_gate_scan.py(永不 import 流水线脚本)。
全程幂等: already_exists 记为成功, 任何时刻可安全重跑。
"""
import json
import os
import subprocess
import sys
import time
from pathlib import Path

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
CLI = "C:/Users/Administrator/.skillhub/skills_store_cli.py"
BASE = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划")
GATE = Path("D:/Workbuddy/05-工具/agent-skills/_sh_gate_scan.py")
UP81 = Path("D:/Workbuddy/05-工具/agent-skills/_sh_upgrade_81.py")
LOG = BASE / "_sh_publish_all.log"
RESULT = BASE / "_sh_publish_all_result.json"

CHG_A = "爆款优化·补反模式FAQ+错误处理/失败模式+能力边界+LGD徽章+安装矩阵（评测弱项修复）"
CHG_B = "行业专用判定器首发·六段式+JSON IR+真实错误码+真机案例+LGD徽章+安装矩阵"

GROUPS = [
    ("A-5低分修复", BASE / "SkillHub_5_upgrade_v1", CHG_A,
     ["a3-law-operational", "agent-evolution", "dpapi-local-vault",
      "session-continuity-protocol", "doc-extract"]),
    ("B-行业6包首发", BASE / "SkillHub_industry6_v1", CHG_B,
     ["uas-ops-checker", "aut-grade-checker", "data-grade-checker",
      "hgrac-route-checker", "fin-ai-classifier", "evid-four-check"]),
]

PACING = 90                                    # 轮内固定包间隔(秒)
PASS_GAP = int(os.environ.get("SH_PASS_GAP", "600"))   # 轮间间隔起步
PASS_GAP_MAX = 1800
MAX_PASSES = int(os.environ.get("SH_MAX_PASSES", "8"))
MAX_TRY = int(os.environ.get("SH_MAX_TRY", "3"))
EARLY_STOP = 3                                 # 连续零进展轮数→早停


def log(msg):
    line = time.strftime("%H:%M:%S ") + str(msg)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")
    print(line, flush=True)


def read_version(pkg):
    for line in (pkg / "SKILL.md").read_text(encoding="utf-8").splitlines():
        if line.strip().startswith("version:"):
            return line.split(":", 1)[1].strip().strip('"').strip("'")
    return None


def attempt_publish(pkg, ver, changelog):
    """单次发布尝试 → (status, msg)。status ∈ ok/exists/throttled/error"""
    args = [PY, CLI, "publish", str(pkg), "--version", ver, "--changelog", changelog]
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=180)
    except Exception as e:
        return "error", f"EXC:{e}"
    out = (r.stdout or "") + (r.stderr or "")
    if "Published" in out or "skillId" in out:
        sid = ""
        if "skillId" in out:
            sid = " skillId=" + out.split("skillId", 1)[1].lstrip("=:）) ").split(",")[0].split("）")[0][:12]
        return "ok", ("Published" + sid)
    if "already exists" in out or "已存在" in out or "冲突" in out:
        return "exists", "already_exists"
    if "过于频繁" in out or "429" in out or "频率" in out or "请求过于频繁" in out:
        return "throttled", out.strip()[-80:]
    return "error", out.strip()[-300:]


def gate_scan(stage_dir):
    """独立闸门扫描, 返回命中包名集合"""
    r = subprocess.run([PY, str(GATE), str(stage_dir)], capture_output=True, text=True, timeout=300)
    hits = set()
    for line in (r.stdout or "").splitlines():
        if "❌ HIT" in line:
            hits.add(line.split(":")[0].strip())
    return hits


def run_group(name, stage, changelog, slugs):
    log(f"===== 组{name}: {len(slugs)} 包 =====")
    hits = gate_scan(stage)
    if hits:
        log(f"  闸门拦截: {sorted(hits)}")
    queue = []
    for s in slugs:
        pkg = stage / s
        ver = read_version(pkg)
        if not ver:
            log(f"  {s}: SKIP 无版本号")
            continue
        if s in hits:
            log(f"  {s}: SKIP 敏感闸门命中")
            continue
        queue.append([s, pkg, ver, 0])  # slug, pkg, ver, tries

    done, results = {}, {}
    zero_streak, gap = 0, PASS_GAP
    for p in range(1, MAX_PASSES + 1):
        pending = [it for it in queue if it[0] not in done and it[3] < MAX_TRY]
        log(f"  --- PASS {p} (待发={len(pending)}, 轮间gap={gap}s) ---")
        if not pending:
            break
        progress = 0
        for idx, item in enumerate(pending):
            s, pkg, ver, _ = item
            item[3] += 1
            st, msg = attempt_publish(pkg, ver, changelog)
            if st in ("ok", "exists"):
                done[s] = msg
                results[s] = {"status": "ok" if st == "ok" else "exists", "msg": msg, "ver": ver}
                progress += 1
                log(f"  {s} v{ver}: ✅ {msg}")
            elif st == "throttled":
                log(f"  {s} v{ver}: ⏳ 429 (try {item[3]}/{MAX_TRY}) last={msg}")
            else:
                results[s] = {"status": "error", "msg": msg, "ver": ver}
                done[s] = "error"  # 真错误不重试
                log(f"  {s} v{ver}: ❌ {msg}")
            if idx < len(pending) - 1:
                time.sleep(PACING)
        if all(it[0] in done or it[3] >= MAX_TRY for it in queue):
            log("  所有包已终态(ok/exists/error)或尝试用尽")
            break
        zero_streak = zero_streak + 1 if progress == 0 else 0
        gap = PASS_GAP if progress else min(PASS_GAP_MAX, gap * 2)
        if zero_streak >= EARLY_STOP:
            log(f"  连续 {EARLY_STOP} 轮零进展 → 早停, 待发 {[i[0] for i in queue if i[0] not in done]}")
            break
        if p < MAX_PASSES:
            log(f"  整轮歇 {gap}s")
            time.sleep(gap)
    for it in queue:
        if it[0] not in done:
            results[it[0]] = {"status": "pending", "msg": "窗口未开/尝试用尽", "ver": it[2]}
    ok_n = sum(1 for v in results.values() if v["status"] in ("ok", "exists"))
    log(f"  组{name}小计: ok/exists={ok_n}/{len(queue)}")
    return results


def main():
    log("========== 总发布编排启动 ==========")
    all_results = {}
    for name, stage, chg, slugs in GROUPS:
        all_results.update({f"{name}:{k}": v for k, v in run_group(name, stage, chg, slugs).items()})
        RESULT.write_text(json.dumps(all_results, ensure_ascii=False, indent=1), encoding="utf-8")

    ab_ok = sum(1 for v in all_results.values() if v.get("status") in ("ok", "exists"))
    if ab_ok == 0:
        log("窗口未开（A/B 组零成功）→ 跳过 81 扫尾，全部转待发，等窗口/明日自动化。")
        all_results["_81_sweep"] = {"status": "skipped", "msg": "A/B 零成功，窗口未开"}
    else:
        log("===== C-81家族扫尾: 启动 _sh_upgrade_81.py (两阶段轮次扫荡) =====")
        try:
            r = subprocess.run([PY, str(UP81)], capture_output=True, text=True, timeout=6 * 3600)
            tail = (r.stdout or "").strip().splitlines()[-6:]
            for t in tail:
                log("  [81] " + t)
            log(f"  81 扫尾退出码={r.returncode}")
            all_results["_81_sweep"] = {"status": "done", "msg": f"returncode={r.returncode}"}
        except Exception as e:
            log(f"  81 扫尾异常: {e}")
            all_results["_81_sweep"] = {"status": "error", "msg": str(e)}

    RESULT.write_text(json.dumps(all_results, ensure_ascii=False, indent=1), encoding="utf-8")
    log(f"========== 编排结束: A/B 组 ok={ab_ok}/11, 81 细节见 _sh_upgrade_81.log ==========")


if __name__ == "__main__":
    main()
