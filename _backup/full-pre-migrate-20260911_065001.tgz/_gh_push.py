# -*- coding: utf-8 -*-
"""通过 GitHub Contents API 推送 agent-skills 4 技能到 zhaoxinghua09-cell/agent-skills。
密钥经 vault.py 在子进程内获取，绝不进入对话/打印。
用法：python _gh_push.py
"""
import base64
import json
import pathlib
import subprocess
import urllib.request

VAULT_PY = "C:/Users/Administrator/.ucvault_local/vault.py"
PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
OWNER = "zhaoxinghua09-cell"
REPO = "agent-skills"
BRANCH = "main"
BASE = pathlib.Path("D:/Workbuddy/05-工具/agent-skills")

def get_token():
    r = subprocess.run([PY, VAULT_PY, "get", "github_api_key"],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError("vault get failed: " + r.stderr[:200])
    return r.stdout.strip()

TOKEN = get_token()
HEAD = {"Authorization": f"Bearer {TOKEN}", "Accept": "application/vnd.github+json",
        "User-Agent": "agent-skills-push", "X-GitHub-Api-Version": "2022-11-28"}

def api(method, url, data=None):
    req = urllib.request.Request(url, data=json.dumps(data).encode() if data else None,
                                 headers=HEAD, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return resp.status, json.loads(resp.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="replace")[:300]
        return e.code, {"error": body}

# 连通性测试
st, me = api("GET", "https://api.github.com/user")
print("connectivity:", st, me.get("login", me.get("error", "")))
if st != 200:
    print("PAT 不可用，终止（改用 MCP 文本推送）")
    raise SystemExit(1)

def put_file(gh_path, content_bytes):
    url = f"https://api.github.com/repos/{OWNER}/{REPO}/contents/{gh_path}"
    st0, cur = api("GET", url)
    sha = cur.get("sha") if st0 == 200 else None
    body = base64.b64encode(content_bytes).decode()
    data = {"message": f"add {gh_path} (agent-skills hit skills)", "content": body, "branch": BRANCH}
    if sha:
        data["sha"] = sha
    st, resp = api("PUT", url, data)
    ok = st in (200, 201)
    print(f"  {'OK' if ok else 'FAIL'} {st} {gh_path}")
    return ok

def put_text_github(gh_path, text):
    return put_file(gh_path, text.encode("utf-8"))

def put_bin_github(gh_path, local_path):
    return put_file(gh_path, local_path.read_bytes())

skills = {
    "context-engineering": "scripts/context_budget.py",
    "ai-cost-cutter": "scripts/cost_estimator.py",
    "prompt-injection-shield": "scripts/prompt_injection_scan.py",
    "eu-ai-act-companion": "scripts/eu_ai_act_nav.py",
}

count = 0
for slug, script in skills.items():
    for f in ["SKILL.md", "README.md", "icon.png", "lgd-powered.png", script]:
        # 本地：agent-skills/<slug>/<f>  →  GitHub：skills/<slug>/<f>
        local = BASE / slug / f
        gh = f"skills/{slug}/{f}"
        if f.endswith(".png"):
            if put_bin_github(gh, local): count += 1
        else:
            if put_text_github(gh, local.read_text(encoding="utf-8")): count += 1

# 根级
if put_text_github("README.md", (BASE / "README.md").read_text(encoding="utf-8")): count += 1
if put_text_github("index.jsonld", (BASE / "index.jsonld").read_text(encoding="utf-8")): count += 1
# 根 lgd-powered.png
if put_bin_github("lgd-powered.png", BASE / "lgd-powered.png"): count += 1

print(f"\n推送完成文件数：{count}")
