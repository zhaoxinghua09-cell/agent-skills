# -*- coding: utf-8 -*-
"""Batch I 六款技能的脚本源码常量。外层三引号内禁三引号；生成码只用 % 格式化。"""

S_UDI_FORMAT_VALIDATOR = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# UDI 格式校验器（零依赖 / 确定性 / JSON IR / 修复回执）
# 支持 GS1 应用标识符 01/10/11/17/21/240/30；校验位按 GS1 Mod10。
import argparse, json, re, sys

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

FIXED_AI = {"01": 14, "11": 6, "17": 6}
VAR_AI = {"10": 20, "21": 20, "240": 30, "30": 8}
ALL_AI = list(FIXED_AI) + list(VAR_AI)


def gs1_check(d13):
    w = 3
    s = 0
    for ch in reversed(d13):
        s += int(ch) * w
        w = 4 - w
    return str((10 - s % 10) % 10)


def valid_ymd(s):
    if not re.match(r"^\\d{6}$", s):
        return False
    mm, dd = int(s[2:4]), int(s[4:6])
    return 1 <= mm <= 12 and 0 <= dd <= 31


def pretty_ymd(s):
    dd = int(s[4:6])
    note = "(00=当月最后一天)" if dd == 0 else ""
    return "%04d-%s-%02d%s" % (2000 + int(s[:2]), s[2:4], dd, note)


def parse_paren(text):
    comps, errors = {}, []
    tokens = re.findall(r"\\((\\d{2})\\)([^\\(\\)]*)", text)
    prefix = text.split("(")[0]
    if prefix.strip():
        errors.append(("UDI_E_UNKNOWN_AI", "前缀", prefix.strip(), "串首存在非标识内容，请核对输入"))
    for ai, val in tokens:
        if ai in comps:
            errors.append(("UDI_E_UNKNOWN_AI", ai, val, "同一 AI 重复出现"))
        comps[ai] = val.strip()
    return comps, errors


def parse_plain(text):
    comps, errors = {}, []
    m = re.match(r"^01(\\d{14})", text)
    if not m:
        errors.append(("UDI_E_AMBIGUOUS", "整体", "", "无括号形态仅支持以 (01)+14 位开头的串；请改用带括号输入"))
        return comps, errors
    comps["01"] = m.group(1)
    rest = text[16:]
    pos = 0
    while pos < len(rest):
        ai = rest[pos:pos + 2]
        if ai in FIXED_AI:
            ln = FIXED_AI[ai]
            val = rest[pos + 2:pos + 2 + ln]
            if len(val) < ln:
                errors.append(("UDI_E_LEN", ai, val, "固定长段不足 %d 位" % ln))
                break
            comps[ai] = val
            pos += 2 + ln
        elif ai in VAR_AI:
            errors.append(("UDI_E_AMBIGUOUS", ai, "", "变长段在无括号串中无法定界；请使用带括号形态"))
            break
        else:
            errors.append(("UDI_E_UNKNOWN_AI", ai, rest[pos:pos + 8], "仅支持 " + ",".join(ALL_AI)))
            break
    return comps, errors


def validate_di(di, errors):
    if not di:
        errors.append(("UDI_E_LEN", "01", "", "缺少 UDI-DI：请提供 (01) 段或 --di"))
        return
    if len(di) != 14 or not di.isdigit():
        errors.append(("UDI_E_LEN", "01", di, "DI 固定 14 位数字"))
        return
    calc = gs1_check(di[:13])
    if calc != di[13]:
        errors.append(("UDI_E_CHECKDIGIT", "01", "期望 %s 实得 %s" % (calc, di[13]), "按 13 位数据位重算校验位或核对录入"))


def main():
    ap = argparse.ArgumentParser(prog="udi_format_validator", description="UDI 格式校验器（GS1 AI 01/10/11/17/21/240/30）")
    ap.add_argument("udi", nargs="?", help="UDI 串，推荐带括号形态 (01)...(17)...(10)...")
    ap.add_argument("--di", help="仅校验 14 位 UDI-DI")
    ap.add_argument("--type", choices=["udi", "basic"], default="udi", help="udi=带生产标识的 UDI；basic=Basic UDI-DI")
    ap.add_argument("--json", action="store_true", help="输出 JSON 中间表示")
    a = ap.parse_args()
    if not a.udi and not a.di:
        ap.error("需要提供 UDI 串或 --di")
    errors, notes = [], []
    comps = {}
    if a.type == "basic":
        code = (a.di or a.udi or "").strip()
        if re.search(r"\\(\\d{2}\\)", code):
            errors.append(("UDI_E_UNKNOWN_AI", "basic", code, "Basic UDI-DI 不含 AI 括号段；请去掉 (01) 等包装标识"))
        if not re.match(r"^[A-Za-z0-9\\-]{6,}$", code):
            errors.append(("UDI_E_LEN", "basic", code, "Basic UDI-DI 应为发码机构签发的字母数字串"))
        notes.append("Basic UDI-DI 结构与归属由发码机构（GS1 AIDC/HIBCC/ICCBBA）定义，格式通过仍需向发码机构核验。")
        comps = {"basic": code}
    else:
        if a.di:
            comps["01"] = a.di.strip()
            src = a.di.strip()
        else:
            src = a.udi.strip()
            if re.search(r"\\(\\d{2}\\)", src):
                comps, errs2 = parse_paren(src)
                errors.extend(errs2)
            else:
                comps, errs2 = parse_plain(src)
                errors.extend(errs2)
        if a.di and re.search(r"\\(\\d{2}\\)", src):
            errors.append(("UDI_E_LEN", "01", src, "--di 只接受 14 位纯数字，不要带括号段"))
            comps["01"] = ""
        validate_di(comps.get("01", ""), errors)
        for ai, label in (("17", "失效日期"), ("11", "生产日期")):
            if ai in comps and comps[ai] and not valid_ymd(comps[ai]):
                errors.append(("UDI_E_DATE", ai, comps[ai], "%s 应为 YYMMDD，日位 00 表示当月最后一天" % label))
        for ai in comps:
            if ai not in ALL_AI:
                errors.append(("UDI_E_UNKNOWN_AI", ai, comps[ai], "仅支持 " + ",".join(ALL_AI)))
        pi = [ai for ai in ("10", "21", "11", "17", "240", "30") if comps.get(ai)]
        if not errors and not pi and a.type == "udi" and not a.di:
            notes.append("未发现生产标识（PI）段：仅有 DI 的串请用 --di 或确认是否漏扫。")
        notes.append("NMPA：三类械 UDI 已全面实施（2022-06-01 起），二类自 2024-06-01 起实施；以官方最新通告为准。")
        notes.append("EU MDR：上市还需 Basic UDI-DI 并录入 EUDAMED；与 UDI-DI 是两个层级。")
        if comps.get("17") and valid_ymd(comps["17"]):
            comps["17_pretty"] = pretty_ymd(comps["17"])
        if comps.get("11") and valid_ymd(comps["11"]):
            comps["11_pretty"] = pretty_ymd(comps["11"])

    valid = not errors
    if a.json:
        out = {"valid": valid, "type": a.type, "parsed": comps, "notes": notes}
        if errors:
            out["errors"] = [{"code": c, "subject": s, "evidence": e, "fixes": [f]} for c, s, e, f in errors]
        print(json.dumps(out, ensure_ascii=False, indent=2))
    else:
        if a.type == "basic":
            print("Basic UDI-DI 校验：%s" % ("通过" if valid else "未通过"))
            if comps.get("basic"):
                print("  code: %s" % comps["basic"])
        else:
            print("UDI 校验：%s" % ("通过" if valid else "未通过"))
            di = comps.get("01", "")
            if di:
                ok = "✓" if not any(c == "UDI_E_CHECKDIGIT" or c == "UDI_E_LEN" for _, s, _, _ in errors if s == "01") else "✗"
                print("  DI        %-16s 校验位 %s（GS1 Mod10）" % (di, ok))
            if comps.get("17"):
                print("  失效日期  %-16s %s" % (comps["17"], comps.get("17_pretty", "")))
            if comps.get("11"):
                print("  生产日期  %-16s %s" % (comps["11"], comps.get("11_pretty", "")))
            for ai, label in (("10", "批号"), ("21", "序列号"), ("240", "附加标识"), ("30", "数量")):
                if comps.get(ai):
                    print("  %-10s %s" % (label, comps[ai]))
        for c, s, e, f in errors:
            print("  [%s] %s: %s -> %s" % (c, s, e or "-", f))
        for n in notes:
            print("提示：%s" % n)
    sys.exit(0 if valid else 1)


if __name__ == "__main__":
    main()
'''

S_CLIN_EVAL_ROUTE_PICKER = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 临床评价路径选择器（零依赖 / 确定性判定树 / JSON IR / 修复回执）
# 规则依据：NMPA 2021年第73号通告体系 + EU MDCG 2020-6 / MDR Art.61。输出为导航建议，以官方最新为准。
import argparse, json, sys

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


def route_nmpa(a, warns):
    cls = a.nmpa_class
    if cls == "I":
        route = "无需临床评价（临床评价资料豁免路径）"
        basis = ["《医疗器械注册与备案管理办法》（国家市场监督管理总局令第47号）",
                 "国家药监局 2021 年第 73 号通告及其配套指南"]
        evidence = ["证明产品安全性、有效性的其他研究资料",
                    "与免临床评价情形的符合性说明"]
        if a.implant == "yes":
            warns.append("输入为 I 类+植入：常见植入器械多为 II/III 类，请复核分类判定依据。")
        return {"market": "NMPA", "route": route, "basis": basis, "evidence": evidence, "notes": warns}
    if a.in_catalog == "yes":
        route = "免临床评价路径（列入《免于临床评价医疗器械目录》）"
        evidence = ["与目录条文的对比说明（适用范围/结构组成/性能指标逐项）",
                    "与同品种医疗器械的对比资料",
                    "目录对比不符项的评价资料"]
        basis = ["国家药监局 2021 年第 73 号通告",
                 "《免于临床评价医疗器械目录》（最新版）"]
        if a.eq_data == "yes":
            warns.append("同时具备同品种临床数据：目录路径优先，等同路径可作备选。")
        return {"market": "NMPA", "route": route, "basis": basis, "evidence": evidence, "notes": warns}
    if a.eq_data == "yes":
        route = "同品种临床评价路径"
        evidence = ["同品种器械的临床数据（文献/数据库/上市后数据）",
                    "差异部分的科学证据与验证资料",
                    "等同性论证对比表（适用范围/技术特征/生物学特性）"]
        basis = ["国家药监局 2021 年第 73 号通告",
                 "《医疗器械临床评价等同性论证技术指导原则》",
                 "《医疗器械同品种临床评价注册审查指导原则》"]
        return {"market": "NMPA", "route": route, "basis": basis, "evidence": evidence, "notes": warns}
    route = "临床试验路径（或先评估能否补充证据转入同品种路径）"
    evidence = ["临床试验方案与伦理审查文件",
                "临床试验机构备案（械临备）",
                "若为创新器械：考虑创新审查通道（绿色通道）"]
    basis = ["国家药监局 2021 年第 73 号通告",
             "《医疗器械临床试验质量管理规范》（GCP）"]
    if a.novel == "yes":
        route = "临床试验路径（新型器械，通常无同品种可用）"
    return {"market": "NMPA", "route": route, "basis": basis, "evidence": evidence, "notes": warns}


def route_eu(a, warns):
    cls = a.eu_class
    if a.wet == "yes":
        if cls == "III" or a.implant == "yes":
            warns.append("WET 名单路径一般不适用于 III 类/植入器械，请复核 MDCG 2020-6 适用条件。")
        route = "文献路径（Well-Established Technology, WET）"
        basis = ["MDCG 2020-6（Regulation (EU) 2017/745 项下充分成熟技术的临床证据要求）",
                 "MDR Annex XIV Part A"]
        evidence = ["WET 名单符合性说明",
                    "文献检索方案与报告（PRISMA 建议引用）",
                    "等同器械证据（如使用）"]
        return {"market": "EU MDR", "route": route, "basis": basis, "evidence": evidence, "notes": warns}
    if cls == "III" or a.implant == "yes":
        route = "临床调查为主路径（MDR Art.61(1)）"
        basis = ["MDR Art.61 / Annex XV", "MDCG 2020-6", "MEDDEV 2.7/1 rev 4（方法学参考）"]
        evidence = ["临床调查方案与伦理批件", "安全性随访计划", "等同器械路径仅在严格等同条件下可替代"]
        return {"market": "EU MDR", "route": route, "basis": basis, "evidence": evidence, "notes": warns}
    if cls == "I":
        route = "临床评价仍需开展，通常无需临床调查（Class I）"
        basis = ["MDR Art.61(10)", "MDCG 2020-6", "MDCG 2020-7 PMCF 计划模板"]
        evidence = ["文献综述与状态评价（SOTA）", "上市后监督（PMS）计划", "性能与安全参数符合性证据"]
        return {"market": "EU MDR", "route": route, "basis": basis, "evidence": evidence, "notes": warns}
    route = "文献/同品种证据组合路径（视证据充分性，必要时补充临床调查）"
    basis = ["MDCG 2020-6", "MEDDEV 2.7/1 rev 4（方法学参考）", "MDR Annex XIV"]
    evidence = ["等同器械 Technical File 可及性确认", "文献检索与评价报告", "差距分析（gap analysis）"]
    if a.ai_samd == "yes":
        warns.append("MDCG 2019-11：诊断类 SaMD 按 Rule 11 常落入 III 类，请先完成分类确认。")
    return {"market": "EU MDR", "route": route, "basis": basis, "evidence": evidence, "notes": warns}


def main():
    ap = argparse.ArgumentParser(prog="clin_eval_route_picker", description="临床评价路径确定性选择器（NMPA/EU MDR）")
    ap.add_argument("--market", choices=["nmpa", "eu", "both"], default="nmpa")
    ap.add_argument("--nmpa-class", choices=["I", "II", "III", "unknown"], default="unknown")
    ap.add_argument("--eu-class", choices=["I", "IIa", "IIb", "III", "unknown"], default="unknown")
    ap.add_argument("--in-catalog", choices=["yes", "no", "unknown"], default="unknown", help="是否列入免临床目录")
    ap.add_argument("--eq-data", choices=["yes", "no", "unknown"], default="unknown", help="有无同品种临床数据")
    ap.add_argument("--novel", choices=["yes", "no"], default="no", help="是否新型器械")
    ap.add_argument("--implant", choices=["yes", "no"], default="no")
    ap.add_argument("--ai-samd", choices=["yes", "no"], default="no")
    ap.add_argument("--wet", choices=["yes", "no", "unknown"], default="unknown", help="EU：是否属成熟技术 WET")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    errors = []
    need_nmpa = a.market in ("nmpa", "both")
    need_eu = a.market in ("eu", "both")
    if need_nmpa and a.nmpa_class == "unknown":
        errors.append(("CE_E_MISSING", "--nmpa-class", "market 含 nmpa 但未给分类", "补 --nmpa-class I/II/III"))
    if need_nmpa and a.nmpa_class != "I" and a.in_catalog == "unknown":
        errors.append(("CE_E_MISSING", "--in-catalog", "未给免临床目录状态", "补 yes/no"))
    if need_nmpa and a.nmpa_class != "I" and a.in_catalog == "no" and a.eq_data == "unknown":
        errors.append(("CE_E_MISSING", "--eq-data", "目录外产品需同品种数据状态", "补 yes/no"))
    if need_eu and a.eu_class == "unknown":
        errors.append(("CE_E_MISSING", "--eu-class", "market 含 eu 但未给分类", "补 --eu-class"))
    if a.novel == "yes" and a.eq_data == "yes":
        errors.append(("CE_E_CONFLICT", "--novel/--eq-data", "新型器械通常无同品种数据，两者同 yes 自相矛盾", "核对证据现状"))
    if a.wet == "yes" and (a.eu_class == "III" or a.implant == "yes"):
        errors.append(("CE_E_CONFLICT", "--wet", "WET 与 III 类/植入通常互斥", "复核 MDCG 2020-6"))
    if errors:
        if a.json:
            print(json.dumps({"routes": None, "errors": [
                {"code": c, "subject": s, "evidence": e, "fixes": [f]} for c, s, e, f in errors]},
                ensure_ascii=False, indent=2))
        else:
            for c, s, e, f in errors:
                print("[%s] %s: %s -> %s" % (c, s, e, f))
        sys.exit(1)
    warns = []
    routes = []
    if need_nmpa:
        r = route_nmpa(a, warns)
        r.setdefault("notes", [])
        r["notes"].append("AI 辅助诊断软件：参照《人工智能医用软件产品分类界定指导原则》，常按第三类管理，路径选择趋严。")
        r["notes"].append("以上为按现行规则文本的确定性推荐，目录与通告会更新，以官方最新为准；注册策略请由注册人员确认。")
        routes.append(r)
    if need_eu:
        r = route_eu(a, warns)
        r.setdefault("notes", [])
        r["notes"].append("MDCG 文件会持续更新，以欧盟委员会最新版本为准；本输出不构成法规意见。")
        routes.append(r)
    if a.json:
        print(json.dumps({"routes": routes}, ensure_ascii=False, indent=2))
    else:
        for r in routes:
            print("== %s ==" % r["market"])
            print("推荐路径：%s" % r["route"])
            for b in r["basis"]:
                print("  依据：%s" % b)
            for e in r["evidence"]:
                print("  需提交：%s" % e)
            for n in r["notes"]:
                print("  提示：%s" % n)
    sys.exit(0)


if __name__ == "__main__":
    main()
'''

S_PMCF_PLAN_CHECK = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# PMCF 计划完整性检查器（零依赖 / 确定性 / JSON IR / 修复回执）
# 要素依据：MDCG 2020-7 Annex I / MDCG 2019-8 核心要素提炼，以官方最新版本为准。
import argparse, json, re, sys

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

REQUIRED = [
    ("objectives", "目标（objectives）", None),
    ("methods", "方法（methods）", lambda v: bool(re.search(r"文献|survey|调查|登记|registry|真实世界|real.?world|上市后|PMS", v, re.I))),
    ("endpoints", "终点（endpoints）", None),
    ("follow_up_period", "随访期（follow-up period）", lambda v: bool(re.search(r"\\d", v))),
    ("statistical_plan", "统计考量（statistical plan）", lambda v: bool(re.search(r"样本|统计|sample|statist|目标值|置信|power|检验|alpha", v, re.I))),
    ("benefit_risk_linkage", "获益-风险关联（benefit-risk linkage）", None),
    ("pms_linkage", "PMS 衔接（PMS linkage）", None),
    ("cer_update_trigger", "CER 更新触发（CER update trigger）", None),
    ("responsible_person", "责任人（responsible person）", None),
    ("timeline", "时间表（timeline）", lambda v: bool(re.search(r"\\d|季度|月|Q[1-4]|阶段", v, re.I))),
]
METHOD_HINT = "方法建议覆盖两类以上：文献综述 / 问卷调查 / 登记库 / 真实世界数据 / 上市后监督数据"


def main():
    ap = argparse.ArgumentParser(prog="pmcf_plan_check", description="PMCF 计划核心要素完整性检查（MDCG 2020-7/2019-8 口径）")
    ap.add_argument("--plan", help="JSON 计划文件路径（键=要素名）")
    ap.add_argument("--fields", action="append", default=[], help="k=v，可重复")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    plan = {}
    if a.plan:
        try:
            with open(a.plan, encoding="utf-8") as fh:
                plan = json.load(fh)
        except Exception as e:
            print(json.dumps({"errors": [{"code": "PMCF_E_PLAN_FILE", "subject": a.plan,
                                          "evidence": str(e), "fixes": ["提供可读的 JSON 文件"]}]},
                             ensure_ascii=False))
            sys.exit(2)
    for f in a.fields:
        if "=" not in f:
            ap.error("--fields 需要 k=v 形式")
        k, v = f.split("=", 1)
        plan[k.strip()] = v.strip()
    if not plan:
        print(json.dumps({"errors": [{"code": "PMCF_E_NO_INPUT", "subject": "input",
                                      "evidence": "未提供 --plan 或 --fields",
                                      "fixes": ["任选其一提供计划内容"]}]}, ensure_ascii=False))
        sys.exit(1)
    missing, weak = [], []
    present = 0
    for key, label, qfn in REQUIRED:
        val = str(plan.get(key, "") or "").strip()
        if not val:
            missing.append({"code": "PMCF_E_MISSING_FIELD", "subject": key, "evidence": label,
                            "fixes": ["补充「%s」内容（参照 MDCG 2020-7 Annex I 要素）" % label]})
        else:
            present += 1
            if qfn is not None and not qfn(val):
                weak.append({"code": "PMCF_E_WEAK_FIELD", "subject": key, "evidence": val[:60],
                             "fixes": ["「%s」内容存疑，请补充可核验的量化描述" % label]})
    score = "%d/10" % present
    basis = ["MDCG 2020-7（PMCF 计划模板 Annex I）", "MDCG 2019-8（PMCF 方法摘要）",
             "NMPA 上市后随访要求参照国内指导原则，以官方最新为准"]
    if a.json:
        print(json.dumps({"completeness": score, "missing": missing, "weak": weak, "basis": basis},
                         ensure_ascii=False, indent=2))
    else:
        print("完整性 %s" % score)
        for m in missing:
            print("  缺失：%s -> %s" % (m["subject"], m["fixes"][0]))
        for w in weak:
            print("  存疑：%s（%s）" % (w["subject"], w["evidence"]))
        if present == 10:
            print("  %s" % METHOD_HINT)
        print("  依据：" + "；".join(basis))
    sys.exit(0 if (not missing and not weak) else 1)


if __name__ == "__main__":
    main()
'''

S_MD_LINK_AUDIT = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Markdown 链接体检器（零依赖 / 默认离线 / JSON IR / 修复回执）
# 内部相对链接与本地锚点为确定性判定；外链仅在 --net 时校验（HEAD，8s 超时，一次重试）。
import argparse, json, os, re, sys, urllib.request, urllib.error

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

EXCLUDE_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build"}
LINK_RE = re.compile(r"\\[[^\\]]*\\]\\(([^)\\s]+)(?:\\s+\\"[^\\"]*\\")?\\)")


def slugify(t):
    t = t.strip().lower()
    t = re.sub(r"[^\\w\\u4e00-\\u9fff\\- ]", "", t)
    t = t.replace(" ", "-")
    return t


def headings(path):
    out = set()
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            for line in fh:
                m = re.match(r"^#{1,6}\\s+(.+?)\\s*$", line)
                if m:
                    out.add(slugify(m.group(1)))
    except Exception:
        pass
    return out


def walk_md(root):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS and not d.startswith(".")]
        for fn in filenames:
            if fn.lower().endswith((".md", ".markdown")):
                yield os.path.join(dirpath, fn)


def check_external(url):
    req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "md-link-audit/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            return None if resp.status < 400 else "http %d" % resp.status
    except urllib.error.HTTPError as e:
        if e.code in (405, 501):
            try:
                req2 = urllib.request.Request(url, headers={"User-Agent": "md-link-audit/1.0"})
                with urllib.request.urlopen(req2, timeout=8) as resp:
                    return None if resp.status < 400 else "http %d" % resp.status
            except Exception:
                return "unreachable"
        return "http %d" % e.code
    except Exception:
        return "unreachable"


def main():
    ap = argparse.ArgumentParser(prog="md_link_audit", description="Markdown 链接体检（默认离线，内部链接确定性判定）")
    ap.add_argument("root", nargs="?", default=".", help="文档目录")
    ap.add_argument("--net", action="store_true", help="联网校验外部链接")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    if not os.path.isdir(a.root):
        print(json.dumps({"errors": [{"code": "MLK_E_NO_DIR", "subject": a.root,
                                      "evidence": "目录不存在", "fixes": ["传入正确的文档目录"]}]},
                         ensure_ascii=False))
        sys.exit(2)
    files = list(walk_md(a.root))
    if not files:
        print(json.dumps({"errors": [{"code": "MLK_E_NO_MD", "subject": a.root,
                                      "evidence": "未发现 Markdown 文件", "fixes": ["确认目录或改用其他目录"]}]},
                         ensure_ascii=False))
        sys.exit(2)
    ext_cache = {}
    results = []
    total = internal_broken = external_bad = 0
    for path in files:
        rel = os.path.relpath(path, a.root)
        try:
            text = open(path, encoding="utf-8", errors="replace").read()
        except Exception:
            continue
        own = headings(path)
        broken = []
        for m in LINK_RE.finditer(text):
            target = m.group(1).strip()
            total += 1
            if target.startswith(("http://", "https://")):
                if a.net:
                    if target not in ext_cache:
                        ext_cache[target] = check_external(target)
                    reason = ext_cache[target]
                    if reason:
                        external_bad += 1
                        broken.append({"target": target, "reason": reason})
                continue
            if target.startswith("mailto:"):
                continue
            if target.startswith("#"):
                anchor = slugify(target[1:])
                if anchor not in own:
                    internal_broken += 1
                    broken.append({"target": target, "reason": "本文件无对应标题"})
                continue
            filepart, _, anchor = target.partition("#")
            fp = os.path.normpath(os.path.join(os.path.dirname(path), filepart))
            if not os.path.exists(fp):
                internal_broken += 1
                broken.append({"target": target, "reason": "文件不存在"})
            elif anchor:
                anchor_s = slugify(anchor)
                if anchor_s not in headings(fp):
                    internal_broken += 1
                    broken.append({"target": target, "reason": "目标文件无对应标题"})
        if broken:
            results.append({"file": rel, "broken": broken})
    summary = {"files": len(files), "links": total, "internal_broken": internal_broken,
               "external_bad": external_bad}
    if a.json:
        print(json.dumps({"summary": summary, "broken_by_file": results}, ensure_ascii=False, indent=2))
    else:
        print("扫描 %d 个 Markdown 文件 · 链接 %d 条" % (len(files), total))
        for r in results:
            print("  %s" % r["file"])
            for b in r["broken"]:
                print("    %s  （%s）" % (b["target"], b["reason"]))
        if not a.net:
            print("  外部链接未校验（--net 未开启）")
        print("%s，rc=%d" % ("发现断链" if (internal_broken or external_bad) else "全部通过",
                             1 if (internal_broken or external_bad) else 0))
    sys.exit(1 if (internal_broken or external_bad) else 0)


if __name__ == "__main__":
    main()
'''

S_CHANGELOG_GEN = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 更新日志生成器（零依赖 / conventional commits 归类 / last-good 原子写 / JSON IR）
import argparse, json, os, re, subprocess, sys, tempfile
from datetime import date

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

CONV = re.compile(r"^(feat|fix|perf|refactor|docs|test|chore|style|build|ci|revert)(\\(([^)]*)\\))?(!)?:\\s*(.*)$")
MAP = {"feat": "Added", "fix": "Fixed", "perf": "Changed", "refactor": "Changed",
       "docs": "Docs", "test": "Other", "style": "Other", "build": "Other",
       "ci": "Other", "chore": "Other", "revert": "Other"}


def git(repo, args):
    return subprocess.run(["git", "-C", repo] + args, capture_output=True, text=True, encoding="utf-8", errors="replace")


def main():
    ap = argparse.ArgumentParser(prog="changelog_gen", description="从 conventional commits 生成 CHANGELOG 草稿")
    ap.add_argument("--repo", default=".", help="git 仓库路径")
    ap.add_argument("--from", dest="frm", help="起始 ref（默认最近 tag，无 tag 则全量最近 500 条）")
    ap.add_argument("--to", default="HEAD")
    ap.add_argument("--version", help="版本号标签，如 v1.2.0")
    ap.add_argument("--out", help="写入文件（临时文件+原子替换，校验失败不覆盖）")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    if not os.path.isdir(os.path.join(a.repo, ".git")) and "git" not in subprocess.run(
            ["git", "-C", a.repo, "rev-parse", "--git-dir"], capture_output=True, text=True).stdout:
        print(json.dumps({"errors": [{"code": "CHG_E_NO_GIT", "subject": a.repo,
                                      "evidence": "不是 git 仓库", "fixes": ["在仓库根目录运行或用 --repo 指定"]}]},
                         ensure_ascii=False))
        sys.exit(2)
    frm = a.frm
    if not frm:
        t = git(a.repo, ["describe", "--tags", "--abbrev=0"])
        frm = t.stdout.strip() if t.returncode == 0 and t.stdout.strip() else None
    rng_args = ["%s..%s" % (frm, a.to)] if frm else ["-n", "500", a.to]
    p = git(a.repo, ["log", "--pretty=%x1e%H%x1f%s%x1f%b"] + rng_args)
    if p.returncode != 0:
        print(json.dumps({"errors": [{"code": "CHG_E_GIT_FAIL", "subject": " ".join(rng_args),
                                      "evidence": (p.stderr or "").strip()[:200], "fixes": ["确认 git 可用且 ref 存在"]}]},
                         ensure_ascii=False))
        sys.exit(2)
    entries = [e for e in p.stdout.split("\\x1e") if e.strip()]
    sections = {"Breaking": [], "Added": [], "Changed": [], "Fixed": [], "Docs": [], "Other": []}
    for e in entries:
        parts = e.split("\\x1f")
        if len(parts) < 2:
            continue
        h, subj = parts[0].strip()[:7], parts[1].strip()
        body = parts[2] if len(parts) > 2 else ""
        m = CONV.match(subj)
        if m:
            sec = MAP.get(m.group(1), "Other")
            line = "- `%s` %s" % (h, subj)
            if m.group(4) or "BREAKING CHANGE" in body:
                sections["Breaking"].append(line)
            else:
                sections[sec].append(line)
        else:
            sections["Other"].append("- `%s` %s" % (h, subj))
    if not any(sections.values()):
        print(json.dumps({"errors": [{"code": "CHG_E_NO_COMMITS", "subject": " ".join(rng_args),
                                      "evidence": "区间内没有提交", "fixes": ["检查 --from/--to 或先提交"]}]},
                         ensure_ascii=False))
        sys.exit(1)
    ver = a.version or "Unreleased"
    lines = ["## %s - %s" % (ver, date.today().isoformat()), ""]
    zh = {"Breaking": "Breaking / 破坏性变更", "Added": "Added / 新增", "Changed": "Changed / 变更",
          "Fixed": "Fixed / 修复", "Docs": "Docs / 文档", "Other": "Other / 其他"}
    for k in ("Breaking", "Added", "Changed", "Fixed", "Docs", "Other"):
        if sections[k]:
            lines.append("### %s" % zh[k])
            lines.extend(sections[k])
            lines.append("")
    lines.append("<!-- 草稿由 conventional commits 归类生成，发布前请人工润色 -->")
    text = "\\n".join(lines)
    if a.json:
        print(json.dumps({"version": ver, "sections": {k: v for k, v in sections.items() if v}},
                         ensure_ascii=False, indent=2))
    else:
        print(text)
    if a.out:
        d = os.path.dirname(os.path.abspath(a.out))
        fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8", newline="\\n") as fh:
            fh.write(text + "\\n")
        os.replace(tmp, a.out)
    sys.exit(0)


if __name__ == "__main__":
    main()
'''

S_ENV_VAR_AUDIT = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 环境变量审计器（零依赖 / 静态启发式 / JSON IR / 修复回执）
# HIGH：已知密钥前缀或疑似密钥字段被赋长字面量；MEDIUM：代码使用但 example 未声明。
import argparse, json, os, re, sys

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

EXCLUDE_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build", ".idea", ".vscode"}
SRC_EXT = (".py", ".js", ".ts", ".jsx", ".tsx", ".mjs", ".cjs", ".sh")
EXAMPLES = (".env.example", ".env.sample", ".env.template")
PY_RE = re.compile(r"os\\.environ\\.get\\(\\s*[\\'\\"]([A-Za-z_]\\w*)[\\'\\"]|os\\.environ\\[[\\'\\"]([A-Za-z_]\\w*)[\\'\\"]\\s*\\]|os\\.getenv\\(\\s*[\\'\\"]([A-Za-z_]\\w*)[\\'\\"]")
JS_RE = re.compile(r"process\\.env\\.([A-Za-z_]\\w*)|process\\.env\\[[\\'\\"]([A-Za-z_]\\w*)[\\'\\"]\\s*\\]")
SH_RE = re.compile(r"^\\s*(?:export\\s+)?([A-Za-z_][A-Za-z0-9_]*)=", re.M)
SECRET_RE = re.compile(r"(?i)(api[_-]?key|apikey|token|secret|password|passwd|pwd|access[_-]?key|secret[_-]?key)\\b\\s*[:=]\\s*[\\'\\"]([^\\'\\"]+)[\\'\\"]")
KEY_PREFIX = ("ghp_", "gho_", "github_pat_", "sk-", "AKIA", "xoxb-", "xoxp-", "AIza", "-----BEGIN")
PLACEHOLDER = ("your_", "xxx", "placeholder", "example", "changeme", "dummy", "<", "${", "test", "insert_")


def used_keys(text, fname, used):
    for m in PY_RE.finditer(text):
        k = m.group(1) or m.group(2) or m.group(3)
        if k:
            used.setdefault(k, fname)
    for m in JS_RE.finditer(text):
        used.setdefault(m.group(1) or m.group(2), fname)
    if fname.endswith(".sh"):
        for m in SH_RE.finditer(text):
            used.setdefault(m.group(1), fname)


def secret_scan(text, rel, findings):
    for i, line in enumerate(text.splitlines(), 1):
        for m in SECRET_RE.finditer(line):
            name, val = m.group(1), m.group(2)
            low = val.lower()
            is_prefix = any(val.startswith(p) for p in KEY_PREFIX)
            is_long = len(val) >= 12
            is_ph = any(p in low for p in PLACEHOLDER)
            if (is_prefix and not is_ph) or (is_long and not is_ph):
                findings.append({"severity": "HIGH", "code": "EVA_F_HARDCODED_SECRET",
                                 "subject": name, "evidence": "%s:%d 值长度 %d" % (rel, i, len(val)),
                                 "fixes": ["改为 os.environ / process.env 读取，值移入环境或密钥管理",
                                           "轮换该凭据（已入源码即视为泄露）"]})
                break


def main():
    ap = argparse.ArgumentParser(prog="env_var_audit", description="环境变量审计：使用清单 vs .env.example + 硬编码密钥扫描")
    ap.add_argument("root", nargs="?", default=".", help="项目根目录")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    if not os.path.isdir(a.root):
        print(json.dumps({"errors": [{"code": "EVA_E_NO_DIR", "subject": a.root,
                                      "evidence": "目录不存在", "fixes": ["传入正确的项目根目录"]}]},
                         ensure_ascii=False))
        sys.exit(2)
    used, secrets = {}, []
    ex_keys = set()
    n_files = 0
    for dirpath, dirnames, filenames in os.walk(a.root):
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS and not d.startswith(".")]
        for fn in filenames:
            fp = os.path.join(dirpath, fn)
            rel = os.path.relpath(fp, a.root)
            if fn in EXAMPLES:
                try:
                    txt = open(fp, encoding="utf-8", errors="replace").read()
                except Exception:
                    continue
                for line in txt.splitlines():
                    m = re.match(r"^\\s*(?:export\\s+)?([A-Za-z_][A-Za-z0-9_]*)\\s*=", line)
                    if m:
                        ex_keys.add(m.group(1))
                continue
            if fn.endswith(SRC_EXT):
                n_files += 1
                try:
                    txt = open(fp, encoding="utf-8", errors="replace").read()
                except Exception:
                    continue
                used_keys(txt, rel, used)
                secret_scan(txt, rel, secrets)
    if n_files == 0:
        print(json.dumps({"errors": [{"code": "EVA_E_NO_FILES", "subject": a.root,
                                      "evidence": "未发现可扫描的源码文件", "fixes": ["确认目录含 .py/.js/.ts/.sh 文件"]}]},
                         ensure_ascii=False))
        sys.exit(2)
    undocumented = [{"severity": "MEDIUM", "code": "EVA_F_UNDOCUMENTED", "subject": k,
                     "evidence": "使用于 %s，example 未声明" % used[k],
                     "fixes": ["在 .env.example 补充 %s=<占位符> 及说明" % k]} for k in sorted(used) if k not in ex_keys]
    unused = sorted(ex_keys - set(used))
    high = [f for f in secrets if f["severity"] == "HIGH"]
    summary = {"src_files": n_files, "used": len(used), "example_keys": len(ex_keys),
               "high": len(high), "undocumented": len(undocumented), "unused_example": unused}
    if a.json:
        print(json.dumps({"summary": summary, "findings": high + undocumented}, ensure_ascii=False, indent=2))
    else:
        print("源码文件 %d · 代码读取环境变量 %d · .env.example 声明 %d" % (n_files, len(used), len(ex_keys)))
        for f in high:
            print("  硬编码疑密 HIGH：%s = ...（%s）" % (f["subject"], f["evidence"]))
        for u in undocumented:
            print("  未文档化 MEDIUM：%s（%s）" % (u["subject"], u["evidence"]))
        for k in unused:
            print("  example 冗余 LOW：%s（代码未读取）" % k)
        print("%s，rc=%d" % ("发现高危项" if high else "审计完成", 1 if high else 0))
    sys.exit(1 if high else 0)


if __name__ == "__main__":
    main()
'''
