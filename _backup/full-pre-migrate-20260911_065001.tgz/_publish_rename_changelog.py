# -*- coding: utf-8 -*-
"""Batch I 收尾：changelog 标识改名 changelog-gen -> changelog-draft-gen。
GitHub 镜像：新目录 skills/changelog-draft-gen/ 推送 5 文件；旧 skills/changelog-gen/ 删除 5 文件；根 README 更新。
密钥经 vault.py 子进程获取，绝不进对话/打印/URL。
"""
import base64, json, pathlib, subprocess, urllib.request, urllib.error, time

BASE = pathlib.Path("D:/Workbuddy/05-工具/agent-skills")
VAULT_PY = "C:/Users/Administrator/.ucvault_local/vault.py"
PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"

NEW = "changelog-draft-gen"
OLD = "changelog-gen"


def vault_get(label):
    r = subprocess.run([PY, VAULT_PY, "get", label], capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError("vault %s failed: %s" % (label, r.stderr[:160]))
    return r.stdout.strip()


def gh_files(slug):
    files = ["SKILL.md", "README.md", "icon.png", "lgd-powered.png"]
    files += ["scripts/%s" % p.name for p in (BASE / slug / "scripts").glob("*.py")]
    return files


def make_api(base_url, owner, repo, token):
    HEAD = {"Authorization": "Bearer %s" % token, "Accept": "application/vnd.github+json",
            "User-Agent": "moat-push", "X-GitHub-Api-Version": "2022-11-28"}

    def call(method, path, data=None):
        url = "%s/repos/%s/%s/contents/%s" % (base_url, owner, repo, path)
        req = urllib.request.Request(url, data=(json.dumps(data).encode() if data else None),
                                     headers=HEAD, method=method)
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                return resp.status, json.loads(resp.read().decode() or "{}")
        except urllib.error.HTTPError as e:
            return e.code, {"error": e.read().decode(errors="replace")[:240]}
    return call


def push_dir(api, slug):
    cnt = 0
    for f in gh_files(slug):
        local = BASE / slug / f
        gh = "skills/%s/%s" % (slug, f)
        st0, cur = api("GET", gh)
        sha = cur.get("sha") if isinstance(cur, dict) else None
        content = base64.b64encode(local.read_bytes()).decode()
        data = {"message": "add %s: viral utility companion skill (P-061)" % slug, "content": content}
        if sha:
            data["sha"] = sha
        st, resp = api("PUT", gh, data)
        good = st in (200, 201)
        cnt += good
        print("  [%s] %s %s" % ("OK" if good else "FAIL", st, gh))
    return cnt


def delete_dir(api, slug):
    # 先列目录拿 sha
    st0, cur = api("GET", "skills/%s" % slug)
    if st0 != 200 or not isinstance(cur, list):
        print("  [SKIP] 旧目录 skills/%s 不存在或已清 (%s)" % (slug, st0))
        return 0
    cnt = 0
    for it in cur:
        gh = "skills/%s/%s" % (slug, it["name"])
        data = {"message": "remove stale %s after rename to changelog-draft-gen (P-061)" % slug,
                "sha": it["sha"]}
        # scripts 子目录递归
        if it["type"] == "dir":
            st1, sub = api("GET", gh)
            if st1 == 200 and isinstance(sub, list):
                for s in sub:
                    data2 = {"message": "remove stale %s/%s (P-061)" % (slug, s["name"]), "sha": s["sha"]}
                    st, _ = api("DELETE", "%s/%s" % (gh, s["name"]), data2)
                    cnt += (st in (200, 201))
                    print("  [%s] %s %s/%s" % ("OK" if st in (200,201) else "FAIL", st, gh, s["name"]))
            data3 = {"message": "remove stale %s dir (P-061)" % slug, "sha": it["sha"]}
            st, _ = api("DELETE", gh, data3)
            cnt += (st in (200, 201))
            print("  [%s] %s %s" % ("OK" if st in (200,201) else "FAIL", st, gh))
        else:
            st, _ = api("DELETE", gh, data)
            cnt += (st in (200, 201))
            print("  [%s] %s %s" % ("OK" if st in (200,201) else "FAIL", st, gh))
    return cnt


def main():
    tok = vault_get("github_api_key")
    api = make_api("https://api.github.com", "zhaoxinghua09-cell", "agent-skills", tok)
    print("== 推送新目录 skills/%s ==" % NEW)
    n = push_dir(api, NEW)
    print("== 删除旧目录 skills/%s ==" % OLD)
    d = delete_dir(api, OLD)
    # 根 README
    local = BASE / "README.md"
    st0, cur = api("GET", "README.md")
    sha = cur.get("sha") if isinstance(cur, dict) else None
    content = base64.b64encode(local.read_bytes()).decode()
    data = {"message": "update README index: changelog rename to changelog-draft-gen (P-061)", "content": content}
    if sha:
        data["sha"] = sha
    st, _ = api("PUT", "README.md", data)
    print("  [%s] %s README.md" % ("OK" if st in (200,201) else "FAIL", st))
    print("\n结果：推送 %d 文件 | 删除 %d 文件 | README %s" % (n, d, "OK" if st in (200,201) else "FAIL"))


if __name__ == "__main__":
    main()
