import subprocess, json, re, os, urllib.request

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
VAULT = "C:/Users/Administrator/.ucvault_local/vault.py"
TOKEN_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".mp_token")
TARGETS = {
    "klCrLv8uXxvjkv6BOXwSng2M9qOcUEQxTkzGwek4hz7WTkbI_KwAfb2nIRgo1RmW": "4技能推文_预览.html",
    "klCrLv8uXxvjkv6BOXwSnvxSJUiOK7HFxZ-SiSryJIvksQVivYxBv0CX0tpkWsMk": "24技能合集_预览.html",
}

def get_secret(label):
    return subprocess.run([PY, VAULT, "get", label], capture_output=True, text=True).stdout.strip()

def get_token():
    raw = get_secret("wechat_mp")
    appid = re.search(r"wx[0-9a-fA-F]{16}", raw).group(0)
    secret = re.search(r"[0-9a-fA-F]{32}", raw).group(0)
    if os.path.exists(TOKEN_FILE):
        t = open(TOKEN_FILE).read().strip()
        try:
            with urllib.request.urlopen(f"https://api.weixin.qq.com/cgi-bin/getcallbackip?access_token={t}", timeout=15) as x:
                if json.loads(x.read().decode()).get("errcode", 0) == 0:
                    return t
        except Exception:
            pass
    with urllib.request.urlopen(f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={appid}&secret={secret}", timeout=30) as x:
        t = json.loads(x.read().decode())["access_token"]
    open(TOKEN_FILE, "w").write(t)
    return t

TOKEN = get_token()
tmp = "C:/Users/Administrator/AppData/Local/Temp"
# collect all drafts (paginate)
items = []
off = 0
while True:
    url = f"https://api.weixin.qq.com/cgi-bin/draft/batchget?access_token={TOKEN}"
    body = json.dumps({"offset": off, "count": 20, "no_content": 0}).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json; charset=utf-8"})
    with urllib.request.urlopen(req, timeout=60) as x:
        r = json.loads(x.read().decode("utf-8"))
    its = r.get("item", [])
    items.extend(its)
    if not its or len(items) >= r.get("total_count", 0):
        break
    off += len(its)

for mid, fname in TARGETS.items():
    found = None
    for it in items:
        if it.get("media_id") == mid:
            found = it.get("content", {}).get("news_item", [{}])[0]
            break
    if not found:
        print("NOT FOUND", mid)
        continue
    html = found.get("content", "")
    # WeChat wraps with its own; add a light doctype+viewport for preview
    doc = f"<!DOCTYPE html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>{found.get('title','')}</title></head><body style=\"margin:0;background:#f2f2f2;\"><div style=\"max-width:680px;margin:0 auto;background:#fff;padding:12px;\">{html}</div></body></html>"
    out = os.path.join(tmp, fname)
    open(out, "w", encoding="utf-8").write(doc)
    print("exported", fname, "len", len(html))
