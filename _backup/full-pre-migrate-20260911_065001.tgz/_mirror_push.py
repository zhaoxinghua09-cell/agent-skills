import subprocess, json, urllib.request, os

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
VAULT = "C:/Users/Administrator/.ucvault_local/vault.py"
BASE = "D:/Workbuddy/05-工具/agent-skills"
CRED = os.path.join(BASE, "_git_cred.py")

def get_secret(label):
    return subprocess.run([PY, VAULT, "get", label], capture_output=True, text=True).stdout.strip()

def api(method, url, token, bearer=False, body=None):
    headers = {"Authorization": (f"Bearer {token}" if bearer else f"token {token}"),
               "Content-Type": "application/json", "User-Agent": "x", "Accept": "application/json"}
    req = urllib.request.Request(url, data=json.dumps(body).encode() if body else None, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as x:
            return x.status, json.loads(x.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "{}")

gitee = get_secret("gitee_api_key")
atom = get_secret("atomgit_api_key")

# create repos
for name, url, tk, bearer, user in [
    ("Gitee", "https://gitee.com/api/v5/user/repos", gitee, False, "stevenzhao26"),
    ("AtomGit", "https://atomgit.com/api/v5/user/repos", atom, True, "gcw_PcK6ZWCL"),
]:
    st, j = api("POST", url, tk, bearer, {"name": "agent-skills",
        "description": "LGD 治理理论落地的通用 AI 智能体技能集合（上下文工程/AI省钱跑批/提示注入防护/EU AI Act合规导航等）",
        "has_issues": "true", "auto_init": "false"})
    if st in (201, 200):
        print(f"  {name} repo created ->", j.get("html_url") or j.get("full_name") or j.get("name"))
    elif st == 409 or (isinstance(j, dict) and "already" in str(j).lower()):
        print(f"  {name} repo exists (409)")
    else:
        print(f"  {name} create status {st}:", str(j)[:160])

# push via local credential helper (token stays in vault, never in .git/config or URL)
import re
helper_spec = "!" + PY + " " + CRED
for name, url in [
    ("Gitee", "https://gitee.com/stevenzhao26/agent-skills.git"),
    ("AtomGit", "https://atomgit.com/gcw_PcK6ZWCL/agent-skills.git"),
]:
    subprocess.run(["git", "config", "credential.helper", helper_spec], cwd=BASE, check=True)
    r = subprocess.run(["git", "push", "--force", url, "main"], cwd=BASE, capture_output=True, text=True)
    subprocess.run(["git", "config", "--unset", "credential.helper"], cwd=BASE)
    ok = r.returncode == 0
    print(f"  push {name}: {'OK' if ok else 'FAIL'} (rc={r.returncode})")
    if not ok:
        out = re.sub(r"[A-Za-z0-9_]{20,}", "<redacted>", (r.stdout + r.stderr))
        print("    " + out[-400:].replace("\n", "\n    "))
