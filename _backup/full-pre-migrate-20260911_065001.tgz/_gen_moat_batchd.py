# -*- coding: utf-8 -*-
"""Batch D · 闭环配套生成器：徽章签发器 + 徽章验真器。
补齐 LGD 闭环最后一环：护照(有籍)→证据链(有证)→门禁(有门禁)→徽章(签发/验真)。
生成纪律（Batch C 教训固化）：脚本主体为普通三引号原文，哨兵 __X__ 用 .replace 注入，
绝不 .format 生成代码（规避花括号转义坑）。图标用 PIL 生成（LGD 藏青+青绿）。
"""
import json, os, shutil
from PIL import Image, ImageDraw

BASE = "D:/Workbuddy/05-工具/agent-skills"
NAVY = (11, 31, 58)
TEAL = (20, 184, 166)
WHITE = (255, 255, 255)
GREY = (180, 200, 210)
S = 512

SKILLS = [
    {
        "slug": "lgd-badge-issuer",
        "script": "badge_issuer",
        "dn_zh": "LGD 徽章签发器",
        "dn_en": "LGD Badge Issuer",
        "func": "三律全过才签发 lgd-certified 徽章证书（SHA-256 指纹 + 签发台账），未过拒绝并留痕。",
        "func_en": "Issue a lgd-certified badge certificate only when all three laws pass (SHA-256 fingerprint + issuance ledger); refuse and log otherwise.",
        "pain": "闭环最后一环『徽章』缺执行件：三律过了没有权威签发动作，护城河停在三张检查表。",
        "pain_en": "The last loop step 'badge' had no executor: passing the three laws led nowhere without an authoritative issuance act.",
    },
    {
        "slug": "lgd-badge-verify",
        "script": "badge_verify",
        "dn_zh": "LGD 徽章验真器",
        "dn_en": "LGD Badge Verifier",
        "func": "验徽章证书：指纹重算防篡改 + 证据哈希格式校验 + 台账对账（serial 存在且未吊销）。",
        "func_en": "Verify a badge certificate: recompute fingerprint (anti-tamper) + evidence hash format + registry cross-check (serial exists & not revoked).",
        "pain": "有签发无验真，徽章可伪造：闭环缺反向校验，信任链断裂。",
        "pain_en": "Issuance without verification is forgeable: the loop lacked reverse checking and the trust chain broke.",
    },
]

ISSUER_BODY = r'''# -*- coding: utf-8 -*-
"""__DN__：三律全过才签发 lgd-certified 徽章证书。零依赖。

签发铁律（对应三律）：
  有籍   = 每次签发/拒绝都写入签发台账（registry），serial 唯一递增
  有证   = 证据必须覆盖三律各至少 1 条，且立即算 SHA-256 入证
  有门禁 = 任一律证据缺失 → 拒绝签发（rc=1），只留拒发记录

用法：
  python badge_issuer.py --holder "my-agent" \
      --evidence l1-registered=passport.json l2-evidence=chain.jsonl l3-gate=gate_report.json
  python badge_issuer.py --holder x --evidence l1-a=1 --json
"""
import argparse, datetime, hashlib, json, pathlib, sys

LAW_PREFIX = ("l1-", "l2-", "l3-")
ISSUER = "LGD Certification Authority (MedXpert x SynomosAI)"
BADGE = "lgd-certified"


def sha256_of(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def load_evidence_ref(p: str) -> str:
    """证据引用：@文件/纯路径 → 内容哈希；否则按内联值哈希。"""
    q = p[1:] if p.startswith("@") else p
    if pathlib.Path(q).is_file():
        return sha256_of(pathlib.Path(q).read_text(encoding="utf-8"))
    return sha256_of(p)


def main():
    ap = argparse.ArgumentParser(description="__DN__ · 三律门禁签发")
    ap.add_argument("--holder", required=True, help="被签发对象标识")
    ap.add_argument("--evidence", nargs="+", required=True,
                    help="证据键值（键须以 l1-/l2-/l3- 开头），值可为内联或@文件")
    ap.add_argument("--registry", default="lgd_badge_registry.json", help="签发台账")
    ap.add_argument("--out", help="证书输出路径（缺省仅打印）")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    # 三律门禁：每律至少 1 条证据
    ev = {}
    laws_hit = set()
    for item in a.evidence:
        if "=" not in item:
            print(f"证据格式错误（应为 key=value）：{item}", file=sys.stderr)
            sys.exit(2)
        k, v = item.split("=", 1)
        if not k.startswith(LAW_PREFIX):
            print(f"证据键须以 l1-/l2-/l3- 开头：{k}", file=sys.stderr)
            sys.exit(2)
        ev[k] = load_evidence_ref(v)
        laws_hit.add(k[:3])

    missing = [l for l in ("l1-", "l2-", "l3-") if l not in laws_hit]
    reg_path = pathlib.Path(a.registry)
    reg = json.loads(reg_path.read_text(encoding="utf-8")) if reg_path.exists() else {"issued": [], "refused": []}

    def save_reg():
        reg_path.parent.mkdir(parents=True, exist_ok=True)
        reg_path.write_text(json.dumps(reg, ensure_ascii=False, indent=2), encoding="utf-8")

    now = datetime.datetime.now().isoformat(timespec="seconds")
    if missing:
        rec = {"time": now, "holder": a.holder, "reason": "三律证据缺失: " + ",".join(missing)}
        reg["refused"].append(rec)
        save_reg()
        msg = f"⛔ 拒绝签发：三律证据缺失（{'、'.join(missing)}）— 已留痕台账"
        print(json.dumps({"issued": False, "holder": a.holder, "missing": missing,
                          "note": msg}, ensure_ascii=False, indent=2) if a.json else msg)
        sys.exit(1)

    serial = len(reg["issued"]) + 1
    cert = {
        "badge": BADGE,
        "serial": serial,
        "holder": a.holder,
        "issuer": ISSUER,
        "issued_at": now,
        "evidence_sha256": ev,
    }
    canonical = json.dumps(cert, ensure_ascii=False, sort_keys=True)
    cert["fingerprint"] = sha256_of(canonical)
    reg["issued"].append({"serial": serial, "time": now, "holder": a.holder,
                          "fingerprint": cert["fingerprint"]})
    save_reg()

    if a.out:
        outp = pathlib.Path(a.out)
        outp.parent.mkdir(parents=True, exist_ok=True)
        outp.write_text(json.dumps(cert, ensure_ascii=False, indent=2), encoding="utf-8")

    if a.json:
        print(json.dumps({"issued": True, "cert": cert, "out": a.out}, ensure_ascii=False, indent=2))
    else:
        print(f"✅ 已签发 {BADGE} 徽章证书")
        print(f"  持有者：{cert['holder']}   编号：#{serial}")
        print(f"  指纹：{cert['fingerprint'][:16]}…")
        print(f"  证据：{len(ev)} 条（三律齐备）")
        if a.out:
            print(f"  证书：{a.out}")
        print(f"  台账：{a.registry}")
    sys.exit(0)


if __name__ == "__main__":
    main()
'''

VERIFIER_BODY = r'''# -*- coding: utf-8 -*-
"""__DN__：验 lgd-certified 徽章证书真伪。零依赖。

三重校验：
  1. 结构完整：badge/serial/holder/issuer/issued_at/evidence_sha256/fingerprint 齐全
  2. 防篡改：按 canonical JSON 重算 SHA-256 指纹，与证书内指纹一致
  3. 台账对账（--registry 可选）：serial 在签发台账且指纹一致（未吊销/未伪造）

用法：
  python badge_verify.py --cert my_cert.json --registry lgd_badge_registry.json
  python badge_verify.py --cert '{"badge":"lgd-certified",...}' --json
"""
import argparse, hashlib, json, pathlib, sys

REQUIRED = ["badge", "serial", "holder", "issuer", "issued_at", "evidence_sha256", "fingerprint"]
BADGE = "lgd-certified"


def sha256_of(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def load_cert(p: str):
    q = p[1:] if p.startswith("@") else p
    if pathlib.Path(q).is_file():
        raw = pathlib.Path(q).read_text(encoding="utf-8")
    else:
        raw = p
    try:
        return json.loads(raw)
    except json.JSONDecodeError as e:
        print(f"证书不是合法 JSON：{e}", file=sys.stderr)
        sys.exit(2)


def main():
    ap = argparse.ArgumentParser(description="__DN__ · 三重验真")
    ap.add_argument("--cert", required=True, help="证书 JSON（内联 / @文件 / 纯路径）")
    ap.add_argument("--registry", help="签发台账（可选，强烈建议）")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    cert = load_cert(a.cert)
    checks = []

    miss = [k for k in REQUIRED if k not in cert]
    checks.append(("结构完整", not miss, "缺失字段: " + ",".join(miss) if miss else "字段齐全"))

    canon = json.dumps({k: cert[k] for k in REQUIRED[:-1]}, ensure_ascii=False, sort_keys=True)
    recomputed = sha256_of(canon)
    checks.append(("指纹防篡改", recomputed == cert.get("fingerprint"),
                   f"重算={recomputed[:16]}… vs 证书={str(cert.get('fingerprint'))[:16]}…"))

    reg_ok, reg_note = None, "未提供台账，跳过对账"
    if a.registry:
        rp = pathlib.Path(a.registry)
        if rp.exists():
            reg = json.loads(rp.read_text(encoding="utf-8"))
            hit = [x for x in reg.get("issued", []) if x.get("serial") == cert.get("serial")]
            reg_ok = bool(hit) and hit[0].get("fingerprint") == cert.get("fingerprint")
            reg_note = "台账命中且指纹一致" if reg_ok else "台账无此编号或指纹不一致（伪造/已吊销）"
        else:
            reg_ok = False
            reg_note = f"台账不存在: {a.registry}"
    if reg_ok is not None:
        checks.append(("台账对账", reg_ok, reg_note))

    ok = all(c[1] for c in checks)
    if a.json:
        print(json.dumps({"verified": ok, "serial": cert.get("serial"),
                          "holder": cert.get("holder"),
                          "checks": [{"name": n, "pass": p, "note": t} for n, p, t in checks]},
                         ensure_ascii=False, indent=2))
    else:
        print(f"{'✅ 验真通过' if ok else '⛔ 验真失败'}  #{cert.get('serial')} {cert.get('holder', '')}")
        for n, p, t in checks:
            print(f"  {'✅' if p else '⛔'} {n}：{t}")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
'''


def gen_script(d):
    body = ISSUER_BODY if d["slug"] == "lgd-badge-issuer" else VERIFIER_BODY
    return body.replace("__DN__", d["dn_zh"])


SKILLMD_TMPL = '''---
name: {slug}
description: {slug} — {func}
slug: {slug}
version: 1.0.0
display_name: {dn_zh}
display_name_en: {dn_en}
agent_created: true
author: Steven Zhao (MedXpert × SynomosAI)
license: MIT
category: AI 治理
platforms: [claude-code, codebuddy, workbuddy, openai-agents]
---

# {dn_zh}（{dn_en}）

LGD 闭环最后一环：**护照（有籍）→ 证据链（有证）→ 门禁（有门禁）→ 徽章（签发/验真）**。

## 解决什么痛点

{pain}

## 功能

{func}

## 用法

见 `scripts/` 下脚本 `--help`。零依赖（stdlib only），Windows/Linux/macOS 均可运行。

## 对应理论

- LGD-I 有籍 / LGD-II 有证 / LGD-III 有门禁（凡自治之物）
- 域码：TH-LGD-001（闭环执行器·徽章环）

## 免责声明

本工具为治理辅助框架，签发效力以使用方组织制度为准。

---
© MedXpert × SynomosAI · LGD-Powered
'''

README_TMPL = '''# {dn_zh} / {dn_en}

{func_en}

**Pain point**: {pain_en}

Part of the **LGD moat loop**: Passport (registered) → Evidence chain (evidenced) → Gate (gated) → **Badge (issued/verified)**.

Zero-dependency (stdlib only). See `scripts/` for CLI usage (`--help`).

© MedXpert × SynomosAI · LGD-Powered
'''


def icon_issuer():
    img = Image.new("RGB", (S, S), NAVY)
    d = ImageDraw.Draw(img)
    d.ellipse([28, 28, S - 28, S - 28], outline=TEAL, width=10)
    # 奖章：圆 + 双缎带
    d.polygon([(206, 300), (256, 470), (306, 300)], fill=TEAL)
    d.polygon([(176, 300), (216, 460), (256, 300)], fill=WHITE)
    d.ellipse([156, 96, 356, 296], outline=WHITE, width=14)
    d.ellipse([186, 126, 326, 266], outline=TEAL, width=8)
    d.line([(241, 196), (256, 216), (286, 168)], fill=WHITE, width=12)
    return img


def icon_verifier():
    img = Image.new("RGB", (S, S), NAVY)
    d = ImageDraw.Draw(img)
    d.ellipse([28, 28, S - 28, S - 28], outline=TEAL, width=10)
    # 盾 + 对勾
    d.polygon([(256, 90), (390, 140), (390, 270), (256, 430), (122, 270), (122, 140)],
              outline=WHITE, width=12)
    d.line([(190, 260), (240, 310), (330, 200)], fill=TEAL, width=18)
    return img


def main():
    icons = {"lgd-badge-issuer": icon_issuer, "lgd-badge-verify": icon_verifier}
    for d in SKILLS:
        slug = d["slug"]
        root = os.path.join(BASE, slug)
        os.makedirs(os.path.join(root, "scripts"), exist_ok=True)
        (open(os.path.join(root, "scripts", d["script"] + ".py"), "w", encoding="utf-8")
         .write(gen_script(d)))
        (open(os.path.join(root, "SKILL.md"), "w", encoding="utf-8")
         .write(SKILLMD_TMPL.format(**d)))
        (open(os.path.join(root, "README.md"), "w", encoding="utf-8")
         .write(README_TMPL.format(**d)))
        icons[slug]().save(os.path.join(root, "icon.png"))
        shutil.copy(os.path.join(BASE, "lgd-fin-guard", "lgd-powered.png"),
                    os.path.join(root, "lgd-powered.png"))
        print("built", slug)
    print("Batch D done: 2 skills")


if __name__ == "__main__":
    main()
