# -*- coding: utf-8 -*-
"""B3 gate-policy-generator 单技能发布：SkillPie + GitHub（跳 Gitee/AtomGit 防 token 再泄漏）。
密钥经 vault.py 子进程获取，不进对话/URL。
"""
import base64, json, pathlib, subprocess, urllib.request, urllib.error, re, sys, time

BASE = pathlib.Path("D:/Workbuddy/05-工具/agent-skills")
VAULT_PY = "C:/Users/Administrator/.ucvault_local/vault.py"
PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
NODE = "C:/Users/Administrator/.workbuddy/binaries/node/versions/node24/node.exe"
SKILLPIE_CLI = "C:/Users/Administrator/.workbuddy/skills/skillpie/scripts/cli.js"
SLUGS = ["gate-policy-generator"]


def vault_get(label):
    r = subprocess.run([PY, VAULT_PY, "get", label], capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"vault {label} failed: {r.stderr[:160]}")
    return r.stdout.strip()


def gh_files(slug):
    files = ["SKILL.md", "README.md", "icon.png", "lgd-powered.png"]
    files += [f"scripts/{p.name}" for p in (BASE / slug / "scripts").glob("*.py")]
    return files


def publish_skillpie():
    print("\n===== SkillPie =====")
    ok = 0
    for slug in SLUGS:
        sd = BASE / slug
        t = (sd / "SKILL.md").read_text(encoding="utf-8")
        m = re.search(r'display_name:\s*"?([^"\n]+)', t)
        title = (m.group(1).strip() if m else slug)
        try:
            r = subprocess.run([NODE, SKILLPIE_CLI, "submit", str(sd), "--title", title],
                               cwd=str(sd.parent), capture_output=True, text=True,
                               encoding="utf-8", errors="replace", timeout=180)
            out = (r.stdout or "") + (r.stderr or "")
        except subprocess.TimeoutExpired:
            out = "TIMEOUT"
        good = ("发布成功" in out) or ("成功" in out and "skillpie" in out.lower()) or ("submitted" in out.lower())
        print(f"  [{'OK' if good else 'FAIL'}] {slug}  {out[-160:].strip()}")
        ok += good
        time.sleep(2)
    return ok


def make_api(base_url, owner, repo, token, head_factory):
    HEAD = head_factory(token)
    def call(method, path, data=None, branch=None):
        url = f"{base_url}/repos/{owner}/{repo}/contents/{path}"
        if method == "GET" and branch:
            url += f"?ref={branch}"
        req = urllib.request.Request(url, data=(json.dumps(data).encode() if data else None),
                                     headers=HEAD, method=method)
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                return resp.status, json.loads(resp.read().decode() or "{}")
        except urllib.error.HTTPError as e:
            return e.code, {"error": e.read().decode(errors="replace")[:240]}
    return call


def push_repo(name, base_url, owner, repo, token, head_factory, branch=None):
    print(f"\n===== {name} ({owner}/{repo}) =====")
    api = make_api(base_url, owner, repo, token, head_factory)
    cnt = 0
    for slug in SLUGS:
        for f in gh_files(slug):
            local = BASE / slug / f
            gh = f"skills/{slug}/{f}"
            st0, cur = api("GET", gh, branch=branch)
            sha = cur.get("sha") if isinstance(cur, dict) else None
            content = base64.b64encode(local.read_bytes()).decode()
            data = {"message": f"add {slug}/{f} (LGD moat B3)", "content": content}
            if branch:
                data["branch"] = branch
            if sha:
                data["sha"] = sha
            st, _ = api("PUT", gh, data)
            good = st in (200, 201)
            cnt += good
            print(f"  [{'OK' if good else 'FAIL'}] {st} {gh}")
    for f in ["README.md", "lgd-powered.png"]:
        local = BASE / f
        st0, cur = api("GET", f, branch=branch)
        sha = cur.get("sha") if isinstance(cur, dict) else None
        content = base64.b64encode(local.read_bytes()).decode()
        data = {"message": f"update {f} (LGD moat B3 index)", "content": content}
        if branch:
            data["branch"] = branch
        if sha:
            data["sha"] = sha
        st, _ = api("PUT", f, data)
        cnt += (st in (200, 201))
        print(f"  [{'OK' if st in (200,201) else 'FAIL'}] {st} {f}")
    return cnt


def main():
    sp = publish_skillpie()
    try:
        gh_tok = vault_get("github_api_key")
        gh = push_repo("GitHub", "https://api.github.com", "zhaoxinghua09-cell", "agent-skills",
                       gh_tok, lambda tk: {"Authorization": f"Bearer {tk}",
                                           "Accept": "application/vnd.github+json",
                                           "User-Agent": "moat-push", "X-GitHub-Api-Version": "2022-11-28"})
        print(f"\nGitHub 推送文件数：{gh}")
    except Exception as e:
        print("GitHub 发布失败：", e)
    print(f"\nSkillPie 成功 {sp}/{len(SLUGS)}")
    print("Gitee/AtomGit 暂停（Gitee token 待核查 / AtomGit 待轮换）")


if __name__ == "__main__":
    main()
