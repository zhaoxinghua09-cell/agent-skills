# -*- coding: utf-8 -*-
"""核验 Gitee / AtomGit 远端是否含本地最新 commit（token 由 vault 子进程取，输出脱敏）。"""
import subprocess, re

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
VAULT = "C:/Users/Administrator/.ucvault_local/vault.py"

local = subprocess.run(["git", "-C", "D:/Workbuddy/05-工具/agent-skills", "rev-parse", "main"],
                       capture_output=True, text=True).stdout.strip()
print("local main:", local[:12])

def token(label):
    return subprocess.run([PY, VAULT, "get", label], capture_output=True, text=True).stdout.strip()

def lsremote(label, url):
    t = token(label)
    u = url.format(t)
    r = subprocess.run(["git", "ls-remote", u, "main"], capture_output=True, text=True, timeout=60)
    out = re.sub(r"[A-Za-z0-9_]{20,}", "<redacted>", (r.stdout + r.stderr))
    h = r.stdout.strip().split()[0] if r.stdout.strip() else ""
    print(f"  {label}: rc={r.returncode} head={h[:12] if h else '-'}  match={'✅' if h==local else '❌(或超时)'}")
    return h == local

gitee = token("gitee_api_key") and True
lsremote("gitee_api_key", "https://stevenzhao26:{0}@gitee.com/stevenzhao26/agent-skills.git")
lsremote("atomgit_api_key", "https://gcw_PcK6ZWCL:{0}@atomgit.com/gcw_PcK6ZWCL/agent-skills.git")
