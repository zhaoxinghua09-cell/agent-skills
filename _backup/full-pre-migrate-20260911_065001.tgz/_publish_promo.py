# -*- coding: utf-8 -*-
"""P-052 推广物料推送：根 README(九件套) + 39 技能 SKILL.md(安装矩阵) → GitHub skills/<slug>/SKILL.md"""
import base64
import json
import pathlib
import subprocess
import urllib.request
import urllib.error

VAULT = "C:/Users/Administrator/.ucvault_local/vault.py"
PYE = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
BASE = pathlib.Path(__file__).resolve().parent
OWNER, REPO = "zhaoxinghua09-cell", "agent-skills"

r = subprocess.run([PYE, VAULT, "get", "github_api_key"], capture_output=True, text=True)
tok = r.stdout.strip()
H = {"Authorization": "Bearer " + tok, "Accept": "application/vnd.github+json",
     "User-Agent": "moat-promo", "X-GitHub-Api-Version": "2022-11-28"}

SLUGS = [
    "lgd-three-laws-auditor", "agent-output-registry", "evidence-chain-builder",
    "lgd-certify", "gate-policy-generator",
    "lgd-fin-guard", "lgd-law-ethic", "lgd-gov-guard", "lgd-crypto-guard",
    "fin-reg-calc", "aml-sentinel", "evidence-chain-check",
    "gov-disclosure-check", "travel-rule-check",
    "lgd-badge-issuer", "lgd-badge-verify",
    "ai-content-discloser", "agent-boarding-pass", "prompt-leak-scanner",
    "data-minimizer", "model-card-generator", "ai-usage-policy", "ai-incident-log",
    "agent-kill-switch", "ai-reply-heuristics", "citation-coverage-check",
    "ai-vendor-checklist", "prompt-injection-drill", "ai-decision-log",
    "loan-rate-disclosure", "kyc-checklist-gen", "invoice-risk-scan", "fund-fee-calc",
    "wallet-address-check", "token-disclosure-check", "contract-interact-checklist",
    "contract-clause-check", "health-claim-guard", "data-export-check",
]


def call(method, path, data=None):
    req = urllib.request.Request("https://api.github.com/" + path,
                                 data=(json.dumps(data).encode() if data else None),
                                 headers=H, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return resp.status, json.loads(resp.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode(errors="replace")[:200]


def put(local, gh_path, msg):
    if not pathlib.Path(local).is_file():
        print("MISSING LOCAL", local)
        return
    st0, cur = call("GET", "repos/%s/%s/contents/%s" % (OWNER, REPO, gh_path))
    sha = cur.get("sha") if isinstance(cur, dict) else None
    data = {"message": msg, "content": base64.b64encode(open(local, "rb").read()).decode()}
    if sha:
        data["sha"] = sha
    st, resp = call("PUT", "repos/%s/%s/contents/%s" % (OWNER, REPO, gh_path), data)
    print(("[OK] " if st in (200, 201) else "[FAIL] ") + gh_path + " -> " + str(st))
    return st


# 1) 根 README 九件套
put(BASE / "README.md", "README.md", "README head: nine-piece Trendshift formula + install matrix (P-052)")
# 2) 39 技能 SKILL.md 安装矩阵
for slug in SLUGS:
    put(BASE / slug / "SKILL.md", "skills/%s/SKILL.md" % slug,
        "%s: add install/usage matrix section (P-052)" % slug)
print("done")
