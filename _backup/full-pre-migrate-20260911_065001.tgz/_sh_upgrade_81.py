import json, os, re, subprocess, zipfile, time, sys
from pathlib import Path

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
CLI = "C:/Users/Administrator/.skillhub/skills_store_cli.py"
ZIP_DIR = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/SkillHub上架包_81家族_20260908")
STAGE = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/SkillHub_81_upgrade_v2")
STAGE.mkdir(parents=True, exist_ok=True)
LOG = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/_sh_upgrade_81.log")
BADGE = "https://medxpert.cn/badge/powered/svg/lgd-powered-cn.svg"
BAD_EXT = (".png",".jpg",".jpeg",".gif",".ico",".zip",".exe",".mp4",".bin")

CAT_MAP = {
    "AI 治理":"ai-agent","AI工程方法":"ai-agent","AI安全":"it-ops-security","AI合规":"ai-agent",
    "AI学习方法论":"knowledge-management","效率工具":"office-efficiency",
    "开发效率":"dev-programming","办公效率":"office-efficiency",
}
SENS_RE = re.compile(
    r"(赵兴华|C:/Users|/Users/[\w]+|D:/Workbuddy|skh_[A-Za-z0-9]|sk-ent-[A-Za-z0-9]|AKIA[0-9A-Z]{16}"
    r"|[\w.]+@(?!medxpert\.cn)(?!skillhub\.cn)(?!example\.(?:com|org|net|cn))(?!test\.com)(?!localhost)[\w.]+\.(?:com|cn)"
    r"|1[3-9]\d{9})", re.I)
PHONE_RE = re.compile(r"1[3-9]\d{9}")

def _synthetic_phone(s):
    """合成/演示号判定：升序连号、降序连号、重复位 ≥4，或已知测试号 → 不是真实 PII。"""
    asc = sum(1 for a,b in zip(s, s[1:]) if ord(b)-ord(a) == 1)
    desc = sum(1 for a,b in zip(s, s[1:]) if ord(a)-ord(b) == 1)
    rep = cur = 1
    for a,b in zip(s, s[1:]):
        cur = cur+1 if a == b else 1
        rep = max(rep, cur)
    return asc >= 4 or desc >= 4 or rep >= 4 or s == "13800138000"

def log(msg):
    with open(LOG,"a",encoding="utf-8") as f:
        f.write(msg+"\n")
    print(msg)

def extract_clean(z, slug):
    pub = STAGE / slug
    pub.mkdir(parents=True, exist_ok=True)
    # 幂等复用：已抽取过的包直接返回（扫尾重跑零删除、零重复抽取；版本由主循环 normalize 收敛）
    sfs = list(pub.rglob("SKILL.md"))
    if sfs:
        sfs.sort(key=lambda p: len(p.parts))
        return sfs[0].parent
    with zipfile.ZipFile(z) as zf:
        for n in zf.namelist():
            if n.endswith("/"): continue
            low = n.lower()
            if any(low.endswith(e) for e in BAD_EXT): continue
            if "__pycache__" in n or "/_" in n or n.startswith("_"): continue
            parts = [p for p in n.split("/") if p]
            if not parts: continue
            fname = parts[-1]
            if fname == "LICENSE":
                lic_dir = pub / "/".join(parts[:-1])
                if (lic_dir / "LICENSE.md").exists(): continue
                parts[-1] = "LICENSE.md"
            tgt = pub / "/".join(parts)
            tgt.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(n) as src, open(tgt,"wb") as dst:
                dst.write(src.read())
    sfs = list(pub.rglob("SKILL.md"))
    if not sfs: return pub
    sfs.sort(key=lambda p: len(p.parts))
    return sfs[0].parent

def derive_description(txt):
    for line in txt.splitlines():
        s = line.strip()
        if s.startswith("# "):
            return s[2:].strip()
    return None

def parse_frontmatter(sk):
    txt = sk.read_text(encoding="utf-8")
    m = re.match(r"^(---\s*\n)(.*?)(\n---)", txt, re.S)
    if not m: return None, txt, None
    fm = m.group(2); rest = txt[m.end():]
    fields = {}
    for line in fm.splitlines():
        if ":" in line and not line.startswith(" "):
            k,_,v = line.partition(":")
            fields[k.strip()] = v.strip().strip('"').strip("'")
    return fields, rest, txt[:m.start()] + m.group(1) + fm + m.group(3)

def bump_version(v):
    m = re.match(r"(\d+)\.(\d+)\.(\d+)", v or "")
    if not m: return "1.1.0"
    a,b,c = map(int, m.groups())
    return f"{a}.{b+1}.{c}"

def normalize_frontmatter(pub, slug, ver):
    sk = pub/"SKILL.md"
    fields, rest, _ = parse_frontmatter(sk)
    if fields is None: return False
    cat = fields.get("category","")
    if cat in CAT_MAP: fields["category"] = CAT_MAP[cat]
    fields["name"] = fields.get("name", slug)
    fields["slug"] = fields.get("slug", slug)
    fields.setdefault("display_name", fields.get("displayName", fields.get("name", slug)))
    fields.setdefault("displayName", fields.get("display_name", slug))
    fields.setdefault("title", fields.get("displayName", slug))
    fields["version"] = ver
    fields.setdefault("license","MIT")
    fields.setdefault("author","诺声(Logos)@SynomosAI")
    if "platforms" not in fields:
        fields["platforms"] = "[skillhub, clawhub, skillpie]"
    if "tags" not in fields or not fields["tags"]:
        fields["tags"] = "[AI, 治理, 自动化, 合规]"
    _desc = (fields.get("description") or "").strip().strip('"').strip("'")
    _bm = {">-", ">", ">+", "|", "|-", "|+"}
    if (not _desc) or (_desc in _bm) or _desc.startswith(">-") or _desc.startswith(">"):
        fields["description"] = derive_description(rest) or f"{slug} — SynomosAI AI 治理/方法论技能（LGD-Powered）"
    order = ["name","slug","display_name","displayName","title","version","category","platforms","author","license","description","tags"]
    out = [f"{k}: {fields[k]}" for k in order if k in fields]
    for k,v in fields.items():
        if k not in order: out.append(f"{k}: {v}")
    sk.write_text("---\n" + "\n".join(out) + "\n---\n" + rest, encoding="utf-8")
    return True

def ensure_ownership(pub, slug, ver):
    lic = pub/"LICENSE.md"
    if not lic.exists():
        lic.write_text("# MIT License\n\nCopyright (c) 2026 SynomosAI\n\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND.\n", encoding="utf-8")
    man = pub/"manifest.json"
    if not man.exists():
        man.write_text(json.dumps({"name":slug,"version":ver,"author":"诺声(Logos)@SynomosAI","license":"MIT","copyright":"SynomosAI","fingerprint_algorithm":"SHA-256"}, ensure_ascii=False, indent=2), encoding="utf-8")
    att = pub/"ATTESTATION.md"
    if not att.exists():
        att.write_text(f"# 权属与发布证据 · {slug}\n\n- 版本：{ver}\n- 著作权：©2026 SynomosAI（诺声 Logos）\n- 许可：MIT\n- 合成知识/方法论归 SynomosAI 所有，禁复制·转售·用于训练模型。\n- 本作品按「现状」(AS IS) 提供，不作任何明示或暗示担保，使用后果由使用者自负。\n", encoding="utf-8")

def parse_sections(md):
    lines = md.splitlines()
    secs, cur, buf = {}, None, []
    for ln in lines:
        m = re.match(r'^##\s+(.*)$', ln)
        if m:
            if cur is not None: secs[cur] = "\n".join(buf).strip()
            cur = m.group(1).strip(); buf = []
        elif cur is not None:
            buf.append(ln)
    if cur is not None: secs[cur] = "\n".join(buf).strip()
    return secs

def grab(secs, *keys):
    for k in secs:
        if any(kw in k for kw in keys): return secs[k]
    return ""

def clean_section(t):
    """去掉捕获段落里混入的 separators / 署名行 / 徽章行，避免重复署名。"""
    if not t: return ""
    out = []
    for ln in t.splitlines():
        s = ln.strip()
        if s == "---": continue
        if s.startswith("©"): continue
        if s.startswith("![") and "LGD-Powered" in s: continue
        out.append(ln)
    return "\n".join(out).strip()

def detect_code(pub):
    scripts = list(pub.rglob("scripts/*.py")) + list(pub.glob("*.py"))
    return scripts

def extract_code_info(pub, slug):
    """返回 (help_text, err_table_rows, example_text) 或 (None,None,None)"""
    scripts = detect_code(pub)
    if not scripts: return None, None, None
    main = None
    for s in scripts:
        if slug.split("-")[0] in s.stem or s.stem == slug:
            main = s; break
    if main is None: main = scripts[0]
    help_txt = None
    try:
        r = subprocess.run([PY, str(main), "--help"], capture_output=True, text=True, timeout=30)
        if r.returncode in (0,2): help_txt = (r.stdout or r.stderr).strip()[:1500]
    except Exception:
        pass
    # 错误码：仅抓取真实常量（形如 XXX_E_YYY），不把 rc 伪造成错误码
    err_rows = []
    try:
        src = main.read_text(encoding="utf-8", errors="ignore")
        for m in re.finditer(r'([A-Z][A-Z0-9_]{2,}_E_[A-Z0-9_]+)\s*=', src):
            err_rows.append(m.group(1))
    except Exception:
        pass
    err_rows = list(dict.fromkeys(err_rows))[:12]
    # 真机示例：尝试 --demo/--self-test/--example
    example = None
    for flag in ("--demo","--self-test","--example","--sample"):
        try:
            r = subprocess.run([PY, str(main), flag], capture_output=True, text=True, timeout=30)
            if r.returncode == 0 and r.stdout.strip():
                example = r.stdout.strip()[:1200]; break
        except Exception:
            continue
    return help_txt, err_rows, example

def upgrade_body(pub, slug, ver):
    sk = pub/"SKILL.md"
    txt = sk.read_text(encoding="utf-8")
    # 去掉旧 frontmatter
    m = re.match(r"^---\s*\n.*?\n---\s*\n", txt, re.S)
    body = txt[m.end():] if m else txt
    fields, _, _ = parse_frontmatter(sk)
    title_cn = fields.get("display_name", slug)
    title_en = fields.get("displayName", slug)
    desc = fields.get("description","")
    secs = parse_sections(body)
    pain = clean_section(grab(secs, "痛点","解决","定位","为什么","场景")) or desc
    ability = clean_section(grab(secs, "能力边界","能做什么","不能","边界","职责","范围","约束"))
    func = clean_section(grab(secs, "功能","作用","定位"))
    usage = clean_section(grab(secs, "用法","使用","调用","安装","命令","入口"))
    output = clean_section(grab(secs, "示例","输出","真机","demo","样例","实例"))
    err = clean_section(grab(secs, "错误","退出","rc","码","故障","修复"))
    faq = clean_section(grab(secs, "FAQ","反模式","常见","问答","Q&A","误区"))
    disclaimer = clean_section(grab(secs, "免责","disclaimer","声明","AS IS","ASIS"))
    theory = clean_section(grab(secs, "理论","对应","治理","溯源","归属","XCGS","A³","三律"))

    is_code = bool(detect_code(pub))
    help_txt, err_rows, example = (extract_code_info(pub, slug) if is_code else (None,None,None))

    L = []
    L.append(f"# {title_cn} / {title_en}")
    L.append("")
    L.append(f"**{slug}** v{ver} · LGD-Powered 家族 · {'零依赖·确定性输出' if is_code else '方法论·可落地'} · {'退出码 rc=0/1/2' if is_code else 'AI 友好·边界清晰'}")
    L.append("")
    L.append(f"![LGD-Powered]({BADGE})")
    L.append("")
    # 痛点
    L.append("## 痛点")
    L.append(pain.strip() if pain.strip() else "（待补：本技能解决的具体痛点）")
    L.append("")
    # 能力边界
    L.append("## 能力边界")
    if ability.strip():
        L.append(ability.strip())
    else:
        L.append("**能做什么**")
        if func.strip():
            L.append(func.strip())
        else:
            L.append(f"- 按本技能定义的规程落地「{title_cn}」相关能力。")
        L.append("**不能 / 不做什么**")
        L.append("- 不替代专业判断与官方合规口径；关键决策须人工复核。")
        L.append("- 不存储敏感明文、口令、密钥；凭据一律走保险库。")
        L.append("**何时不用（❌）**")
        L.append("- 仅需一次性答案、不需沉淀为可复用资产时，直接询问即可。")
        L.append("- 涉及医疗/临床/疗效声明或受监管专业决策时，须转人工与持证专业意见。")
    L.append("")
    # 用法
    L.append("## 用法")
    if usage.strip():
        L.append(usage.strip())
    elif is_code and help_txt:
        L.append("```bash")
        L.append(f"python scripts/{detect_code(pub)[0].name} --help")
        L.append("```")
        L.append("")
        L.append("<details><summary>--help 输出</summary>")
        L.append("")
        L.append("```")
        L.append(help_txt)
        L.append("```")
        L.append("</details>")
    else:
        L.append("读取本 SKILL.md，按「能力边界 → 用法 → 示例」顺序落地；跨技能协同见对应章节。")
    L.append("")
    # 输出示例
    L.append("## 输出示例（真机）")
    if is_code and example:
        L.append("```")
        L.append(example)
        L.append("```")
    elif output.strip():
        L.append(output.strip())
    elif is_code and help_txt:
        L.append("（运行上方 `--help` 查看完整参数；带参运行即得确定性输出）")
    else:
        L.append("（方法论技能，无机器输出；落地示例见「反模式 FAQ」与正文示意）")
    L.append("")
    # 退出码与错误码
    if is_code:
        L.append("## 退出码与错误码")
        L.append("- `rc=0` 通过 / `rc=1` 发现问题 / `rc=2` 用法或环境错误")
        if err_rows:
            L.append("")
            L.append("| 错误码 | 含义 | 建议修复 |")
            L.append("|---|---|---|")
            for e in err_rows:
                L.append(f"| {e} | （见脚本注释） | 按提示修正输入/环境 |")
        else:
            L.append("")
            L.append("（无预定义错误码常量；失败时以非零 rc + 人类可读错误信息退出，不抛原始栈帧）")
        L.append("")
    elif err.strip():
        L.append("## 错误处理")
        L.append(err.strip())
        L.append("")
    # 反模式 FAQ
    L.append("## 反模式 FAQ")
    if faq.strip():
        L.append(faq.strip())
    else:
        L.append(f"**Q：{title_cn}能完全自动搞定吗？**")
        L.append("A：不能。本技能是方法论/规程，关键判断与跨技能执行需人工或协同技能确认。")
        L.append("")
        L.append(f"**Q：可以直接当法规/专业意见用吗？**")
        L.append("A：不能。仅作辅助框架，最终以官方最新文本与持证专业意见为准。")
    L.append("")
    # 理论/溯源（保留）
    if theory.strip():
        L.append("## 理论依据")
        L.append(theory.strip())
        L.append("")
    # 免责
    L.append("## 免责 / Disclaimer")
    if disclaimer.strip():
        L.append(disclaimer.strip())
    else:
        L.append("本技能按「原样（AS IS）」提供，不作任何明示或暗示担保；非医疗器械/非医疗软件，无疗效或临床声明；关键决策请人工复核并以官方最新要求为准。")
    L.append("")
    L.append("---")
    L.append("")
    L.append(f"© SynomosAI · LGD-Powered · [![LGD-Powered]({BADGE})]({BADGE})")
    L.append("")
    # 安装矩阵
    L.append("## 安装与使用矩阵")
    L.append("```bash")
    L.append(f"# 一键获取（skills CLI）")
    L.append(f"npx skills add zhaoxinghua09-cell/agent-skills -g")
    L.append("")
    L.append(f"# 或手动：克隆后拷贝本技能到你的 Agent 技能目录")
    L.append(f"git clone https://github.com/zhaoxinghua09-cell/agent-skills.git")
    L.append(f"cp -r agent-skills/skills/{slug} ~/.workbuddy/skills/")
    L.append("```")
    L.append("")
    L.append("| Agent | 技能目录 | 运行示例 |")
    L.append("|---|---|---|")
    L.append(f"| Claude Code | `~/.claude/skills/{slug}/` | 让 Claude 按本技能 SKILL.md 工作流调用脚本 |")
    L.append(f"| Codex / Cursor / WorkBuddy | 各自 skills 目录 | 同上，SKILL.md 即操作规程 |")
    L.append(f"| 直接命令行 | 任意位置 | `python scripts/*.py --help`（代码件） |")
    L.append("")
    # 重新写：保留已规范化的 frontmatter + 新 body
    fm_txt = sk.read_text(encoding="utf-8")
    fm_match = re.match(r"^---\s*\n.*?\n---\s*\n", fm_txt, re.S)
    fm_block = fm_match.group(0) if fm_match else "---\n---\n"
    sk.write_text(fm_block + "\n".join(L), encoding="utf-8")

def sensitive_scan(pub):
    for root,_,files in os.walk(pub):
        for f in files:
            if f.lower().endswith((".md",".py",".json",".txt",".yaml",".yml")):
                p = os.path.join(root,f)
                try: c = open(p,encoding="utf-8",errors="ignore").read()
                except Exception: continue
                for m in SENS_RE.finditer(c):
                    tok = m.group(0)
                    if PHONE_RE.fullmatch(tok) and _synthetic_phone(tok):
                        continue  # 合成演示号，非真实 PII
                    return True, f"{f}: matched sensitive pattern"
    return False, ""

PACING = 90  # 全局自适应包间隔（秒）：连续 429 翻倍（上限 1800），成功减半（下限 90）

def publish_retry(pub, slug, ver):
    global PACING
    args = [PY, CLI, "publish", str(pub), "--version", ver,
            "--changelog", "81家族爆款升级·六段式+确定性输出/错误码+反模式FAQ+LGD徽章+安装矩阵"]
    delays = [120, 300, 600, 900, 1200, 1800]
    last = ""
    for i in range(6):
        try:
            r = subprocess.run(args, capture_output=True, text=True, timeout=180)
        except Exception as e:
            return False, f"EXC:{e}"
        out = (r.stdout + r.stderr)
        if "Published" in out or "skillId" in out:
            PACING = max(90, PACING // 2)
            return True, out.strip()[-160:]
        if "already exists" in out or "已存在" in out or "冲突" in out:
            return True, "already_exists"
        if "过于频繁" in out or "429" in out or "频率" in out or "请求过于频繁" in out:
            last = out.strip()[-80:]
            time.sleep(delays[i] if i < len(delays) else 1800)
            PACING = min(PACING * 2, 1800)
            continue
        return False, out.strip()[-300:]
    return False, f"max_retry last={last}"

def publish_once(pub, slug, ver):
    """单次发布尝试：ok / exists / throttled / error 四态。不做包内重试——重试交给轮次扫荡。"""
    args = [PY, CLI, "publish", str(pub), "--version", ver,
            "--changelog", "81家族爆款升级·六段式+确定性输出/错误码+反模式FAQ+LGD徽章+安装矩阵"]
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=180)
    except Exception as e:
        return "error", f"EXC:{e}"
    out = (r.stdout + r.stderr)
    if "Published" in out or "skillId" in out:
        return "ok", out.strip()[-120:]
    if "already exists" in out or "已存在" in out or "冲突" in out:
        return "exists", "already_exists"
    if "过于频繁" in out or "429" in out or "频率" in out or "请求过于频繁" in out:
        return "throttled", out.strip()[-80:]
    return "error", out.strip()[-300:]

# ---- 导入守卫：本脚本被 import 时（如复用 sensitive_scan 做闸门扫描）禁止执行主循环 ----
if __name__ != "__main__":
    log("guard: imported as module -> main pipeline NOT executed")
    import sys as _sys
    _sys.exit(0)

# ---------- 阶段一：全量本地升级暂存（零 API 调用；extract_clean 幂等复用，无删除） ----------
results = []
zips = sorted(ZIP_DIR.glob("*.zip"))
LIMIT = int(os.environ.get("SH_LIMIT","0") or 0)
if LIMIT: zips = zips[:LIMIT]
total = len(zips)
staged = []   # (slug, pub_dir, ver)
for idx, z in enumerate(zips):
    slug = z.stem
    pub = extract_clean(z, slug)
    fields,_,_ = parse_frontmatter(pub/"SKILL.md")
    if fields is None:
        log(f"[stage {idx+1}/{total}] {slug} SKIP frontmatter fail"); results.append({"slug":slug,"status":"err_fm"}); continue
    body_txt = (pub/"SKILL.md").read_text(encoding="utf-8", errors="ignore")
    already = ("反模式 FAQ" in body_txt) or (BADGE in body_txt)   # 已升级标记 → 复用时保持版本不重复 bump
    cur_ver = str(fields.get("version","1.0.0"))
    ver = cur_ver if already else bump_version(cur_ver)
    if not normalize_frontmatter(pub, slug, ver):
        log(f"[stage {idx+1}/{total}] {slug} SKIP normalize fail"); results.append({"slug":slug,"status":"err_fm"}); continue
    ensure_ownership(pub, slug, ver)
    upgrade_body(pub, slug, ver)
    hit, sm = sensitive_scan(pub)
    if hit:
        log(f"[stage {idx+1}/{total}] {slug} SKIP sensitive: {sm}"); results.append({"slug":slug,"status":"err_sensitive","msg":sm}); continue
    staged.append((slug, str(pub), ver))
    log(f"[stage {idx+1}/{total}] {slug} v{ver} ready" + (" (reuse)" if already else ""))

if os.environ.get("SH_DRY"):
    log(f"\nDRY DONE. staged={len(staged)} total={total}")
    Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/_sh_upgrade_81_result.json").write_text(
        json.dumps(results + [{"slug":s,"status":"dry","ver":v} for s,_,v in staged], ensure_ascii=False, indent=1), encoding="utf-8")
    sys.exit(0)

# ---------- 阶段二：轮次扫荡发布（每包每轮一次尝试；429 不包内重试，整轮歇 SH_PASS_GAP 秒） ----------
PENDING = list(staged)
PASS_GAP = int(os.environ.get("SH_PASS_GAP","600") or 600)
MAX_PASSES = int(os.environ.get("SH_MAX_PASSES","20") or 20)
pub_done = 0
nopass_streak = 0
for ps in range(1, MAX_PASSES+1):
    if not PENDING: break
    log(f"--- PASS {ps}/{MAX_PASSES}: pending={len(PENDING)} ---")
    throttled = 0; ok_this = 0
    still = []
    for slug, pubdir, ver in PENDING:
        st, pm = publish_once(Path(pubdir), slug, ver)
        if st in ("ok","exists"):
            log(f"  {slug} v{ver}: {st} {pm}")
            results.append({"slug":slug,"status":"ok","ver":ver,"msg":pm}); pub_done += 1; ok_this += 1
        elif st == "throttled":
            throttled += 1; still.append((slug,pubdir,ver))
        else:
            log(f"  {slug} v{ver}: FAIL {pm}")
            results.append({"slug":slug,"status":"err_pub","ver":ver,"msg":pm})
    PENDING = still
    nopass_streak = nopass_streak + 1 if ok_this == 0 else 0
    log(f"--- pass {ps} done: ok_this_pass={ok_this} throttled={throttled} remain={len(PENDING)} nopass_streak={nopass_streak} ---")
    if PENDING and ok_this == 0 and nopass_streak >= 4:
        log("--- 4 连轮零进展（疑似日配额），提前收工，剩余转 pending ---")
        break
    if PENDING:
        time.sleep(PASS_GAP)

ok_n = sum(1 for r in results if r.get("status")=="ok")
log(f"\nDONE. ok_publish={ok_n} staged={len(staged)} remain_pending={len(PENDING)} total_target={total}")
Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/_sh_upgrade_81_result.json").write_text(
    json.dumps({"results":results,"pending":[{"slug":s,"ver":v,"pub":p} for s,p,v in PENDING]}, ensure_ascii=False, indent=1), encoding="utf-8")
