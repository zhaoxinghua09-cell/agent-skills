---
name: ai-content-discloser
description: ai-content-discloser — 为 AI 参与（全生成/辅助/混合）的内容一键生成合规披露声明：显式声明（中/EN）+ 隐式元数据标注 + 平台贴法，依据中国《人工智能生成合成内容标识办法》与 EU AI Act 第 50 条口径。
slug: ai-content-discloser
version: 1.0.0
display_name: AI 内容披露生成器
display_name_en: AI Content Discloser
agent_created: true
author: 诺声(Logos)@SynomosAI
license: MIT
category: AI 治理
platforms: [claude-code, codebuddy, workbuddy, openai-agents]
copyright: SynomosAI
---
# AI 内容披露生成器（AI Content Discloser）

LGD 广谱爆款配套件：把"有籍·有证·有门禁"做成人人天天用得上的工具。

## 解决什么痛点

发 AI 内容不知道怎么标、标什么：监管已要求显式+隐式标识，漏标有下架/处罚风险，手工写声明费时且口径不统一。

## 功能

为 AI 参与（全生成/辅助/混合）的内容一键生成合规披露声明：显式声明（中/EN）+ 隐式元数据标注 + 平台贴法，依据中国《人工智能生成合成内容标识办法》与 EU AI Act 第 50 条口径。

## 用法

见 `scripts/` 下脚本 `--help`。零依赖（stdlib only），Windows/Linux/macOS 均可运行。

## 对应理论

- LGD-II 有证（披露 = 内容出处有证）· 域码 TH-LGD-002（广谱件·披露环）

## 免责声明

本工具为治理辅助框架，口径以监管官方最新文本为准，不构成法律意见。

---
© MedXpert × SynomosAI · LGD-Powered

## 安装与使用矩阵

```bash
# 一键获取（skills CLI）
npx skills add zhaoxinghua09-cell/agent-skills -g

# 或手动：克隆后拷贝本技能到你的 Agent 技能目录
git clone https://github.com/zhaoxinghua09-cell/agent-skills.git
cp -r agent-skills/skills/ai-content-discloser ~/.claude/skills/
```

| Agent | 技能目录 | 运行示例 |
|---|---|---|
| Claude Code | `~/.claude/skills/ai-content-discloser/` | 让 Claude 按本技能 SKILL.md 工作流调用 `scripts/` |
| Codex CLI / Cursor / WorkBuddy | 各自 skills 目录 | 同上，SKILL.md 即操作规程 |
| 直接命令行 | 任意位置 | `python scripts/ai_content_discloser.py --help` |
