# -*- coding: utf-8 -*-
"""Batch H 冒烟：十款效率工具真实场景用例（临时目录，跑完清理）"""
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile

BASE = pathlib.Path(__file__).resolve().parent
PY = sys.executable
PASS = FAIL = 0


def run(slug, snake, *args, stdin=None):
    r = subprocess.run([PY, str(BASE / slug / "scripts" / (snake + ".py"))] + list(args),
                       capture_output=True, text=True, input=stdin, encoding="utf-8")
    return r.returncode, r.stdout


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("  [PASS] " + name)
    else:
        FAIL += 1
        print("  [FAIL] " + name + (" | " + detail if detail else ""))


def main():
    tmp = tempfile.mkdtemp(prefix="batchh_smoke_")
    try:
        # ---------- batch-renamer ----------
        print("batch-renamer:")
        d = os.path.join(tmp, "rn"); os.makedirs(d)
        for c in "abc":
            open(os.path.join(d, "shot_%s.jpg" % c), "w").write("x")
        rc, out = run("batch-renamer", "batch_renamer", "--dir", d, "--start", "1")
        check("dry-run 预览3个 rc0", rc == 0 and "DRY-RUN" in out, out)
        rc, out = run("batch-renamer", "batch_renamer", "--dir", d, "--start", "1", "--apply")
        check("apply 后 stem+序号改名", rc == 0 and os.path.isfile(os.path.join(d, "shot_a01.jpg")) and not os.path.isfile(os.path.join(d, "shot_a.jpg")), out)
        rc, out = run("batch-renamer", "batch_renamer", "--dir", d, "--prefix", "trip_", "--start", "5", "--apply")
        check("prefix+start 组合", rc == 0 and os.path.isfile(os.path.join(d, "trip_05.jpg")), out)
        rc, out = run("batch-renamer", "batch_renamer", "--dir", os.path.join(tmp, "nope"))
        check("目录不存在 rc2", rc == 2)

        # ---------- dup-finder ----------
        print("dup-finder:")
        d = os.path.join(tmp, "dup"); os.makedirs(d)
        open(os.path.join(d, "a.txt"), "w").write("same-content-here")
        open(os.path.join(d, "b.txt"), "w").write("same-content-here")
        open(os.path.join(d, "c.txt"), "w").write("different!")
        rc, out = run("dup-finder", "dup_finder", "--dir", d)
        check("报告1组重复 rc1", rc == 1 and "重复组: 1" in out, out)
        rc, out = run("dup-finder", "dup_finder", "--dir", d, "--apply", "--json")
        j = json.loads(out)
        check("apply 删1留1", rc == 0 and j["removed"] == 1 and os.path.isfile(os.path.join(d, "a.txt")) and not os.path.isfile(os.path.join(d, "b.txt")), out)

        # ---------- dir-organizer ----------
        print("dir-organizer:")
        d = os.path.join(tmp, "org"); os.makedirs(d)
        open(os.path.join(d, "a.png"), "w").write("x")
        open(os.path.join(d, "b.pdf"), "w").write("x")
        open(os.path.join(d, "c.zip"), "w").write("x")
        rc, out = run("dir-organizer", "dir_organizer", "--dir", d)
        check("dry-run 预览 rc0", rc == 0 and "DRY-RUN" in out, out)
        rc, out = run("dir-organizer", "dir_organizer", "--dir", d, "--apply")
        check("apply 归类3类", rc == 0 and os.path.isfile(os.path.join(d, "图片", "a.png")) and os.path.isfile(os.path.join(d, "文档", "b.pdf")) and os.path.isfile(os.path.join(d, "压缩包", "c.zip")), out)

        # ---------- disk-scan ----------
        print("disk-scan:")
        d = os.path.join(tmp, "disk"); os.makedirs(os.path.join(d, "sub"))
        open(os.path.join(d, "big.bin"), "wb").write(b"\0" * 4096)
        open(os.path.join(d, "sub", "small.txt"), "w").write("hi")
        rc, out = run("disk-scan", "disk_scan", "--dir", d, "--json")
        j = json.loads(out)
        check("Top文件含big.bin", rc == 0 and j["top_files"][0]["path"].endswith("big.bin"), out)

        # ---------- json-tidy ----------
        print("json-tidy:")
        rc, out = run("json-tidy", "json_tidy", "--sort", stdin='{"b":1,"a":[1,2]}')
        check("格式化+排序", rc == 0 and out.find('"a"') < out.find('"b"'), out)
        rc, out = run("json-tidy", "json_tidy", stdin='{"b":1,}')
        check("坏JSON rc1+定位", rc == 1 and "解析失败" in out, out)

        # ---------- csv-slice ----------
        print("csv-slice:")
        f = os.path.join(tmp, "t.csv")
        open(f, "w", encoding="utf-8").write("name,city,age\n张三,北京,30\n李四,上海,25\n王五,北京,40\n")
        rc, out = run("csv-slice", "csv_slice", "--file", f, "--head", "1", "--cols", "1,2", "--where", "2=北京")
        check("筛选+取列", rc == 0 and "张三" in out and "李四" not in out and "age" not in out, out)
        rc, out = run("csv-slice", "csv_slice", "--file", f, "--count")
        check("计数3行", rc == 0 and "3" in out, out)

        # ---------- text-replace ----------
        print("text-replace:")
        d = os.path.join(tmp, "tr"); os.makedirs(d)
        open(os.path.join(d, "x.md"), "w", encoding="utf-8").write("old v1 old v1 keep")
        open(os.path.join(d, "y.md"), "w", encoding="utf-8").write("no match here")
        g = os.path.join(d, "*.md").replace("\\", "/")
        rc, out = run("text-replace", "text_replace", "--glob", g, "--old", "old v1", "--new", "new v2")
        check("dry-run 统计2处", rc == 0 and "2 处" in out and "old v1" in open(os.path.join(d, "x.md"), encoding="utf-8").read(), out)
        rc, out = run("text-replace", "text_replace", "--glob", g, "--old", "old v1", "--new", "new v2", "--apply")
        check("apply 替换+bak", rc == 0 and "new v2" in open(os.path.join(d, "x.md"), encoding="utf-8").read() and os.path.isfile(os.path.join(d, "x.md.bak")), out)

        # ---------- text-stats ----------
        print("text-stats:")
        f = os.path.join(tmp, "s.txt")
        open(f, "w", encoding="utf-8").write("人工智能 AI 很火。\n人工智能改变世界。")
        rc, out = run("text-stats", "text_stats", "--file", f, "--top", "3", "--json")
        j = json.loads(out)
        check("统计+词频", rc == 0 and j["chars"] > 0 and any("人工智能" == t[0] for t in j["top"]), out)

        # ---------- regex-sandbox ----------
        print("regex-sandbox:")
        rc, out = run("regex-sandbox", "regex_sandbox", "--pattern", r"(\d{4})-(\d{2})", "--text", "2026-09-08 and 2025-01-01", "--replace", r"\2/\1尾")
        check("匹配2处+分组", rc == 0 and "匹配 2 处" in out and "'2026', '09'" in out, out)
        rc, out = run("regex-sandbox", "regex_sandbox", "--pattern", "zzz", "--text", "abc")
        check("无匹配 rc1", rc == 1)
        rc, out = run("regex-sandbox", "regex_sandbox", "--pattern", "([", "--text", "x")
        check("坏正则 rc2", rc == 2)

        # ---------- hash-check ----------
        print("hash-check:")
        d = os.path.join(tmp, "hc"); os.makedirs(d)
        open(os.path.join(d, "f1.txt"), "w").write("aaa")
        open(os.path.join(d, "f2.txt"), "w").write("bbb")
        rc, out = run("hash-check", "hash_check", "gen", "--dir", d)
        check("gen 生成清单", rc == 0 and os.path.isfile(os.path.join(d, "manifest.sha256")), out)
        rc, out = run("hash-check", "hash_check", "check", "--dir", d)
        check("check 全过 rc0", rc == 0 and "PASS" in out, out)
        open(os.path.join(d, "f1.txt"), "w").write("TAMPERED")
        rc, out = run("hash-check", "hash_check", "check", "--dir", d)
        check("篡改检出 rc1", rc == 1 and "[改动]" in out, out)

        print("\n==== Batch H 冒烟: PASS=%d FAIL=%d ====" % (PASS, FAIL))
        sys.exit(1 if FAIL else 0)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()
