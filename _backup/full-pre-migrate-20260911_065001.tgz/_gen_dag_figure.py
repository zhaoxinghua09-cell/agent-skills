# -*- coding: utf-8 -*-
"""六层治理谱图配图生成器（知乎文章 A 稿第三节配图）
VI 纪律：藏青 #0B1F3A + 青绿 #14B8A6 + 象牙底；不自创徽章；浅色适配知乎白底。
"""
from PIL import Image, ImageDraw, ImageFont
import os

W, H = 1200, 1210
NAVY = (11, 31, 58)
TEAL = (20, 184, 166)
IVORY = (250, 248, 242)
GREY = (120, 128, 140)
LGREY = (216, 222, 230)
PALEGREEN = (230, 247, 244)
PALEGREY = (240, 237, 230)
DARK = (28, 38, 52)

F = "C:/Windows/Fonts/msyh.ttc"
FS = "C:/Windows/Fonts/seguisym.ttf"  # ★◐○ 真字形：经 fontTools cmap 验证（msyh/simhei 均缺 ◐）
def fnt(sz, bold=False):
    return ImageFont.truetype(F, sz)

def seg_draw(dr, xy, text, size, color, bold=False):
    """分段混排：★◐○ 符号 run 用 simhei，其余用 msyh。"""
    x, y = xy
    SYM = set("★◐○●▲◇")
    runs, cur, cur_sym = [], "", None
    for ch in text:
        s = ch in SYM
        if cur_sym is None or s == cur_sym:
            cur += ch
            cur_sym = s
        else:
            runs.append((cur, cur_sym)); cur, cur_sym = ch, s
    if cur:
        runs.append((cur, cur_sym))
    for t, is_sym in runs:
        f = ImageFont.truetype(FS if is_sym else F, size)
        dr.text((x, y), t, font=f, fill=color)
        x += dr.textlength(t, font=f)

OUT = r"D:/Workbuddy/05-工具/宣传资产/谱图_治理六层DAG_1200x1500.png"
os.makedirs(os.path.dirname(OUT), exist_ok=True)

img = Image.new("RGB", (W, H), IVORY)
d = ImageDraw.Draw(img)

# ===== 标题条 =====
d.rounded_rectangle([0, 0, W, 96], radius=0, fill=NAVY)
d.text((48, 26), "治理谱图 · 六层结构与两翼", font=fnt(40, True), fill=IVORY)
d.text((640, 42), "Governance Determinability", font=fnt(20), fill=(168, 190, 210))

# ===== 外部地基（引用层，虚线支撑语义用浅灰）=====
d.rounded_rectangle([200, 124, 1000, 214], radius=14, outline=GREY, width=2, fill=PALEGREY)
d.text((238, 138), "外部地基 · 支撑引用（非推出关系）", font=fnt(21, True), fill=GREY)
seg_draw(d, (238, 172), "determinability 法学谱系 · McCann 454 定理 · Tibebu 问责不完整性 · FERZ 授权纪律", 19, (100, 108, 120))
# 地基 -> 主链 虚线感（短竖线）
for y in range(222, 254, 8):
    d.line([600, y, 600, y + 4], fill=GREY, width=2)

# ===== 六层主链 =====
LX0, LX1 = 200, 1000
layers = [
    ("第 1 层 · 价值公理", "◐ 共存论 —— 人机共存为目标态", PALEGREEN, NAVY, 262, 88, False),
    ("第 2 层 · 制度", "★ AI Passport    ◐ LGD-I 有籍", None, None, 382, 88, False),
    ("第 3 层 · 证据", "◐ LGD-II 有证    ◐ XCGS 证据链底座    ★ BTSK", None, None, 502, 88, False),
    ("第 4 层 · 判定", "◐ LGD-III 有门禁  →  ★ 治理判定论（L0–L4 · 四态输出 · 判定债务）", None, None, 622, 108, True),
    ("第 5 层 · 实例", "★ ACD-MD（医械先行）· ★ ACD 家族 · ★ 81 个治理技能", None, None, 762, 88, False),
    ("第 6 层 · 约束回灌", "★ A³ / PCC —— 约束 AI 造 AI 全链路（含判定器自身）", None, None, 882, 88, False),
]
edges = [
    "共存要求个体可识别 · 责任可分",
    "证据必须挂在对象上",
    "复放 = 用证据重走判定",
    "判定论落地为工具与领域包",
    "工具受自身理论约束",
]
for i, (name, body, fill, _fc, y, hh, core) in enumerate(layers):
    if fill is None:
        fill = (255, 255, 255)
    ow = 4 if core else 2
    oc = TEAL if core else NAVY
    d.rounded_rectangle([LX0, y, LX1, y + hh], radius=16, outline=oc, width=ow, fill=fill)
    d.text((LX0 + 26, y + 10), name, font=fnt(19, True), fill=TEAL if core else GREY)
    seg_draw(d, (LX0 + 26, y + 40), body, 23 if not core else 22, NAVY)
    if core:
        d.text((LX0 + 26, y + 74), "不可判定，则不可治理", font=fnt(20, True), fill=TEAL)
    if i < 5:
        ay = y + hh
        ey = layers[i + 1][4]
        mid = (ay + ey) // 2
        d.line([600, ay + 4, 600, ey - 10], fill=NAVY, width=3)
        d.polygon([(592, ey - 14), (608, ey - 14), (600, ey - 4)], fill=NAVY)
        d.text((618, mid - 12), edges[i], font=fnt(17), fill=(90, 100, 115))

# ===== 左翼 RRM =====
d.rounded_rectangle([28, 262, 128, 970], radius=24, fill=NAVY)
for j, ch in enumerate("RRM 现实参照法 · 方法驱动"):
    d.text((78 - 10, 300 + j * 0), "", font=fnt(1))
# 竖排文字
def vtext(x, y, text, size, color, bold=False):
    yy = y
    for ch in text:
        if ch == " ":
            yy += size * 0.5
            continue
        d.text((x, yy), ch, font=fnt(size, bold), fill=color)
        yy += size + 6
vtext(58, 320, "RRM 现实参照法", 24, IVORY, True)
vtext(58, 620, "方法 · 驱动实例层", 20, (168, 190, 210))
# 右翼
d.rounded_rectangle([1072, 262, 1172, 970], radius=24, fill=NAVY)
vtext(1102, 320, "不可能域地图", 24, IVORY, True)
vtext(1102, 620, "边界 · 约束全链", 20, (168, 190, 210))
# 翼->主链 短横线
for y in (430, 660, 880):
    d.line([128, y, 196, y], fill=NAVY, width=3)
    d.polygon([(190, y - 7), (190, y + 7), (198, y)], fill=NAVY)
    d.line([1004, y, 1068, y], fill=NAVY, width=3)
    d.polygon([(1074, y - 7), (1074, y + 7), (1066, y)], fill=NAVY)

# ===== 图例 =====
d.rounded_rectangle([200, 1010, 1000, 1086], radius=14, outline=LGREY, width=2, fill=(255, 255, 255))
seg_draw(d, (238, 1026), "★ 我方构建      ◐ 发扬光大（本体非首创，扩展与诠释为我方）      ○ 外部地基（引用）", 20, DARK)
d.text((238, 1056), "首创性三档如实标注 · 外部地基为支撑引用边，不得表述为推出关系 · 全部主张附可证伪条件", font=fnt(17), fill=GREY)

# ===== 底部 =====
d.text((200, 1120), "逐边推出关系与证伪传播表见理论仓：github.com/zhaoxinghua09-cell/lgd-theory", font=fnt(18), fill=(90, 100, 115))
d.text((200, 1152), "© SynomosAI · 谱图结构 v1.1 · 2026-09", font=fnt(16), fill=GREY)

img.save(OUT)
print("saved:", OUT, img.size)
