# -*- coding: utf-8 -*-
"""LGD 护城河技能图标生成器（藏青 #0B1F3A + 青绿 #14B8A6）。"""
from PIL import Image, ImageDraw
import os

NAVY = (11, 31, 58)
TEAL = (20, 184, 166)
WHITE = (255, 255, 255)
GREY = (180, 200, 210)
S = 512

def new():
    img = Image.new("RGB", (S, S), NAVY)
    d = ImageDraw.Draw(img)
    # 青绿外环
    d.ellipse([28, 28, S-28, S-28], outline=TEAL, width=10)
    return img, d

def save(img, name):
    p = os.path.join("D:/Workbuddy/05-工具/agent-skills", name, "icon.png")
    img.save(p)
    print("saved", p)

# A1 三律自检器：三条竖条（有籍/有证/有门禁）
img, d = new()
for i, x in enumerate([150, 236, 322]):
    h = 150 + i*40
    d.rounded_rectangle([x, 250-h//2+30, x+46, 250+h//2+30], radius=10, fill=TEAL if i==1 else WHITE)
save(img, "lgd-three-laws-auditor")

# B1 有籍登记器：一本书/户口标签
img, d = new()
d.rounded_rectangle([150, 150, 362, 360], radius=18, outline=WHITE, width=10)
d.line([256, 150, 256, 360], fill=TEAL, width=8)
d.ellipse([225, 235, 287, 297], outline=TEAL, width=10)
save(img, "agent-output-registry")

# B2 有证证据链：三个链环
img, d = new()
for cx in [180, 256, 332]:
    d.ellipse([cx-46, 210, cx+46, 302], outline=TEAL if cx==256 else WHITE, width=12)
save(img, "evidence-chain-builder")

# A2 certify：印章/对勾盾
img, d = new()
d.rounded_rectangle([160, 150, 352, 362], radius=40, outline=WHITE, width=10)
d.line([210, 262, 245, 300], fill=TEAL, width=16)
d.line([245, 300, 305, 215], fill=TEAL, width=16)
save(img, "lgd-certify")

print("ALL ICONS DONE")
