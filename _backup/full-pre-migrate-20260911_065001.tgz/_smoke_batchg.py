# -*- coding: utf-8 -*-
"""Batch G 冒烟驱动：10 技能正反用例 + rc=2，全 PASS 才算过。"""
import json
import pathlib
import subprocess
import sys

PY = sys.executable
BASE = pathlib.Path(__file__).resolve().parent
FAILS = []


def run(script, args, label, expect_rc):
    p = subprocess.run([PY, script] + args, capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=60)
    ok = p.returncode == expect_rc
    if not ok:
        FAILS.append(label)
    print(("PASS " if ok else "FAIL ") + label + "  (rc=%s expect %s)" % (p.returncode, expect_rc))
    if not ok:
        print("  stdout:", (p.stdout or "")[:200])
        print("  stderr:", (p.stderr or "")[:200])
    return p


R = "loan-rate-disclosure/scripts/loan_rate_disclosure.py"
run(R, ["--rate", "10", "--base", "3.85"], "G1-1 利率合规 PASS", 0)
run(R, ["--rate", "20", "--base", "3.85"], "G1-2 超4倍LPR FAIL", 1)
run(R, [], "G1-3 缺输入 rc=2", 2)

K = "kyc-checklist-gen/scripts/kyc_checklist_gen.py"
run(K, ["--type", "personal", "--have", "1,2,3,4,5"], "G2-1 材料齐备 PASS", 0)
run(K, ["--type", "corporate", "--have", "1"], "G2-2 企业缺项 FAIL", 1)

I = "invoice-risk-scan/scripts/invoice_risk_scan.py"
run(I, ["--taxid", "91350100M000100Y43", "--amount", "1000", "--date", "2026-01-01"], "G3-1 发票要素 PASS", 0)
run(I, ["--taxid", "abc", "--amount", "-5"], "G3-2 税号/金额违规 FAIL", 1)

F = "fund-fee-calc/scripts/fund_fee_calc.py"
run(F, ["--amount", "100000", "--mgmt", "0.015", "--years", "2"], "G4-1 费率试算 PASS", 0)
run(F, ["--amount", "100000", "--claim", "保本保收益"], "G4-2 保本承诺 FAIL", 1)
run(F, ["--amount", "-1"], "G4-3 负本金 rc=2", 2)

W = "wallet-address-check/scripts/wallet_address_check.py"
run(W, ["--address", "0x1234567890abcdef1234567890abcdef12345678"], "G5-1 EVM地址 PASS", 0)
run(W, ["--address", "hello-world-not-an-address"], "G5-2 乱串地址 FAIL", 1)

T = "token-disclosure-check/scripts/token_disclosure_check.py"
run(T, ["--text", "代币总量10亿，分配方案60%社区，锁仓3年，团队20%，风险提示：投资有风险"], "G6-1 披露完备 PASS", 0)
run(T, ["--text", "保证收益稳赚翻倍"], "G6-2 收益承诺+缺要素 FAIL", 1)

C = "contract-interact-checklist/scripts/contract_interact_checklist.py"
run(C, ["--have", "1,2,3,4,5,6", "--approve", "limited"], "G7-1 六项齐 PASS", 0)
run(C, ["--have", "1", "--approve", "unlimited"], "G7-2 无限授权 FAIL", 1)

L = "contract-clause-check/scripts/contract_clause_check.py"
run(L, ["--text", "任何一方违约应承担责任；争议提交仲裁；管辖法院为原告所在地。"], "G8-1 必备条款 PASS", 0)
run(L, ["--text", "双方友好合作。违约金为40%。"], "G8-2 缺管辖+高违约金 FAIL", 1)

H = "health-claim-guard/scripts/health_claim_guard.py"
run(H, ["--kind", "保健食品", "--text", "有助于补充营养，本品不能代替药物。"], "G9-1 合规宣传 PASS", 0)
run(H, ["--text", "三天根治糖尿病，无副作用"], "G9-2 疗效宣称 FAIL", 1)

D = "data-export-check/scripts/data_export_check.py"
run(D, ["--have", "1,2,3,4,5"], "G10-1 五项齐 PASS", 0)
run(D, ["--have", "1"], "G10-2 义务缺项 FAIL", 1)

print("=" * 50)
print("TOTAL FAILS:", len(FAILS))
sys.exit(1 if FAILS else 0)
