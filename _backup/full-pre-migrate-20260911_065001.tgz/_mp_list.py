import subprocess, json, re, os, urllib.request

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
VAULT = "C:/Users/Administrator/.ucvault_local/vault.py"
TOKEN_FILE = os.path.join(os.path.dirname(__file__), ".mp_token")

def get_secret(label):
    return subprocess.run([PY, VAULT, "get", label], capture_output=True, text=True).stdout.strip()

def get_token():
    raw = get_secret("wechat_mp")
    appid = re.search(r"wx[0-9a-fA-F]{16}", raw).group(0)
    secret = re.search(r"[0-9a-fA-F]{32}", raw).group(0)
    if os.path.exists(TOKEN_FILE):
        t = open(TOKEN_FILE).read().strip()
        try:
            with urllib.request.urlopen(f"https://api.weixin.qq.com/cgi-bin/getcallbackip?access_token={t}", timeout=15) as x:
                if json.loads(x.read().decode()).get("errcode", 0) == 0:
                    return t
        except Exception:
            pass
    with urllib.request.urlopen(f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={appid}&secret={secret}", timeout=30) as x:
        t = json.loads(x.read().decode())["access_token"]
    open(TOKEN_FILE, "w").write(t)
    return t

TOKEN = get_token()
print("token len", len(TOKEN))

url = f"https://api.weixin.qq.com/cgi-bin/draft/batchget?access_token={TOKEN}"
body = json.dumps({"offset": 0, "count": 20, "no_content": 0}).encode("utf-8")
req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json; charset=utf-8"})
with urllib.request.urlopen(req, timeout=60) as x:
    r = json.loads(x.read().decode("utf-8"))

print("total_count", r.get("total_count"), "item_count", r.get("item_count"))
dump = []
for it in r.get("item", []):
    c = it.get("content", {})
    title = c.get("title", "")
    content = c.get("content", "")
    dump.append({"media_id": it.get("media_id"), "title": title, "content_head": content[:400]})
    # print to stdout for visual garble check
    print("\n==== media_id:", it.get("media_id"))
    print("TITLE:", title)
    print("HEAD:", content[:300])
# save full dump (local only, not in repo)
out = "C:/Users/Administrator/AppData/Local/Temp/mp_draft_dump.json"
open(out, "w", encoding="utf-8").write(json.dumps(r, ensure_ascii=False, indent=2))
print("\nsaved full dump ->", out)
