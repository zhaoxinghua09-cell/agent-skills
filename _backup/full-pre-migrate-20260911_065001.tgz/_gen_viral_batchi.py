# -*- coding: utf-8 -*-
"""Batch I 爆款精品批（P-061）：3 医疗器械 + 3 通用，质量优先。
哨兵 replace 注入纪律（禁 format/f-string 注入）。零依赖 + JSON IR + 修复回执错误码。
"""
import os, sys, pathlib, shutil

BASE = pathlib.Path(r"D:/Workbuddy/05-工具/agent-skills")
VERSION = "1.0.0"
REPO = "zhaoxinghua09-cell/agent-skills"
BADGE_URL = "https://medxpert.cn/badge/powered/svg/lgd-powered-en.svg?v=84"

# ---------------- 技能定义 ----------------
SKILLS = [
    {
        "slug": "udi-format-validator",
        "snake": "udi_format_validator",
        "dn": "UDI 格式校验器",
        "dnen": "UDI Format Validator",
        "cat": "医疗器械合规",
        "glyph": "U",
        "pain": "拿到一串 UDI 不知道 DI 有没有错、生产标识全不全、 Basic UDI-DI 怎么区分，注册资料被打回才知道格式错了",
        "usage": """```bash
# 带包装标识（推荐，GS1 扫码输出常见形态）
python scripts/udi_format_validator.py "(01)06901234567892(17)260930(10)LOT2026A(21)SN0001"

# 仅校验 UDI-DI
python scripts/udi_format_validator.py --di 06901234567892

# JSON 中间表示（机器可读）
python scripts/udi_format_validator.py "(01)06901234567892" --json
```""",
        "sample": """$ udi_format_validator.py "(01)06901234567892(17)260930(10)LOT2026A"
UDI 校验：通过
  DI        06901234567892   校验位 ✓（GS1 Mod10）
  失效日期  2026-09-30       格式 ✓
  批号      LOT2026A         生产标识 ✓
提示：三类械 UDI 已全面实施（2022-06），二类自 2024-06-01 起；EU 需另配 Basic UDI-DI，以官方最新要求为准。""",
        "errs": [
            ("UDI_E_LEN", "DI 长度不等于 14 位", "核对 GS1 编码结构，DI 固定 14 位"),
            ("UDI_E_CHECKDIGIT", "GS1 Mod10 校验位不符", "按 13 位数据位重算校验位，或核对录入笔误"),
            ("UDI_E_DATE", "日期段非法（月/日越界）", "AI(11)/(17) 为 YYMMDD，日位 00 表示月末需注明"),
            ("UDI_E_UNKNOWN_AI", "出现不受支持的应用标识符", "仅支持 01/10/11/17/21/240/30，其余请人工核对"),
            ("UDI_E_AMBIGUOUS", "无括号串中变长段无法定界", "请使用带括号形态或含 FNC1 的扫码输出"),
        ],
        "faq": [
            ("UDI-DI 和 Basic UDI-DI 有什么区别？", "UDI-DI 标识具体型号包装，Basic UDI-DI 是同族产品的注册单元级标识（EU MDR 要求，NMPA 亦有对应口径），本工具按 --type 分开校验结构。"),
            ("校验位通过了就等于编码合规吗？", "不等于。本工具做格式与结构判定；编码归属、企业前缀、发码机构资质仍需向发码机构与官方数据库核验。"),
        ],
        "claim_zh": "给 UDI 串做一次确定的、可复现的体检，别等打回才知道格式错。",
        "claim_en": "A deterministic health check for UDI strings - catch format errors before regulators do.",
        "keywords": "UDI校验 UDI-DI Basic-UDI-DI GS1检查位 NMPA UDI MDR 医疗器械唯一标识 注册资料",
    },
    {
        "slug": "clin-eval-route-picker",
        "snake": "clin_eval_route_picker",
        "dn": "临床评价路径选择器",
        "dnen": "Clinical Evaluation Route Picker",
        "cat": "医疗器械合规",
        "glyph": "R",
        "pain": "免临床目录、同品种路径、临床试验三条路怎么选说不清，资料写到一半才发现路走错了",
        "usage": """```bash
# NMPA：III 类、不在免临床目录、无同品种数据
python scripts/clin_eval_route_picker.py --market nmpa --nmpa-class III --in-catalog no --eq-data no

# NMPA：列入免临床目录
python scripts/clin_eval_route_picker.py --market nmpa --nmpa-class II --in-catalog yes

# EU：IIa 类、属成熟技术（WET）
python scripts/clin_eval_route_picker.py --market eu --eu-class IIa --wet yes

# JSON 中间表示
python scripts/clin_eval_route_picker.py --market nmpa --nmpa-class II --in-catalog yes --json
```""",
        "sample": """$ clin_eval_route_picker.py --market nmpa --nmpa-class II --in-catalog yes
推荐路径：免临床评价路径（列入《免于临床评价医疗器械目录》）
  依据：国家药监局 2021 年第 73 号通告
  需提交：与目录条目的对比说明、与同品种器械的对比资料
  提示：对比不符项需另行评价；以官方最新版目录为准""",
        "errs": [
            ("CE_E_MISSING", "缺少必需输入（如 market=nmpa 但未给 --nmpa-class）", "按提示补齐对应市场的分类与条件输入"),
            ("CE_E_CONFLICT", "输入组合自相矛盾（如 I 类+植入+临床数据）", "核对产品实际分类与证据现状后重新输入"),
            ("CE_E_VALUE", "布尔类参数取值非法", "布尔参数仅接受 yes/no"),
        ],
        "faq": [
            ("工具给的路径能直接当注册策略吗？", "不能。输出是基于现行规则文本的确定性推荐，供立项讨论与资料准备导航；注册策略需结合产品具体属性并由注册人员/法规顾问确认。"),
            ("为什么答案总带'以官方最新为准'？", "目录、通告与指南会更新，工具按发布时规则编写；本措辞是 YMYL 内容纪律，不是免责套话。"),
        ],
        "claim_zh": "三条临床评价路径，用确定的判定树选，不用凭感觉赌。",
        "claim_en": "A deterministic decision tree for NMPA/EU clinical evaluation routes.",
        "keywords": "临床评价 免临床目录 同品种 临床试验 NMPA 73号通告 MDCG 2020-6 WET 医疗器械注册",
    },
    {
        "slug": "pmcf-plan-check",
        "snake": "pmcf_plan_check",
        "dn": "PMCF 计划完整性检查器",
        "dnen": "PMCF Plan Completeness Checker",
        "cat": "医疗器械合规",
        "glyph": "P",
        "pain": "PMCF 计划写了一半交上去，公告机构说缺方法缺终点缺统计考量，来回补件三个月",
        "usage": """```bash
# 按字段逐项检查
python scripts/pmcf_plan_check.py --fields objectives=随访生存率变化 methods=文献+登记库 endpoints=并发症发生率 follow_up_period=24个月 statistical_plan=单臂目标值法 benefit_risk_linkage=是 pms_linkage=是 cer_update_trigger=年度 responsible_person=RA经理 timeline=2026Q4启动

# 或用 JSON 计划文件
python scripts/pmcf_plan_check.py --plan pmcf.json --json
```""",
        "sample": """$ pmcf_plan_check.py --plan pmcf.json
完整性 8/10（80%）
  缺失：statistical_plan（统计考量）
  存疑：follow_up_period 未含具体时长
建议补齐后重跑至 10/10 再提交公告机构。""",
        "errs": [
            ("PMCF_E_MISSING_FIELD", "核心要素缺失", "按 README 要素表补齐对应字段"),
            ("PMCF_E_WEAK_FIELD", "字段有值但内容存疑（如随访期无数值）", "补充可核验的量化内容"),
            ("PMCF_E_NO_INPUT", "未提供 --plan 或 --fields", "任选其一提供计划内容"),
        ],
        "faq": [
            ("检查通过等于公告机构认可吗？", "不等于。本工具核对的是 MDCG 2020-7/2019-8 提炼的核心要素完整性，公告机构还会审查方法学合理性。"),
            ("NMPA 侧能用吗？", "PMCF 概念源自 EU MDR；NMPA 上市后临床随访要求参照国内指导原则执行，本工具输出对两侧均为要素清单参考。"),
        ],
        "claim_zh": "交公告机构之前，先用十条核心要素把 PMCF 计划过一遍秤。",
        "claim_en": "Weigh your PMCF plan against ten core elements before the notified body does.",
        "keywords": "PMCF计划 MDCG 2020-7 MDCG 2019-8 上市后临床随访 CER 公告机构 补件",
    },
    {
        "slug": "md-link-audit",
        "snake": "md_link_audit",
        "dn": "Markdown 链接体检器",
        "dnen": "Markdown Link Auditor",
        "cat": "效率工具",
        "glyph": "L",
        "pain": "README 里链接一堆 404、改了路径没人发现，CI 上还老因为外网检查超时误报",
        "usage": """```bash
# 默认离线：只查内部相对链接与本地锚点（CI 友好，零外呼）
python scripts/md_link_audit.py docs/

# 联网校验外部链接（8s 超时 + 一次重试）
python scripts/md_link_audit.py . --net

# JSON 输出
python scripts/md_link_audit.py . --json
```""",
        "sample": """$ md_link_audit.py docs/
扫描 12 个 Markdown 文件 · 链接 47 条
  内部断链 2：
    getting-started.md -> ../imgs/arch.png   （文件不存在）
    README.md -> #install                    （无对应标题）
  外部链接 31 条（--net 未开启，未校验）
发现断链，rc=1""",
        "errs": [
            ("MLK_E_NO_DIR", "目录不存在", "传入正确的文档目录"),
            ("MLK_E_NO_MD", "目录内没有 Markdown 文件", "确认目录或改用 --ext 扩展名"),
        ],
        "faq": [
            ("为什么不默认联网？", "外呼会拖慢 CI 且被限流误伤；默认只做确定性的本地判定，外链校验交给 --net 显式开启。"),
            ("锚点判定规则是什么？", "按 GitHub 口径：转小写、去标点、空格转连字符；中文标题同样适用。"),
        ],
        "claim_zh": "README 断链在 CI 里就地现形——默认离线、快而确定。",
        "claim_en": "Find broken links in your Markdown before your readers do. Offline-first.",
        "keywords": "markdown链接检查 断链 404 README CI docs 锚点 链接审计",
    },
    {
        "slug": "changelog-gen",
        "snake": "changelog_gen",
        "dn": "更新日志草稿生成器",
        "dnen": "Changelog Generator",
        "cat": "工程方法",
        "glyph": "G",
        "pain": "发版手写 CHANGELOG 漏三漏四，conventional-changelog 全家桶又太重，只想按规范出个草稿",
        "usage": """```bash
# 默认：自最近一个 tag 到 HEAD
python scripts/changelog_gen.py --version v1.2.0

# 指定区间与输出文件（last-good 原子替换）
python scripts/changelog_gen.py --from v1.1.0 --to HEAD --version v1.2.0 --out CHANGELOG.md

# JSON 输出
python scripts/changelog_gen.py --version v1.2.0 --json
```""",
        "sample": """$ changelog_gen.py --version v1.2.0
## v1.2.0 - 2026-09-08

### ⚠ Breaking / 破坏性变更
- `a1b2c3d` refactor(cli)!: rename --dry-run to --preview

### Added / 新增
- `e4f5a6b` feat: add --json output for machine readers

### Fixed / 修复
- `b7c8d9e` fix: correct check-digit weighting order

（草稿由 conventional commits 归类生成，发布前请人工润色）""",
        "errs": [
            ("CHG_E_NO_GIT", "目录不是 git 仓库", "在仓库根目录运行或用 --repo 指定路径"),
            ("CHG_E_NO_COMMITS", "区间内没有提交", "检查 --from/--to 区间或 tag 是否存在"),
            ("CHG_E_GIT_FAIL", "git 命令执行失败", "确认 git 可用且仓库可读"),
        ],
        "faq": [
            ("支持中文提交信息吗？", "支持。分类只看 conventional 前缀（feat/fix/...），描述语言不限。"),
            ("会直接覆盖我的 CHANGELOG.md 吗？", "仅当显式传 --out 时写入，且走临时文件+原子替换；校验失败不会覆盖旧文件。"),
        ],
        "claim_zh": "conventional commits 进，符合规范的 CHANGELOG 草稿出，零依赖一条命令。",
        "claim_en": "Turn conventional commits into a Keep a Changelog draft. Zero-dependency CLI.",
        "keywords": "changelog conventional-commits 发版 CHANGELOG git log release notes 版本发布",
    },
    {
        "slug": "env-var-audit",
        "snake": "env_var_audit",
        "dn": "环境变量审计器",
        "dnen": "Environment Variable Auditor",
        "cat": "安全合规",
        "glyph": "E",
        "pain": "代码里 os.getenv 了三个新变量忘写进 .env.example，新人克隆跑不起来；更怕的是哪个密码被硬编码进了源码",
        "usage": """```bash
# 审计当前项目
python scripts/env_var_audit.py .

# JSON 输出
python scripts/env_var_audit.py . --json
```""",
        "sample": """$ env_var_audit.py .
代码读取的环境变量：5 · .env.example 声明：4
  未文档化 MEDIUM：AWS_REGION（代码使用，example 未列）
  硬编码疑密 HIGH：DB_PASSWORD = "hunter2secret123" (app/db.py:12)
发现高危项，rc=1""",
        "errs": [
            ("EVA_E_NO_DIR", "目录不存在", "传入正确的项目根目录"),
            ("EVA_E_NO_FILES", "未发现可扫描的源码文件", "确认目录含 .py/.js/.ts/.sh 文件"),
        ],
        "faq": [
            ("HIGH 是怎么判定的？", "两类：值匹配已知密钥前缀（ghp_/sk-/AKIA/xoxb 等），或疑似密钥字段名被赋以 12 位以上字面量且不是占位符。"),
            ("会误报吗？", "会有少量误报（如示例代码里的假密钥）。工具只做静态启发式并给出文件行号证据，处置由人决定。"),
        ],
        "claim_zh": "克隆即跑不起来？密钥进了源码？一条命令把环境变量账目对清。",
        "claim_en": "Audit env vars: undocumented keys, unused examples, hardcoded secrets.",
        "keywords": "环境变量 .env.example 硬编码密钥 secret scanning env audit 配置审计 泄漏防护",
    },
]

SKILL_TMPL = """---
name: __SLUG__
description: __DESC__
slug: __SLUG__
version: 1.0.0
display_name: __DN__
display_name_en: __DNEN__
agent_created: true
author: zhaoxinghua09-cell
license: MIT
category: __CAT__
platforms: [claude, codex, cursor, windsurf, workbuddy]
---

# __DN__ / __DNEN__

**__SLUG__** v1.0.0 · LGD-Powered 家族 · 零依赖 · 确定性输出（JSON IR）· 修复回执错误码

## 痛点
__PAIN__

## 用法
__USAGE__

## 输出示例（真机）
```
__SAMPLE__
```

## 退出码与错误码
- rc=0 通过 / rc=1 发现问题 / rc=2 用法错误
__ERRTAB__

## FAQ
__FAQ__

## 免责 / Disclaimer
__SLUG__ 输出为确定性格式/结构判定与规则化建议，不构成法规意见、安全承诺或专业咨询；关键决策请人工复核并以官方最新要求为准。
"""

README_TMPL = """# __DN__ / __DNEN__

![license](https://img.shields.io/badge/license-MIT-blue) ![python](https://img.shields.io/badge/python-3.8%2B-green) ![deps](https://img.shields.io/badge/deps-zero-orange) ![LGD](https://img.shields.io/badge/LGD--Powered-三律-teal)

> `__SLUG__` v1.0.0 · Zero-dependency · Deterministic output (JSON IR) · Receipt-style errors

**__CLAIM_ZH__**

**EN**: __CLAIM_EN__

**关键词 / Keywords**: __KEYWORDS__

## Install & Try / 安装即试
```bash
mkdir -p ~/.claude/skills/__SLUG__/scripts
curl -fsSL https://raw.githubusercontent.com/__REPO__/main/skills/__SLUG__/scripts/__SNAKE__.py -o ~/.claude/skills/__SLUG__/scripts/__SNAKE__.py
python ~/.claude/skills/__SLUG__/scripts/__SNAKE__.py --help
```
其他 Agent：`~/.config/opencode/skills/`、`~/.agents/skills/` 等同结构放置；WorkBuddy 对话内直接装。

## Usage / 用法
__USAGE__

## Sample output / 真机输出
```
__SAMPLE__
```

## Exit codes & error receipts / 退出码与修复回执
- rc=0 ok / rc=1 findings / rc=2 usage
__ERRTAB__

## FAQ
__FAQ__

## Links / 快链
- 仓库: https://github.com/__REPO__/tree/main/skills/__SLUG__
- 家族门户: https://zhaoxinghua09-cell.github.io/lgd-hub/
- Issues: https://github.com/__REPO__/issues

## Disclaimer / 免责
__DISCL__

License MIT © __SLUG__ authors. LGD-Powered badge: [定版真源](https://medxpert.cn/badge/powered/svg/lgd-powered-en.svg?v=84)
"""

ICON_FONTS = [
    "C:/Windows/Fonts/msyhbd.ttc", "C:/Windows/Fonts/msyh.ttc",
    "C:/Windows/Fonts/simhei.ttf", "C:/Windows/Fonts/seguisym.ttf",
]


def make_icons(slug, glyph):
    from PIL import Image, ImageDraw, ImageFont
    NAVY, TEAL, WHITE = (11, 31, 58, 255), (20, 184, 166, 255), (255, 255, 255, 255)
    img = Image.new("RGBA", (512, 512), NAVY)
    d = ImageDraw.Draw(img)
    d.ellipse([36, 36, 476, 476], outline=TEAL, width=18)
    d.ellipse([76, 76, 436, 436], outline=(20, 184, 166, 90), width=6)
    size = 170 if len(glyph) > 1 else 210
    font = None
    for p in ICON_FONTS:
        try:
            font = ImageFont.truetype(p, size)
            break
        except Exception:
            continue
    if font is not None:
        try:
            bbox = d.textbbox((0, 0), glyph, font=font)
            w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
            d.text((256 - w / 2 - bbox[0], 256 - h / 2 - bbox[1]), glyph, font=font, fill=WHITE)
        except Exception:
            font = None
    if font is None:
        d.rectangle([196, 196, 316, 316], fill=TEAL)
    img.save(BASE / slug / "icon.png")
    badge = Image.new("RGBA", (256, 96), NAVY)
    b = ImageDraw.Draw(badge)
    b.rectangle([4, 4, 251, 91], outline=TEAL, width=6)
    f2 = None
    for p in ICON_FONTS:
        try:
            f2 = ImageFont.truetype(p, 40)
            break
        except Exception:
            continue
    if f2 is not None:
        b.text((24, 24), "LGD", font=f2, fill=WHITE)
        b.text((108, 28), "Powered", font=ImageFont.truetype(ICON_FONTS[1], 26), fill=TEAL)
    badge.save(BASE / slug / "lgd-powered.png")


def errtab(errs):
    rows = ["| 错误码 | 含义 | 建议修复 |", "|---|---|---|"]
    for code, meaning, fix in errs:
        rows.append("| %s | %s | %s |" % (code, meaning, fix))
    return "\n".join(rows)


def faqblk(faqs):
    out = []
    for q, a in faqs:
        out.append("**%s**\n\n%s\n" % (q, a))
    return "\n".join(out)


def discl_zh(slug):
    return ("%s 输出为确定性格式/结构判定与规则化建议，不构成法规意见、安全承诺或专业咨询；"
            "关键决策请人工复核并以官方最新要求为准。" % slug)


def write_scripts():
    import scripts_b
    for sk in SKILLS:
        dst = BASE / sk["slug"] / "scripts" / (sk["snake"] + ".py")
        dst.parent.mkdir(parents=True, exist_ok=True)
        src = getattr(scripts_b, "S_" + sk["snake"].upper())
        dst.write_text(src, encoding="utf-8", newline="\n")


def main():
    for sk in SKILLS:
        sdir = BASE / sk["slug"]
        sdir.mkdir(parents=True, exist_ok=True)
        desc = "%s — %s（零依赖，确定性输出，rc=0/1/2，--json 机器可读）" % (sk["dn"], sk["pain"])
        common = {
            "__SLUG__": sk["slug"], "__SNAKE__": sk["snake"], "__DN__": sk["dn"],
            "__DNEN__": sk["dnen"], "__CAT__": sk["cat"], "__PAIN__": sk["pain"],
            "__DESC__": desc, "__USAGE__": sk["usage"], "__SAMPLE__": sk["sample"],
            "__ERRTAB__": errtab(sk["errs"]), "__FAQ__": faqblk(sk["faq"]),
            "__REPO__": REPO, "__CLAIM_ZH__": sk["claim_zh"], "__CLAIM_EN__": sk["claim_en"],
            "__KEYWORDS__": sk["keywords"], "__DISCL__": discl_zh(sk["slug"]),
        }
        sk_md = SKILL_TMPL
        for k, v in common.items():
            sk_md = sk_md.replace(k, v)
        (sdir / "SKILL.md").write_text(sk_md, encoding="utf-8", newline="\n")
        rd = README_TMPL
        for k, v in common.items():
            rd = rd.replace(k, v)
        (sdir / "README.md").write_text(rd, encoding="utf-8", newline="\n")
        make_icons(sk["slug"], sk["glyph"])
        print("[OK] %s (%s)" % (sk["slug"], sk["cat"]))
    write_scripts()
    print("done: %d skills" % len(SKILLS))


if __name__ == "__main__":
    main()
