# -*- coding: utf-8 -*-
"""推送本地 main 到 AtomGit（token 由 vault 子进程取，不直接出现在本文件）。超时加长，错误脱敏。"""
import subprocess, pathlib, re

BASE = pathlib.Path("D:/Workbuddy/05-工具/agent-skills")
VAULT_PY = "C:/Users/Administrator/.ucvault_local/vault.py"
PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
TOKEN = subprocess.run([PY, VAULT_PY, "get", "atomgit_api_key"], capture_output=True, text=True).stdout.strip()
URL = f"https://gcw_PcK6ZWCL:{TOKEN}@atomgit.com/gcw_PcK6ZWCL/agent-skills.git"

def scrub(s):
    return re.sub(r"[A-Za-z0-9_]{20,}", "<redacted>", s)

try:
    r = subprocess.run(["git", "push", "--force", URL, "main"],
                        cwd=str(BASE), capture_output=True, text=True, timeout=300)
    out = scrub((r.stdout or "") + (r.stderr or ""))
    print("rc=", r.returncode)
    print(out[-600:])
except subprocess.TimeoutExpired as e:
    print("TIMEOUT after 300s (push may be ongoing server-side):", scrub(str(e))[-300:])
except Exception as e:
    print("ERR:", scrub(str(e))[-300:])
