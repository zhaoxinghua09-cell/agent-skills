---
name: model-card-generator
description: model-card-generator — 给团队内任何 AI 系统/智能体生成一页『模型卡』：身份/用途/数据/限制/风险/联系人，输出 Markdown+JSON，对齐模型卡惯例与透明度义务。
slug: model-card-generator
version: 1.0.0
display_name: 模型卡生成器
display_name_en: Model Card Generator
agent_created: true
author: 诺声(Logos)@SynomosAI
license: MIT
category: AI 治理
platforms: [claude-code, codebuddy, workbuddy, openai-agents]
copyright: SynomosAI
---
# 模型卡生成器（Model Card Generator）

LGD 广谱爆款系列：把"有籍·有证·有门禁"做成人人天天用得上的工具。

## 解决什么痛点

团队里 AI 系统越接越多，却说不清每个『它是谁、干什么、不能干什么』——出事后无档可查。

## 功能

给团队内任何 AI 系统/智能体生成一页『模型卡』：身份/用途/数据/限制/风险/联系人，输出 Markdown+JSON，对齐模型卡惯例与透明度义务。

## 用法

见 `scripts/` 下脚本 `--help`。零依赖（stdlib only），Windows/Linux/macOS 均可运行。

## 对应理论

- LGD-I 有籍（每个 AI 系统有一页身份卡） · 域码 TH-LGD-006

## 免责声明

本工具为治理辅助框架，口径以监管官方最新文本为准，不构成法律意见。

---
© MedXpert × SynomosAI · LGD-Powered

## 安装与使用矩阵

```bash
# 一键获取（skills CLI）
npx skills add zhaoxinghua09-cell/agent-skills -g

# 或手动：克隆后拷贝本技能到你的 Agent 技能目录
git clone https://github.com/zhaoxinghua09-cell/agent-skills.git
cp -r agent-skills/skills/model-card-generator ~/.claude/skills/
```

| Agent | 技能目录 | 运行示例 |
|---|---|---|
| Claude Code | `~/.claude/skills/model-card-generator/` | 让 Claude 按本技能 SKILL.md 工作流调用 `scripts/` |
| Codex CLI / Cursor / WorkBuddy | 各自 skills 目录 | 同上，SKILL.md 即操作规程 |
| 直接命令行 | 任意位置 | `python scripts/model_card_generator.py --help` |
