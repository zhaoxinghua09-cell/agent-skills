# -*- coding: utf-8 -*-
"""从 76 个终检通过的 zip 生成 SkillHub 待传清单(字段照抄级)。"""
import re
import sys
import zipfile
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path("D:/Workbuddy/2026-09-06-08-06-50/上线规划/SkillHub上架包_81家族_20260908")
OUT = ROOT / "待传清单_20260908.md"

BATCH = [
    ("批1 · 效率流量款（建议最先传，蹭下载热度）", {"效率工具"}),
    ("批2 · LGD 治理旗舰（家族门面，含三律审计/认证/徽章）", {"AI 治理"}),
    ("批3 · 安全与合规守门", {"AI安全", "AI合规", "AI学习方法论"}),
    ("批4 · 工程方法与办公效率", {"AI工程方法", "开发效率", "办公效率"}),
]

rows = {}
for z in sorted(ROOT.glob("*.zip")):
    with zipfile.ZipFile(z) as zf:
        sk = zf.read(z.stem + "/SKILL.md").decode("utf-8", errors="replace")
    fm = re.match(r"^---\n(.*?)\n---", sk, re.S).group(1)
    g = lambda k: (re.search(r"^%s:\s*(.+)$" % k, fm, re.M).group(1).strip().strip('"') if re.search(r"^%s:" % k, fm, re.M) else "")
    cat = g("category")
    disp = g("display_name") or g("displayName") or z.stem
    ver = g("version")
    summ = g("summary") or g("description")
    summ = summ[:42] + "…" if len(summ) > 43 else summ
    rows[z.stem] = (disp, cat, ver, summ)

lines = [
    "# SkillHub 补传清单 · 81 家族 76 包（2026-09-08 · P-057）",
    "",
    "**包位置**: `D:/Workbuddy/2026-09-06-08-06-50/上线规划/SkillHub上架包_81家族_20260908/*.zip`",
    "",
    "**上传方式**（铁律：点传由 Steven 手动完成，AI 不代发）:",
    "1. 浏览器登录 SkillHub（微信 OAuth · user_8a3569c1）",
    "2. 逐个上传 zip；名称/displayName/category/tags 全部照抄下表（SKILL.md frontmatter 里都有）",
    "3. 每传完一批在表内打勾；建议一天一批，观察审核口径再放下一批",
    "",
    "## ⚠️ 勿重复上传（已在 SkillHub，有 skillId 记录）",
    "",
    "| slug | skillId |",
    "|---|---|",
    "| session-continuity-protocol | 189923 |",
    "| dpapi-local-vault | 189924 |",
    "| ai-brain-learning-memory（改名 medxpert-brain-learning-memory） | 189941 |",
    "| agent-evolution | 173852 |",
    "| a3-law-operational | 178474 |",
    "",
    "**口径说明**: 本批 76 包统一 `author: 诺声(Logos)@SynomosAI` + `copyright: SynomosAI` + MIT（与已过审先例一致）；每包含 SKILL.md / README / LICENSE / manifest.json / ATTESTATION.md 权属五件套；已通过真名/路径/密钥强制扫描（零残留）。早前 25 个医械 MCP 包（注册老炮@MedXpert 口径）保持现状不动。",
    "",
]
for title, catset in BATCH:
    sub = sorted([s for s, r in rows.items() if r[1] in catset])
    lines.append("## %s — %d 件" % (title, len(sub)))
    lines.append("")
    lines.append("| ☐ | slug | 显示名 | 分类 | 版本 | 一句话 |")
    lines.append("|---|---|---|---|---|---|")
    for s in sub:
        d, c, v, u = rows[s]
        lines.append("| ☐ | %s | %s | %s | %s | %s |" % (s, d, c, v, u))
    lines.append("")
total = sum(len([s for s, r in rows.items() if r[1] in cs]) for _, cs in BATCH)
lines.append("**合计 %d 包 = 已传 5 + 本批 76 = 81 家族全量。**" % total)
OUT.write_text("\n".join(lines), encoding="utf-8")
print("清单已生成:", OUT, "| 覆盖", total, "包")
