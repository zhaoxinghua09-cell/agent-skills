from PIL import Image, ImageDraw, ImageFont, ImageFilter
import os

BASE = "D:/Workbuddy/05-工具/agent-skills"
OUT = os.path.join(BASE, "cover.png")
FONT = "C:/Windows/Fonts/simhei.ttf"
NAVY = (11, 31, 58)
NAVY2 = (8, 22, 40)
TEAL = (20, 184, 166)
WHITE = (255, 255, 255)
GREY = (200, 211, 224)

W, H = 900, 383
img = Image.new("RGBA", (W, H), NAVY)
# vertical gradient
for y in range(H):
    t = y / H
    c = tuple(int(NAVY[i] * (1 - t) + NAVY2[i] * t) for i in range(3))
    ImageDraw.Draw(img).line([(0, y), (W, y)], fill=c + (255,))

d = ImageDraw.Draw(img)

# decorative teal translucent circles (top-right)
for (cx, cy, r, a) in [(760, 60, 120, 38), (840, 130, 70, 26), (700, 150, 50, 20)]:
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=TEAL + (a,))

# left teal bar
d.rectangle([0, 0, 10, H], fill=TEAL + (255,))

def font(sz):
    return ImageFont.truetype(FONT, sz)

# kicker
d.text((48, 44), "LGD 治理理论  ·  通用 AI 智能体技能", font=font(19), fill=TEAL)
# title (two lines)
d.text((46, 86), "4 个让 AI 自己都", font=font(46), fill=WHITE)
d.text((46, 146), "想装的通用技能", font=font(46), fill=WHITE)
# subtitle
d.text((48, 214), "不局限医疗  ·  零依赖  ·  每个带一个能直接跑的脚本", font=font(20), fill=GREY)

# chips row: 4 skills
skills = [
    ("context-engineering", "上下文工程"),
    ("ai-cost-cutter", "AI 省钱跑批"),
    ("prompt-injection-shield", "提示注入防护"),
    ("eu-ai-act-companion", "EU AI Act 导航"),
]
chip_y, chip_h = 286, 70
chip_w = 196
gap = 12
x0 = 48
for i, (slug, label) in enumerate(skills):
    x = x0 + i * (chip_w + gap)
    # chip bg
    d.rounded_rectangle([x, chip_y, x + chip_w, chip_y + chip_h], radius=12,
                        fill=(255, 255, 255, 22), outline=(255, 255, 255, 45))
    # icon
    ic = Image.open(f"{BASE}/{slug}/icon.png").convert("RGBA").resize((40, 40), Image.LANCZOS)
    img.paste(ic, (x + 14, chip_y + 15), ic)
    # label
    d.text((x + 64, chip_y + 25), label, font=font(19), fill=WHITE)

# LGD-Powered badge bottom-right
badge = Image.open(f"{BASE}/lgd-powered.png").convert("RGBA")
bw = 132
bh = int(badge.size[1] * bw / badge.size[0])
badge = badge.resize((bw, bh), Image.LANCZOS)
img.paste(badge, (W - bw - 30, H - bh - 22), badge)

img.convert("RGB").save(OUT)
print("cover saved", OUT, Image.open(OUT).size)
