# CSV 切片器 / CSV Slice

> `csv-slice` v1.0.0 · LGD-Powered Utility Family · Zero-dependency

**中文**：想看下CSV前几行某几列，打开Excel卡半天，写pandas又太重 一条命令搞定；默认 dry-run 预览、`--apply` 才执行、`--json` 机器可读；成功 rc=0 / 发现问题 rc=1 / 用法错误 rc=2。

**EN**: One command for daily file/text chores. Dry-run by default, `--apply` to execute, `--json` for machines. rc=0 ok / rc=1 findings / rc=2 usage.

## Usage / 用法
```bash
python scripts/csv_slice.py --help
```

## Disclaimer / 免责
Efficiency aid only — back up important data before --apply. / 效率辅助，--apply 前请备份重要数据。
