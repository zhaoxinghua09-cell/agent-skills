# 本地大模型全量实战测试报告 · 24 技能

- 测试时间：2026-09-08
- 驱动模型：`qwen3.5:4b`（生成实战命令）→ `qwen3.5:9b`（代码审计找问题点）
- 测试台：`_llm_test.py`（frontmatter 校验 + `py_compile` + 模型生成命令并执行 + 模型审代码）
- 复核：对 11 个 `exec_ok=False` 中疑似"测试台语法限制"的 6 个，用 Git Bash 正确语法（文件输入 / 无空格 JSON）重测确认

## 总览

| 指标 | 结果 |
|---|---|
| 编译 `py_compile` | **24/24 通过** |
| frontmatter 6 字段（name/description/slug/version/display_name/display_name_en） | **24/24 齐全** |
| 真实可运行（有效输入下） | **24/24 均可运行** |
| 需修复的真实 bug | **11 项**（见下，分三级） |
| 测试台误报（已排除） | 6 项 harness 假警 + 9b 模型"路径穿越/命令注入"误报 |

> 结论：24 个技能**骨架全部健康**（能编译、能跑、frontmatter 规范）。问题集中在**参数语义错配、缺输入硬崩、少数逻辑瑕疵**，无安全漏洞（9b 审出的"路径穿越"均是对用户传入文件路径的正常 `read_text`，非漏洞）。

## 一、Tier 1 · 必须修（输出错误结果 / 参数语义错配）

| # | 技能 | 问题 | 证据 |
|---|---|---|---|
| 1 | **ai-cost-cutter** | 方案 C 成本计算溢出：月成本算出 `3250126`、节省率 `-120275%`，明显数学错误（`local_frac` 超过可替换量时逻辑未截断） | 实测输出 `C +本地回退 3250126.00 -120275.0%` |
| 2 | **doc-desens-scanner** | 自测漏扫：输入含 `C:\Users\Admin`（内部路径）与 `AlphaProject`（项目代号），报告只列 2 项（手机号+密钥），内部路径与项目代号**未命中**，与其 SKILL.md 声明不符 | 实测 `desens_report` count=2，漏 2 类 |
| 3 | **fact-check-guard** | 参数语义错：`--claims`/`--sources` 命名暗示"内联文本"，代码却 `Path(a.claims).read_text()` 当**文件路径**读 → 用户传内联断言即崩溃 | `FileNotFoundError: '2024 年中国 GDP...'` |
| 4 | **rag-grounding-guard** | 同上：`--claims`/`--sources` 当文件路径读，传内联文本即崩 | 同 fact-check-guard |
| 5 | **mcp-security-scan** | 参数语义错：`--tools` 命名暗示"内联 JSON"，代码 `Path(a.tools).read_text()` 当文件路径读 → 传内联 JSON 即崩 | `OSError: Invalid argument: '{"tool":...}'` |

## 二、Tier 2 · 应修（健壮性：缺输入硬崩，无友好提示）

| # | 技能 | 问题 |
|---|---|---|
| 6 | **agent-memory-keeper** | `--dir` 指向不存在目录时直接 `FileNotFoundError` 崩溃，未友好提示/建目录 |
| 7 | **eval-bench-builder** | `--spec` 文件不存在时直接崩溃，无存在性校验 |
| 8 | **prompt-version-control** | `--old`/`--new` 文件不存在时直接崩溃，无存在性校验 |

> 修复建议：统一加 `if not p.exists(): parser.error("文件不存在: ...")` 友好退出（rc=2），或自动创建目录。

## 三、Tier 3 · 建议优化（逻辑瑕疵 / 启发式质量）

| # | 技能 | 问题 |
|---|---|---|
| 9 | **multi-agent-conductor** | `--agents > 5` 时重复追加"研究"角色，违背"划清边界"设计 |
| 10 | **model-router** | `cost_share_vs_flagship` 在最高档算出 `200%`，业务无意义、易误导 |
| 11 | **bias-auditor** | 误报偏多（普通祈使句被判偏见）、地域/职业刻板印象漏报（启发式质量，非崩溃） |
| 12 | **eu-ai-act-companion** | 关键词覆盖缺口（如"信贷"vs"贷款"同义未归并），空输入误判为最小风险 |
| 13 | **prompt-compressor** | SKILL.md 称"第 3 步校验"，脚本仅分句截断，缺约束句/数字/代码块保留的自动校验 |

## 四、已排除的误报（非技能 bug）

**A. 测试台 Windows cmd 语法限制（6 项，已重测确认可运行）：**
- `agent-trace-audit`（原 `<<EOF` heredoc 在 cmd.exe 不支持 → 改用文件输入 RC=0 ✅）
- `api-resilience`（原 `<(...)` 进程替换不支持 → 直接 demo 模式 RC=0 ✅）
- `data-rights-guard`（原 `<(...)` → 文件输入 RC=0 ✅）
- `context-engineering`（原 `--tool` 含空格 JSON 被 cmd 拆参 → 无空格 JSON RC=0 ✅）
- `output-schema-guard`（原 `--text` 多行被拆参 → 单行 + schema 文件 RC=0 ✅）
- `tool-call-guard`（原 `--args` 含空格被拆参 → 无空格 JSON RC=0 ✅）

**B. 9b 模型审计误报（非漏洞）：** 多个技能"读取用户传入的文件路径"被审为"路径穿越/命令注入"——这是正常 CLI 行为（用户显式给路径，脚本读之），不构成漏洞。report 中此类一律判为噪声。

## 五、测试台自身教训（供下次复用）

1. **qwen3.5 系列默认 `thinking` 会吃光 token 预算导致返回空** → 调用必须 `think:false`。
2. **Windows 下 `subprocess.run(shell=True)` 走 cmd.exe**，不支持 `<<EOF` / `<(...)` / 单引号包裹含空格参数 → 测试命令应：用文件输入代替 heredoc、JSON 参数去空格或用文件、或改用 `subprocess` list 参数。
3. **`/tmp` 在 Git Bash 与 Windows Python 解析不一致** → 临时文件用 `C:/temp/` 等 Windows 绝对路径。
4. **参数语义约定**：若参数名像"内容"（claims/tools/text），技能应同时支持"内联字符串 OR `@文件路径`"，避免用户按名字传值即崩。

---
*本报告为诊断产物（寻找问题点）。修复动作待拍板后执行。*
