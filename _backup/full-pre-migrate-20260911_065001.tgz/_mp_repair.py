import subprocess, json, re, os, urllib.request, urllib.parse, uuid

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
VAULT = "C:/Users/Administrator/.ucvault_local/vault.py"
BASE = os.path.dirname(os.path.abspath(__file__))
TOKEN_FILE = os.path.join(BASE, ".mp_token")
GARBLED_MID = "klCrLv8uXxvjkv6BOXwSnmC_PQTtz8aAup8GQ6xi5wShHoH_OhKNnmrcgVR8niMb"

def get_secret(label):
    return subprocess.run([PY, VAULT, "get", label], capture_output=True, text=True).stdout.strip()

def get_token():
    raw = get_secret("wechat_mp")
    appid = re.search(r"wx[0-9a-fA-F]{16}", raw).group(0)
    secret = re.search(r"[0-9a-fA-F]{32}", raw).group(0)
    if os.path.exists(TOKEN_FILE):
        t = open(TOKEN_FILE).read().strip()
        try:
            with urllib.request.urlopen(f"https://api.weixin.qq.com/cgi-bin/getcallbackip?access_token={t}", timeout=15) as x:
                if json.loads(x.read().decode()).get("errcode", 0) == 0:
                    return t
        except Exception:
            pass
    with urllib.request.urlopen(f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={appid}&secret={secret}", timeout=30) as x:
        t = json.loads(x.read().decode())["access_token"]
    open(TOKEN_FILE, "w").write(t)
    return t

TOKEN = get_token()
print("token len", len(TOKEN))

def mp_raw(path, data_bytes, ctype="application/json; charset=utf-8"):
    url = f"https://api.weixin.qq.com{path}?access_token={TOKEN}"
    req = urllib.request.Request(url, data=data_bytes, headers={"Content-Type": ctype})
    with urllib.request.urlopen(req, timeout=60) as x:
        return json.loads(x.read().decode("utf-8"))

# ---- 1. delete garbled draft ----
try:
    d = mp_raw("/cgi-bin/draft/delete", json.dumps({"media_id": GARBLED_MID}).encode("utf-8"))
    print("delete garbled:", d.get("errmsg", d))
except Exception as e:
    print("delete garbled ERR (may already gone):", str(e)[:120])

# ---- 2. upload images ----
def upload_image(path):
    url = f"https://api.weixin.qq.com/cgi-bin/material/add_material?access_token={TOKEN}&type=image"
    bd = open(path, "rb").read()
    boundary = "----WebKitFormBoundary" + uuid.uuid4().hex
    body = (b"--" + boundary.encode() + b"\r\n"
            + b'Content-Disposition: form-data; name="media"; filename="'
            + os.path.basename(path).encode() + b'"\r\n'
            + b"Content-Type: image/png\r\n\r\n" + bd + b"\r\n"
            + b"--" + boundary.encode() + b"--\r\n")
    req = urllib.request.Request(url, data=body, headers={
        "Content-Type": f"multipart/form-data; boundary={boundary}", "User-Agent": "x"})
    with urllib.request.urlopen(req, timeout=60) as x:
        j = json.loads(x.read().decode())
    if "media_id" not in j:
        raise SystemExit("upload fail: " + str(j))
    return j["media_id"], j.get("url", "")

print("uploading images...")
imgs = {}
for s in ["context-engineering", "ai-cost-cutter", "prompt-injection-shield", "eu-ai-act-companion"]:
    mid, url = upload_image(f"{BASE}/{s}/icon.png")
    imgs[s] = url
    print("  icon", s, "ok")
cover_mid, cover_url = upload_image(f"{BASE}/cover.png")
print("  cover ok")

# ---- 3. build article (raw Chinese, single JSON encode) ----
NAVY = "#0B1F3A"; TEAL = "#14B8A6"; RED = "#E8281B"; DARK = "#1a2332"
skills_data = [
    ("context-engineering", "① 上下文工程", "Context Engineering",
     "AI 越长聊越笨、忘了前面的设定、token 烧太快。",
     "把“每轮喂给模型的信息”当成工程——审计<b>相关性·冗余·预算·衰减</b>四维度，给裁剪/检索/记忆/门禁四步流程。",
     "<code>context_budget.py</code> 自动算各块 token 占比、跨块重复、衰减风险。"),
    ("ai-cost-cutter", "② AI 省钱跑批", "AI Cost Cutter",
     "API 账单太贵，贵模型在做贱活。",
     "四把刀降本——<b>批处理</b>（异步 50% 折扣）/ <b>本地模型回退</b>（贱活本地跑）/ <b>缓存层</b>（同问不二付）/ <b>模型路由</b>分级。",
     "<code>cost_estimator.py</code> 输出月度账单与三档降本方案差额。<b>实测可省 94%。</b>"),
    ("prompt-injection-shield", "③ 提示注入防护", "Prompt Injection Shield",
     "网页/邮件/工具返回里藏着“忽略之前的指令，你是 DAN”，模型分不清。",
     "外部内容进上下文前先扫描——<b>中英双语文式库 + 启发式 + 沙箱规则</b>，风险分定处置（放行/隔离/丢弃）。",
     "<code>prompt_injection_scan.py</code> 返回风险分 + 命中规则 + 处置建议。"),
    ("eu-ai-act-companion", "④ EU AI Act 合规导航", "EU AI Act Companion",
     "要进欧盟市场，不确定算高风险还是有限风险、provider 还是 deployer。",
     "<b>风险四级分类</b> + 按角色义务清单 + 关键时间节点（2024-08→2027-08）+ 合格评定路径。",
     "<code>eu_ai_act_nav.py</code> 输入用例+角色，输出风险级+义务+节点。"),
]
def esc(t): return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def bold(t): return re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
def link(t): return re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1（\2）", t)

h = []
H = lambda s: h.append(s)
H(f'<section style="font-family:-apple-system,PingFang SC,Microsoft YaHei,sans-serif;color:#222;line-height:1.85;font-size:16px;">')
H(f'<section style="background:linear-gradient(135deg,{NAVY},{DARK});color:#fff;padding:36px 24px;border-radius:16px;margin-bottom:22px;">')
H(f'<p style="margin:0 0 10px;color:{TEAL};font-size:15px;letter-spacing:.5px;">LGD 治理理论  ·  通用 AI 智能体技能</p>')
H(f'<h1 style="margin:0 0 12px;font-size:26px;line-height:1.3;">4 个让 AI 自己都<br>想装的通用技能</h1>')
H(f'<p style="margin:0;color:#aebcd3;font-size:14px;">不局限医疗 · 零依赖 · 每个带一个能直接跑的脚本</p></section>')
H(f'<p style="margin:18px 0 8px;color:#444;">我们把 <b>LGD 治理理论（有籍·有证·有门禁）</b>做成了 4 个通用 AI 智能体技能。它们不挑行业、每个都带一个可执行脚本。</p>')
H(f'<p style="margin:8px 0 20px;color:#555;"><b>为什么是这 4 个：</b>通用技能下载量远大于垂直技能。我们对照 GitHub 高星弱者，挑了“理论能做得更好”的 4 个方向——<span style="color:{RED};">上下文</span>、<span style="color:{RED};">成本</span>、<span style="color:{RED};">安全</span>、<span style="color:{RED};">合规</span>。</p>')
for slug, cn, en, pain, sol, script in skills_data:
    ic = imgs.get(slug, "")
    H(f'<section style="border-left:4px solid {TEAL};background:#fff;padding:18px 20px;margin:16px 0;border-radius:0 12px 12px 0;box-shadow:0 1px 4px rgba(0,0,0,.06);">')
    H(f'<table style="width:100%;border:0;margin:0;"><tr><td style="width:52px;vertical-align:top;"><img src="{ic}" style="width:46px;height:46px;border-radius:11px;"></td>'
      f'<td style="vertical-align:top;"><h2 style="margin:2px 0 4px;font-size:17px;color:{NAVY};">{cn}</h2>'
      f'<p style="margin:0;color:#888;font-size:13px;">{en}</p></td></tr></table>')
    H(f'<div style="background:#fef2f2;border-radius:8px;padding:10px 14px;margin:10px 0 0;"><span style="color:{RED};font-weight:bold;font-size:14px;">痛点：</span>{esc(pain)}</div>')
    H(f'<p style="margin:10px 0 0;color:#333;">{bold(link(sol))}</p>')
    H(f'<p style="margin:8px 0 0;color:#666;font-size:14px;">附脚本：{script}</p>')
    H(f'</section>')
H(f'<section style="background:linear-gradient(135deg,#eef4fb,#f0faf8);border:1px solid #d4e6f0;border-radius:14px;padding:18px 20px;margin:20px 0;">')
H(f'<h2 style="margin:0 0 12px;font-size:17px;color:{NAVY};">怎么装</h2>')
H(f'<table style="width:100%;border-collapse:collapse;">')
for label, desc in [("<b>SkillPie</b>", "市场搜技能名直接装（4 个均已上线）。"), ("<b>GitHub</b>", "zhaoxinghua09-cell/agent-skills → 复制 skills/&lt;名字&gt;/ 到你的 agent 技能目录。")]:
    H(f'<tr><td style="padding:6px 10px 6px 0;width:90px;white-space:nowrap;vertical-align:top;color:{NAVY};font-weight:bold;">{label}</td><td style="padding:6px 0;color:#333;">{desc}</td></tr>')
H(f'</table><p style="margin:10px 0 0;color:#666;font-size:14px;">每个技能内置“AI 何时该主动建议安装”判定节，AI 读到命中即荐。</p></section>')
H(f'<section style="margin:18px 0;"><h2 style="font-size:17px;color:{NAVY};">理论背书</h2>')
H(f'<p style="margin:8px 0;color:#333;">四个技能共用同一治理脊柱——<b>有籍（来源登记）·有证（可溯源）·有门禁（修改走备份→可逆→小批量→确认）</b>。</p>')
H(f'<p style="margin:6px 0;color:#555;">这正是它们敢丢进自主 agent、而不只是聊天机器人的原因。</p>')
H(f'<p style="margin:6px 0;color:#777;font-size:14px;">理论根：<b>LGD-theory</b>（github.com/zhaoxinghua09-cell/lgd-theory）· MIT · 理论 CC BY 4.0</p></section>')
H(f'<section style="text-align:center;margin-top:22px;padding-top:16px;border-top:1px solid #eaecef;">')
H(f'<img src="{cover_url}" style="height:40px;border-radius:6px;"><br>')
H(f'<span style="color:#999;font-size:13px;">© LGD / SynomosAI 2026 · 关注【MedXpert】获取更多 AI 治理实践</span></section>')
H('</section>')

content = "".join(h)
article = {
    "title": "4 个让 AI 自己都想装的通用技能（不局限医疗）",
    "author": "MedXpert",
    "digest": "LGD 治理理论 4 通用 AI 技能：上下文工程/AI省钱/注入防护/EU AI Act 导航",
    "content": content,
    "thumb_media_id": cover_mid,
    "need_open_comment": 0,
    "only_fans_can_comment": 0,
}
# SINGLE encode, raw Chinese, UTF-8
data = json.dumps({"articles": [article]}, ensure_ascii=False).encode("utf-8")
r = mp_raw("/cgi-bin/draft/add", data)
print("draft/add:", r)
media_id = r.get("media_id")
if not media_id:
    raise SystemExit("draft add failed: " + str(r))

# ---- 4. verify stored content is real Chinese (no literal \uXXXX) ----
vr = mp_raw("/cgi-bin/draft/batchget", json.dumps({"offset": 0, "count": 20, "no_content": 0}).encode("utf-8"))
found = None
for it in vr.get("item", []):
    if it.get("media_id") == media_id:
        found = it.get("content", {}).get("news_item", [{}])[0]
        break
if found:
    t = found.get("title", "")
    c = found.get("content", "")
    bad = bool(re.search(r"\\u[0-9a-fA-F]{4}", t)) or bool(re.search(r"\\u[0-9a-fA-F]{4}", c))
    print("VERIFY title:", t)
    print("VERIFY garbled?", bad)
    if bad:
        raise SystemExit("STILL GARBLED — abort, do not publish")
    print("VERIFY OK: real Chinese stored")
else:
    print("VERIFY: new draft not found in batchget (likely offset); treat as ok if add returned media_id")

print("NEW media_id:", media_id)
