# -*- coding: utf-8 -*-
"""Batch I 冒烟驱动：6 技能 × 真实沙箱用例。PASS/FAIL 统计，rc 语义全验。"""
import json, os, subprocess, sys, tempfile, shutil

sys.stdout.reconfigure(encoding="utf-8")
PY = sys.executable
BASE = r"D:/Workbuddy/05-工具/agent-skills"
passed, failed = 0, []


def run(slug, snake, args, cwd=None):
    p = subprocess.run([PY, os.path.join(BASE, slug, "scripts", snake + ".py")] + args,
                       capture_output=True, text=True, encoding="utf-8", errors="replace", cwd=cwd)
    return p.returncode, p.stdout


def check(name, ok, detail=""):
    global passed
    if ok:
        passed += 1
        print("  PASS %s" % name)
    else:
        failed.append(name)
        print("  FAIL %s | %s" % (name, detail[:200]))


def jout(out):
    try:
        return json.loads(out)
    except Exception:
        return {}


def main():
    tmp = tempfile.mkdtemp(prefix="batchi_")
    try:
        # ---------- udi-format-validator ----------
        print("udi-format-validator:")
        rc, out = run("udi-format-validator", "udi_format_validator",
                      ["(01)06901234567892(17)260930(10)LOT2026A(21)SN0001", "--json"])
        d = jout(out)
        check("合法串 rc0 valid", rc == 0 and d.get("valid") is True, out)
        check("解析批号/序列号", d.get("parsed", {}).get("10") == "LOT2026A" and d.get("parsed", {}).get("21") == "SN0001", out)
        rc, out = run("udi-format-validator", "udi_format_validator", ["(01)06901234567893", "--json"])
        d = jout(out)
        check("校验位错 rc1", rc == 1 and d["errors"][0]["code"] == "UDI_E_CHECKDIGIT", out)
        rc, out = run("udi-format-validator", "udi_format_validator", ["(01)06901234567892(17)261332", "--json"])
        d = jout(out)
        check("日期非法 rc1", rc == 1 and d["errors"][0]["code"] == "UDI_E_DATE", out)
        rc, out = run("udi-format-validator", "udi_format_validator", ["1026LOTABC", "--json"])
        d = jout(out)
        check("无括号变长歧义 rc1", rc == 1 and d["errors"][0]["code"] == "UDI_E_AMBIGUOUS", out)
        rc, out = run("udi-format-validator", "udi_format_validator", ["--di", "06901234567892"])
        check("--di 模式文本输出 rc0", rc == 0 and "校验位" in out, out)
        rc, out = run("udi-format-validator", "udi_format_validator", [])
        check("无参数 rc2", rc == 2, out)

        # ---------- clin-eval-route-picker ----------
        print("clin-eval-route-picker:")
        rc, out = run("clin-eval-route-picker", "clin_eval_route_picker",
                      ["--market", "nmpa", "--nmpa-class", "III", "--in-catalog", "no", "--eq-data", "no", "--json"])
        d = jout(out)
        check("III类目录外无数据→临床试验", rc == 0 and "临床试验" in d["routes"][0]["route"], out)
        rc, out = run("clin-eval-route-picker", "clin_eval_route_picker",
                      ["--market", "nmpa", "--nmpa-class", "II", "--in-catalog", "yes", "--json"])
        d = jout(out)
        check("目录内→免临床", rc == 0 and "免临床" in d["routes"][0]["route"], out)
        rc, out = run("clin-eval-route-picker", "clin_eval_route_picker",
                      ["--market", "nmpa", "--nmpa-class", "II", "--in-catalog", "no", "--eq-data", "yes", "--json"])
        d = jout(out)
        check("有同品种数据→等同路径", rc == 0 and "同品种" in d["routes"][0]["route"], out)
        rc, out = run("clin-eval-route-picker", "clin_eval_route_picker", ["--market", "nmpa", "--nmpa-class", "I"])
        check("I类→豁免", rc == 0 and "豁免" in out, out)
        rc, out = run("clin-eval-route-picker", "clin_eval_route_picker",
                      ["--market", "nmpa", "--nmpa-class", "II", "--in-catalog", "no", "--eq-data", "yes",
                       "--novel", "yes", "--json"])
        check("矛盾输入 rc1", rc == 1 and "CE_E_CONFLICT" in out, out)
        rc, out = run("clin-eval-route-picker", "clin_eval_route_picker", ["--market", "nmpa", "--in-catalog", "no", "--eq-data", "no", "--json"])
        check("缺分类 rc1 CE_E_MISSING", rc == 1 and "CE_E_MISSING" in out, out)
        rc, out = run("clin-eval-route-picker", "clin_eval_route_picker",
                      ["--market", "eu", "--eu-class", "IIa", "--wet", "yes"])
        check("EU WET→文献路径", rc == 0 and "文献路径" in out, out)

        # ---------- pmcf-plan-check ----------
        print("pmcf-plan-check:")
        full = ["objectives=生存率", "methods=文献+登记库", "endpoints=并发症", "follow_up_period=24个月",
                "statistical_plan=单臂目标值法", "benefit_risk_linkage=是", "pms_linkage=是",
                "cer_update_trigger=年度", "responsible_person=RA", "timeline=2026Q4"]
        rc, out = run("pmcf-plan-check", "pmcf_plan_check", sum([["--fields", f] for f in full], []))
        check("10/10 rc0", rc == 0 and "10/10" in out, out)
        sub = [f for f in full if not f.startswith(("statistical_plan", "timeline", "endpoints"))]
        rc, out = run("pmcf-plan-check", "pmcf_plan_check", sum([["--fields", f] for f in sub], []))
        check("缺3项 rc1 7/10", rc == 1 and "7/10" in out and "endpoints" in out, out)
        rc, out = run("pmcf-plan-check", "pmcf_plan_check", [])
        check("无输入 rc1", rc == 1 and "PMCF_E_NO_INPUT" in out, out)
        pf = os.path.join(tmp, "pmcf.json")
        with open(pf, "w", encoding="utf-8") as fh:
            json.dump({k.split("=")[0]: k.split("=")[1] for k in full}, fh, ensure_ascii=False)
        rc, out = run("pmcf-plan-check", "pmcf_plan_check", ["--plan", pf])
        check("JSON 计划文件 rc0", rc == 0 and "10/10" in out, out)

        # ---------- md-link-audit ----------
        print("md-link-audit:")
        docs = os.path.join(tmp, "docs")
        os.makedirs(os.path.join(docs, "sub"))
        with open(os.path.join(docs, "a.md"), "w", encoding="utf-8") as fh:
            fh.write("# intro\n\n[b](b.md) [bad](missing.md) [self](#intro) [dead](#nope) [ext](https://example.com/x)\n")
        with open(os.path.join(docs, "b.md"), "w", encoding="utf-8") as fh:
            fh.write("# B\n[up](a.md#intro)\n")
        rc, out = run("md-link-audit", "md_link_audit", [docs, "--json"])
        d = jout(out)
        s = d.get("summary", {})
        check("断链2 rc1", rc == 1 and s.get("internal_broken") == 2, out)
        check("外部链接离线跳过", s.get("external_bad") == 0 and "example.com" not in json.dumps(d.get("broken_by_file", [])), out)
        rc, out = run("md-link-audit", "md_link_audit", [os.path.join(tmp, "empty")])
        check("无目录 rc2", rc == 2 and "MLK_E_NO_DIR" in out, out)
        rc, out = run("md-link-audit", "md_link_audit", [os.path.join(tmp, "empty2")])
        os.makedirs(os.path.join(tmp, "empty2"))
        rc, out = run("md-link-audit", "md_link_audit", [os.path.join(tmp, "empty2")])
        check("无MD rc2", rc == 2 and "MLK_E_NO_MD" in out, out)

        # ---------- changelog-gen ----------
        print("changelog-gen:")
        repo = os.path.join(tmp, "repo")
        os.makedirs(repo)

        def g(*args):
            return subprocess.run(["git", "-C", repo] + list(args), capture_output=True, text=True,
                                  encoding="utf-8", errors="replace")
        g("init", "-q")
        g("config", "user.email", "t@t.local")
        g("config", "user.name", "t")
        with open(os.path.join(repo, "f.txt"), "w") as fh:
            fh.write("1\n")
        g("add", ".")
        g("commit", "-qm", "feat: add machine json output")
        with open(os.path.join(repo, "f.txt"), "a") as fh:
            fh.write("2\n")
        g("add", ".")
        g("commit", "-qm", "fix: correct check-digit weighting")
        with open(os.path.join(repo, "f.txt"), "a") as fh:
            fh.write("3\n")
        g("add", ".")
        g("commit", "-qm", "refactor(cli)!: rename flag")
        rc, out = run("changelog-gen", "changelog_gen", ["--repo", repo, "--version", "v0.1.0"])
        check("三段归类 rc0", rc == 0 and "Breaking" in out and "新增" in out and "修复" in out, out)
        rc, out = run("changelog-gen", "changelog_gen", ["--repo", repo, "--from", "HEAD", "--to", "HEAD"])
        d = jout(out)
        check("空区间 rc1", rc == 1 and d["errors"][0]["code"] == "CHG_E_NO_COMMITS", out)
        rc, out = run("changelog-gen", "changelog_gen", ["--repo", os.path.join(tmp, "nope")])
        check("非git目录 rc2", rc == 2 and "CHG_E_NO_GIT" in out, out)
        outp = os.path.join(repo, "CHANGELOG.md")
        rc, out = run("changelog-gen", "changelog_gen", ["--repo", repo, "--version", "v0.1.0", "--out", outp])
        check("--out 原子写入", rc == 0 and os.path.isfile(outp) and "Breaking" in open(outp, encoding="utf-8").read(), out)

        # ---------- env-var-audit ----------
        print("env-var-audit:")
        proj = os.path.join(tmp, "proj")
        os.makedirs(proj)
        with open(os.path.join(proj, "app.py"), "w", encoding="utf-8") as fh:
            fh.write("import os\nTOKEN = os.getenv('API_TOKEN')\n")
        with open(os.path.join(proj, "db.py"), "w", encoding="utf-8") as fh:
            fh.write("DB_PASSWORD = 'hunter2secret123'\n")
        rc, out = run("env-var-audit", "env_var_audit", [proj, "--json"])
        d = jout(out)
        check("HIGH rc1", rc == 1 and d["summary"]["high"] == 1, out)
        check("未文档化 MEDIUM", any(f["subject"] == "API_TOKEN" for f in d.get("findings", [])), out)
        with open(os.path.join(proj, ".env.example"), "w", encoding="utf-8") as fh:
            fh.write("API_TOKEN=your_token_here\nDB_HOST=localhost\n")
        rc, out = run("env-var-audit", "env_var_audit", [proj, "--json"])
        d = jout(out)
        check("补example后 undocumented=0", rc == 1 and d["summary"]["undocumented"] == 0, out)
        check("example 冗余 LOW", "DB_HOST" in json.dumps(d["summary"]), out)
        rc, out = run("env-var-audit", "env_var_audit", [os.path.join(tmp, "nope")])
        check("无目录 rc2", rc == 2 and "EVA_E_NO_DIR" in out, out)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("\n%d passed, %d failed" % (passed, len(failed)))
    if failed:
        print("FAILED:", failed)
        sys.exit(1)


if __name__ == "__main__":
    main()
