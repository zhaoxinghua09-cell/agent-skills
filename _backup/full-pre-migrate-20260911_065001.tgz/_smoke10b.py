# -*- coding: utf-8 -*-
"""10 痛点技能脚本冒烟测试：造样例输入，逐脚本真实跑一遍。"""
import subprocess, pathlib, tempfile, os

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
BASE = pathlib.Path("D:/Workbuddy/05-工具/agent-skills")
SCR = pathlib.Path(tempfile.mkdtemp(prefix="smoke10b_"))

def w(name, text):
    p = SCR / name
    p.write_text(text, encoding="utf-8")
    return p

# inputs
schema = w("schema.json", '{"required":["name","status"],"fields":{"name":{"type":"str"},"status":{"type":"str","enum":["pending","done","failed"]}}}')
good = w("good.json", '{"name":"x","status":"pending"}')
bad = w("bad.json", '{"name":"x"}')
claims = w("claims.txt", "研究表明运动有益健康。\nGDP去年增长了5%。\n某神秘疗法可治愈一切。")
refs = w("refs.txt", "权威期刊确认规律运动降低慢病风险。\n国家统计局公报显示去年GDP增长5.0%。")
trace = w("trace.txt", "1 search a\n2 search a\n3 search a\n4 search a\n5 write b\n6 write b")
v1 = w("v1.txt", "你是一个助手。\n用中文回答。")
v2 = w("v2.txt", "你是一个助手。\n用中文回答。\n先给结论再给理由。")
tools = w("tools.json", '[{"name":"run_shell","description":"execute shell command on host"},{"name":"fetch_url","description":"http request to external url"},{"name":"read_file","description":"read file by path"}]')
manifest = w("manifest.json", '[{"id":"d1","license":"MIT","commercial":true,"attribution":false,"source":"public"},{"id":"d2","license":"","commercial":false,"attribution":true,"source":""},{"id":"d3","license":"CC-BY-NC","commercial":false,"attribution":true,"source":"forum"}]')

SCRIPT = {
    "output-schema-guard": "schema_guard.py",
    "tool-call-guard": "tool_guard.py",
    "model-router": "model_router.py",
    "fact-check-guard": "fact_guard.py",
    "agent-loop-guard": "loop_guard.py",
    "bias-auditor": "bias_audit.py",
    "prompt-version-control": "prompt_vc.py",
    "api-resilience": "resilience_demo.py",
    "mcp-security-scan": "mcp_scan.py",
    "data-rights-guard": "rights_guard.py",
}

cases = [
    ("output-schema-guard", ["--schema", str(schema), "--text", good.read_text(encoding="utf-8")]),
    ("output-schema-guard", ["--schema", str(schema), "--text", bad.read_text(encoding="utf-8")]),
    ("tool-call-guard", ["--tool", "delete_file", "--args", '{"path":"/data"}']),
    ("tool-call-guard", ["--tool", "read_file", "--args", '{"path":"x"}']),
    ("model-router", ["--task", "把这段客服对话归类并抽情绪"]),
    ("model-router", ["--task", "设计分布式缓存架构并论证取舍"]),
    ("fact-check-guard", ["--claims", str(claims), "--sources", str(refs)]),
    ("agent-loop-guard", ["--trace", str(trace), "--max-steps", "10", "--repeat", "3"]),
    ("bias-auditor", ["--text", "男生更适合做技术，女生适合沟通。"]),
    ("prompt-version-control", ["--old", str(v1), "--new", str(v2), "--score", "0.82", "--registry", str(SCR / "reg.json")]),
    ("api-resilience", ["--fail-rate", "0.7", "--max-retry", "4"]),
    ("mcp-security-scan", ["--tools", str(tools)]),
    ("data-rights-guard", ["--manifest", str(manifest)]),
]

ok = 0
for slug, args in cases:
    r = subprocess.run([PY, str(BASE / slug / "scripts" / SCRIPT[slug]), *args],
                       capture_output=True, text=True, cwd=str(BASE), encoding="utf-8")
    rc = r.returncode
    if rc == 0 and r.stdout.strip():
        ok += 1
        print(f"PASS {slug}: {r.stdout.strip().splitlines()[0][:70]}")
    else:
        print(f"FAIL {slug} rc={rc}\n  OUT={r.stdout[-200:]}\n  ERR={r.stderr[-200:]}")
print(f"\n==== {ok}/{len(cases)} cases PASS ====")
