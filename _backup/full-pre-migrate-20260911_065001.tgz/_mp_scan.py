import subprocess, json, re, os, urllib.request

PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
VAULT = "C:/Users/Administrator/.ucvault_local/vault.py"
TOKEN_FILE = os.path.join(os.path.dirname(__file__), ".mp_token")

def get_secret(label):
    return subprocess.run([PY, VAULT, "get", label], capture_output=True, text=True).stdout.strip()

def get_token():
    raw = get_secret("wechat_mp")
    appid = re.search(r"wx[0-9a-fA-F]{16}", raw).group(0)
    secret = re.search(r"[0-9a-fA-F]{32}", raw).group(0)
    if os.path.exists(TOKEN_FILE):
        t = open(TOKEN_FILE).read().strip()
        try:
            with urllib.request.urlopen(f"https://api.weixin.qq.com/cgi-bin/getcallbackip?access_token={t}", timeout=15) as x:
                if json.loads(x.read().decode()).get("errcode", 0) == 0:
                    return t
        except Exception:
            pass
    with urllib.request.urlopen(f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={appid}&secret={secret}", timeout=30) as x:
        t = json.loads(x.read().decode())["access_token"]
    open(TOKEN_FILE, "w").write(t)
    return t

TOKEN = get_token()

def batchget(offset):
    url = f"https://api.weixin.qq.com/cgi-bin/draft/batchget?access_token={TOKEN}"
    body = json.dumps({"offset": offset, "count": 20, "no_content": 0}).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json; charset=utf-8"})
    with urllib.request.urlopen(req, timeout=60) as x:
        return json.loads(x.read().decode("utf-8"))

all_items = []
off = 0
while True:
    r = batchget(off)
    items = r.get("item", [])
    all_items.extend(items)
    if not items or len(all_items) >= r.get("total_count", 0):
        break
    off += len(items)
    if off >= 100:
        break

print(f"TOTAL drafts: {len(all_items)}")
rows = []
for it in all_items:
    ni = it.get("content", {}).get("news_item", [{}])
    art = ni[0] if ni else {}
    title = art.get("title", "")
    author = art.get("author", "")
    content = art.get("content", "")
    # garble = literal \uXXXX escape sequences present in stored text
    garbled = bool(re.search(r"\\u[0-9a-fA-F]{4}", title)) or bool(re.search(r"\\u[0-9a-fA-F]{4}", content[:500]))
    mine = ("SkillPie" in content or "agent-skills" in content or "LGD" in title
            or "通用技能" in title or "让 AI" in title or "context-engineering" in content
            or "ai-cost-cutter" in content or "prompt-injection" in content or "eu-ai-act" in content)
    rows.append({"media_id": it.get("media_id"), "title": title, "author": author,
                 "garbled": garbled, "mine": mine, "len": len(content)})

# sort: mine first, garbled flagged
for row in rows:
    tag = ("GARBLED" if row["garbled"] else "ok     ")
    mine_tag = "MINE" if row["mine"] else "    "
    print(f"[{tag}] [{mine_tag}] len={row['len']:<6} {row['title'][:40]}")
    print(f"         mid={row['media_id']}")

out = "C:/Users/Administrator/AppData/Local/Temp/mp_scan.json"
open(out, "w", encoding="utf-8").write(json.dumps(rows, ensure_ascii=False, indent=2))
print("\nsaved ->", out)
