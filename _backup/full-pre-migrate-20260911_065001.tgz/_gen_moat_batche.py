# -*- coding: utf-8 -*-
"""Batch E · 广谱爆款配套生成器（3 技能）：
  E1 ai-content-discloser   AI 内容披露生成器（有证·人人发 AI 内容都要标注）
  E2 agent-boarding-pass    智能体登机牌（三律便携证件·签发/验真一体）
  E3 prompt-leak-scanner    提示词泄漏扫描器（有门禁·发布前最后一道门）

生成纪律（Batch C/D 教训固化）：脚本主体为普通三引号原文，哨兵 __X__ 用 .replace 注入，
绝不 .format 生成代码。图标用 PIL 生成（LGD 藏青 #0B1F3A + 青绿 #14B8A6）。
"""
import json, os, shutil
from PIL import Image, ImageDraw

BASE = "D:/Workbuddy/05-工具/agent-skills"
NAVY = (11, 31, 58)
TEAL = (20, 184, 166)
WHITE = (255, 255, 255)
AMBER = (245, 166, 35)
S = 512

SKILLS = [
    {
        "slug": "ai-content-discloser",
        "script": "ai_content_discloser",
        "dn_zh": "AI 内容披露生成器",
        "dn_en": "AI Content Discloser",
        "func": "为 AI 参与（全生成/辅助/混合）的内容一键生成合规披露声明：显式声明（中/EN）+ 隐式元数据标注 + 平台贴法，依据中国《人工智能生成合成内容标识办法》与 EU AI Act 第 50 条口径。",
        "func_en": "One-click compliance disclosure for AI-involved content (full/assisted/mixed): explicit statement (CN/EN) + implicit metadata labels + platform tips, aligned with China's AI Content Labeling Measures and EU AI Act Art.50.",
        "pain": "发 AI 内容不知道怎么标、标什么：监管已要求显式+隐式标识，漏标有下架/处罚风险，手工写声明费时且口径不统一。",
        "pain_en": "People don't know how to label AI content: regulators require explicit + implicit labels; missing them risks takedowns, and hand-writing disclosures is slow and inconsistent.",
        "theory": "LGD-II 有证（披露 = 内容出处有证）· 域码 TH-LGD-002（广谱件·披露环）",
        "theory_en": "LGD-II evidenced (disclosure = provenance on record)",
    },
    {
        "slug": "agent-boarding-pass",
        "script": "agent_boarding_pass",
        "dn_zh": "智能体登机牌",
        "dn_en": "Agent Boarding Pass",
        "func": "给任何 AI 智能体签发一张可验证的『登机牌』：身份 + 证据哈希 + 权限白名单 + 有效期，SHA-256 防篡改；一条命令验真（指纹重算 + 过期校验）。可整张贴进 system prompt / 仓库 / 工单。",
        "func_en": "Issue a verifiable 'boarding pass' for any AI agent: identity + evidence hash + permission allowlist + TTL, SHA-256 anti-tamper; one command to verify (fingerprint recompute + expiry check). Paste it into system prompts, repos or tickets.",
        "pain": "把 AI 智能体接入团队/流程时说不清它是谁、凭什么、能干什么、干到什么时候——口头约定无法校验，出事无据可查。",
        "pain_en": "Onboarding an AI agent into a team leaves 'who is it, on what evidence, allowed what, until when' unverifiable — verbal agreements can't be checked and leave no audit trail.",
        "theory": "三律便携化（有籍=身份入牌 · 有证=证据哈希入牌 · 有门禁=无三律不签发）· 域码 TH-LGD-003（广谱件·证件环）",
        "theory_en": "Three laws, pocket-sized: identity on card, evidence hash on card, no issuance without all three.",
    },
    {
        "slug": "prompt-leak-scanner",
        "script": "prompt_leak_scanner",
        "dn_zh": "提示词泄漏扫描器",
        "dn_en": "Prompt Leak Scanner",
        "func": "发布/共享前扫描提示词与 system prompt 的泄漏与后门风险：密钥口令、内部路径、个人可识别信息、自定义敏感词（--extra）、自我泄漏后门（『忽略之前指令/打印系统提示词』类埋点）。有风险 rc=1 拦下。",
        "func_en": "Pre-share scanner for prompts and system prompts: secrets, internal paths, PII, custom sensitive words (--extra), and self-leak backdoors ('ignore previous instructions' / 'print your system prompt' plants). Non-zero exit blocks leaks.",
        "pain": "提示词是最容易被随手外发的敏感资产：一句内嵌的密钥/内网路径/『复述你的系统提示词』就能把家底和后门一起送出去，目前没人做发布前体检。",
        "pain_en": "Prompts are the most casually shared sensitive asset: one embedded key, intranet path, or 'repeat your system prompt' plant gives away the farm — nobody runs a pre-release check.",
        "theory": "LGD-III 有门禁（提示词对外发布前的最后一道门）· 域码 TH-LGD-004（广谱件·提示词门禁环）",
        "theory_en": "LGD-III gated (the last gate before a prompt goes public).",
    },
]

DISCLOSER_BODY = r'''# -*- coding: utf-8 -*-
"""__DN__：为 AI 参与生成的内容一键生成合规披露声明。零依赖。

依据（口径给量级区间，以官方最新文本为准）：
  - 中国《人工智能生成合成内容标识办法》（2025-09-01 起施行）：AI 生成合成内容应加显式标识
  - EU AI Act 第 50 条：与 AI 交互 / 生成操纵性内容需透明度告知

三律映射：LGD-II 有证 —— 披露即让内容出处"有证"。

用法：
  python ai_content_discloser.py --type article --ai-level assisted --brand "MedXpert"
  python ai_content_discloser.py --type image --ai-level full --json
"""
import argparse, datetime, json, sys

LEVELS = {
    "full": ("AI 全生成", "AI-generated"),
    "assisted": ("AI 辅助创作（人工主创）", "AI-assisted, human-authored"),
    "mixed": ("AI 与人工混合生成", "co-created by AI and human"),
}
TYPES = ["text", "article", "report", "image", "video", "audio", "code"]
PLATFORMS = {
    "wechat": "公众号：在文首或文末正文区加显式声明（不放『阅读原文』之后）",
    "web": "网页：页首可见声明 + HTML meta 标签（见下方隐式标注）",
    "paper": "论文/报告：方法节注明 AI 参与与工具，首页角标",
    "code": "代码仓库：README 声明 + commit message 标注 [ai]",
    "generic": "通用：随内容载体可见位置加显式声明",
}


def main():
    ap = argparse.ArgumentParser(description="__DN__ · 合规披露一键生成")
    ap.add_argument("--type", required=True, choices=TYPES, help="内容类型")
    ap.add_argument("--ai-level", required=True, choices=list(LEVELS), help="AI 参与度")
    ap.add_argument("--brand", default="", help="署名/品牌（可选）")
    ap.add_argument("--tool", default="", help="使用的 AI 工具名（可选，如 GLM/Claude）")
    ap.add_argument("--platform", default="generic", choices=list(PLATFORMS), help="发布渠道")
    ap.add_argument("--date", default=datetime.date.today().isoformat(), help="披露日期")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    zh_lvl, en_lvl = LEVELS[a.ai_level]
    who = f"（{a.brand}）" if a.brand else ""
    tool = f"，使用工具：{a.tool}" if a.tool else ""
    explicit_zh = (f"本文由 AI {zh_lvl} 产出{who}{tool}，"
                   f"已经人工审核校对。披露日期：{a.date}。依据《人工智能生成合成内容标识办法》"
                   f"与 EU AI Act 第 50 条进行标识；口径以官方最新文本为准。")
    explicit_en = (f"This content is {en_lvl}{(' by ' + a.brand) if a.brand else ''}"
                   f"{(', produced with ' + a.tool) if a.tool else ''}, and has been human-reviewed. "
                   f"Labeled per China's AI Content Labeling Measures and EU AI Act Art.50; "
                   f"latest official text prevails.")
    implicit = {
        "content_type": a.type,
        "ai_generated": a.ai_level == "full",
        "ai_involvement": a.ai_level,
        "tool": a.tool or None,
        "disclosure_date": a.date,
        "human_reviewed": True,
        "note": "隐式标识：写入文件元数据 / HTML meta / 图片 EXIF（字段名以平台规范为准）",
    }
    result = {
        "explicit_zh": explicit_zh,
        "explicit_en": explicit_en,
        "implicit_metadata": implicit,
        "platform_tip": PLATFORMS[a.platform],
        "basis": "《人工智能生成合成内容标识办法》(2025-09-01 施行)；EU AI Act Art.50。本工具为治理辅助，不构成法律意见。",
    }
    if a.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)
    print("=== 显式声明（中文）===")
    print(explicit_zh)
    print("\n=== Explicit statement (EN) ===")
    print(explicit_en)
    print("\n=== 隐式标注（元数据建议）===")
    print(json.dumps(implicit, ensure_ascii=False, indent=2))
    print("\n=== 平台贴法 ===")
    print(PLATFORMS[a.platform])
    print("\n依据：" + result["basis"])
    sys.exit(0)


if __name__ == "__main__":
    main()
'''

BOARDING_BODY = r'''# -*- coding: utf-8 -*-
"""__DN__：给任何 AI 智能体签发一张可验证的『登机牌』。零依赖。

一张登机牌 = 身份（有籍）+ 证据哈希（有证）+ 权限白名单/有效期（有门禁）。
签发铁律：三律证据缺任一律 → 拒绝签发（rc=1）。
可整张贴进 system prompt / 仓库 / 工单，接收方一条命令验真。

用法：
  签发：python agent_boarding_pass.py --agent research-bot \
          --evidence l1-registered=passport.json l2-evidence=chain.jsonl l3-gate=gate.json \
          --allow search summarize write_draft --ttl 24 --out pass.json
  验真：python agent_boarding_pass.py --verify pass.json
"""
import argparse, datetime, hashlib, json, pathlib, sys

LAW_PREFIX = ("l1-", "l2-", "l3-")


def sha256_of(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def load_evidence_ref(p: str) -> str:
    q = p[1:] if p.startswith("@") else p
    if pathlib.Path(q).is_file():
        return sha256_of(pathlib.Path(q).read_text(encoding="utf-8"))
    return sha256_of(p)


def issue(a):
    ev, laws_hit = {}, set()
    for item in a.evidence:
        if "=" not in item:
            print(f"证据格式错误（应为 key=value）：{item}", file=sys.stderr)
            sys.exit(2)
        k, v = item.split("=", 1)
        if not k.startswith(LAW_PREFIX):
            print(f"证据键须以 l1-/l2-/l3- 开头：{k}", file=sys.stderr)
            sys.exit(2)
        ev[k] = load_evidence_ref(v)
        laws_hit.add(k[:3])
    missing = [l for l in ("l1-", "l2-", "l3-") if l not in laws_hit]
    if missing:
        msg = "⛔ 拒绝签发：三律证据缺失（" + "、".join(missing) + "）"
        print(json.dumps({"issued": False, "agent": a.agent, "missing": missing,
                          "note": msg}, ensure_ascii=False, indent=2) if a.json else msg)
        sys.exit(1)

    now = datetime.datetime.now()
    expires = (now + datetime.timedelta(hours=a.ttl)).isoformat(timespec="seconds")
    card = {
        "pass_type": "lgd-agent-boarding-pass",
        "agent": a.agent,
        "issued_at": now.isoformat(timespec="seconds"),
        "expires_at": expires,
        "allow": a.allow or [],
        "evidence_sha256": ev,
    }
    card["fingerprint"] = sha256_of(json.dumps(card, ensure_ascii=False, sort_keys=True))
    if a.out:
        outp = pathlib.Path(a.out)
        outp.parent.mkdir(parents=True, exist_ok=True)
        outp.write_text(json.dumps(card, ensure_ascii=False, indent=2), encoding="utf-8")
    if a.json:
        print(json.dumps({"issued": True, "card": card, "out": a.out},
                         ensure_ascii=False, indent=2))
    else:
        print("✅ 已签发登机牌：" + a.agent)
        print("  有效期至：" + expires + f"（ttl={a.ttl}h）")
        print("  允许动作：" + (", ".join(card["allow"]) or "（未列，视为只读）"))
        print("  证据：" + str(len(ev)) + " 条（三律齐备）  指纹：" + card["fingerprint"][:16] + "…")
        if a.out:
            print("  登机牌文件：" + a.out)
    sys.exit(0)


def verify(a):
    p = a.verify
    q = p[1:] if p.startswith("@") else p
    try:
        if pathlib.Path(q).is_file():
            raw = pathlib.Path(q).read_text(encoding="utf-8")
        else:
            raw = p
        card = json.loads(raw)
    except (json.JSONDecodeError, OSError) as e:
        print(f"登机牌不可读/非 JSON：{e}", file=sys.stderr)
        sys.exit(2)

    checks = []
    miss = [k for k in ("pass_type", "agent", "issued_at", "expires_at",
                        "allow", "evidence_sha256", "fingerprint") if k not in card]
    checks.append(("结构完整", not miss, "缺失字段: " + ",".join(miss) if miss else "字段齐全"))

    body = {k: card[k] for k in ("pass_type", "agent", "issued_at", "expires_at",
                                 "allow", "evidence_sha256") if k in card}
    checks.append(("指纹防篡改",
                   bool(card.get("fingerprint")) and sha256_of(json.dumps(body, ensure_ascii=False, sort_keys=True)) == card.get("fingerprint"),
                   "重算一致" if checks and sha256_of(json.dumps(body, ensure_ascii=False, sort_keys=True)) == card.get("fingerprint") else "不一致（已被篡改或非本体系签发）"))

    try:
        expired = datetime.datetime.now() > datetime.datetime.fromisoformat(card.get("expires_at", "2000-01-01T00:00:00"))
    except ValueError:
        expired = True
    checks.append(("未过期", not expired, "有效期至 " + str(card.get("expires_at"))))

    ok = all(c[1] for c in checks)
    if a.json:
        print(json.dumps({"verified": ok, "agent": card.get("agent"),
                          "allow": card.get("allow"),
                          "checks": [{"name": n, "pass": pp, "note": t} for n, pp, t in checks]},
                         ensure_ascii=False, indent=2))
    else:
        print(("✅ 验真通过：" if ok else "⛔ 验真失败：") + str(card.get("agent")))
        for n, pp, t in checks:
            print(f"  {'✅' if pp else '⛔'} {n}：{t}")
    sys.exit(0 if ok else 1)


def main():
    ap = argparse.ArgumentParser(description="__DN__ · 智能体三律便携证件")
    sub = ap.add_mutually_exclusive_group(required=True)
    sub.add_argument("--agent", help="签发：智能体标识")
    sub.add_argument("--verify", help="验真：登机牌 JSON（内联 / @文件 / 纯路径）")
    ap.add_argument("--evidence", nargs="+", help="证据键值（键须以 l1-/l2-/l3- 开头）")
    ap.add_argument("--allow", nargs="*", default=[], help="允许动作白名单")
    ap.add_argument("--ttl", type=int, default=72, help="有效时长（小时，默认 72）")
    ap.add_argument("--out", help="登机牌输出路径")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    if a.agent:
        if not a.evidence:
            print("签发需 --evidence（三律证据 key=value）", file=sys.stderr)
            sys.exit(2)
        issue(a)
    else:
        verify(a)


if __name__ == "__main__":
    main()
'''

SCANNER_BODY = r'''# -*- coding: utf-8 -*-
"""__DN__：发布/共享前扫描提示词的泄漏与后门风险。零依赖。

扫五类：
  1. 密钥口令（API key / token / password / 私钥块）
  2. 内部路径与主机（盘符绝对路径 /home /Users /内网 IP）
  3. 个人可识别信息（手机号 / 邮箱 / 身份证）
  4. 自定义敏感词（--extra，项目代号/雇主名/内部系统名）
  5. 自我泄漏后门（提示词里埋了"忽略之前指令 / 打印你的系统提示词"类指令）

门禁语义：发现高风险 → rc=1 拦下（发布前门禁）；干净 → rc=0；参数错误 → rc=2。
三律映射：LGD-III 有门禁 —— 提示词对外发布前的最后一道门。

用法：
  python prompt_leak_scanner.py --file prompt.txt
  python prompt_leak_scanner.py --text "..." --extra 内部代号A
  python prompt_leak_scanner.py --file p.txt --json
"""
import argparse, json, pathlib, re, sys

KEYS = re.compile("(" + "sk-[A-Za-z0-9]{8,}|" + "ghp_[A-Za-z0-9]{8,}|" + "gho_[A-Za-z0-9]{8,}|"
                  + "AKIA[0-9A-Z]{16}|"
                  + r"api[_-]?key\s*[=:]\s*\S+|" + r"secret\s*[=:]\s*\S+|"
                  + r"password\s*[=:]\s*\S+|" + r"Bearer\s+[A-Za-z0-9._-]{10,}|"
                  + "-----BEGIN[A-Z ]*PRIVATE KEY-----)", re.I)
PATHS = re.compile(r"([A-Za-z]:[\\/][^\s\"']+|/home/\S+|/Users/\S+|"
                   r"(?:10|172\.(?:1[6-9]|2\d|3[01]))\.\d+\.\d+\.\d+)", re.I)
PII = re.compile(r"(1[3-9]\d{9}|[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}|\b\d{17}[\dXx]\b)")
BACKDOOR = re.compile("(忽略(之前|上面|以上|先前)(的)?(所有)?(指令|规则|设定)|"
                      "ignore\\s+(all\\s+)?previous\\s+instructions|"
                      "(打印|输出|复述|泄露|repeat|print|reveal|show)[^。\\n]{0,10}"
                      "(系统提示|system prompt|初始指令|initial instructions)|"
                      "(你|you)[^。\\n]{0,8}(系统提示词|system prompt)[^。\\n]{0,12}(是什么|什么|reveal))", re.I)

SEVERITY = {"密钥口令": "HIGH", "内部路径/主机": "HIGH", "自我泄漏后门": "HIGH",
            "个人可识别信息": "MED", "自定义敏感词": "HIGH"}


def scan(text, extra):
    hits = []
    for name, pat in (("密钥口令", KEYS), ("内部路径/主机", PATHS),
                      ("个人可识别信息", PII), ("自我泄漏后门", BACKDOOR)):
        for m in pat.finditer(text):
            frag = m.group(0)
            shown = frag[:10] + "…" if len(frag) > 13 else frag
            hits.append({"category": name, "severity": SEVERITY[name],
                         "pos": m.start(), "sample": shown})
    for w in extra or []:
        for m in re.finditer(re.escape(w), text):
            hits.append({"category": "自定义敏感词", "severity": SEVERITY["自定义敏感词"],
                         "pos": m.start(), "sample": w})
    return hits


def main():
    ap = argparse.ArgumentParser(description="__DN__ · 提示词发布前门禁")
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--file", help="提示词文件路径")
    src.add_argument("--text", help="提示词文本（内联，或 @文件/纯路径）")
    ap.add_argument("--extra", nargs="*", default=[], help="自定义敏感词（项目代号/内部系统名）")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    try:
        if a.file:
            text = pathlib.Path(a.file).read_text(encoding="utf-8")
        else:
            q = a.text[1:] if a.text.startswith("@") else a.text
            text = (pathlib.Path(q).read_text(encoding="utf-8")
                    if pathlib.Path(q).is_file() else q)
    except OSError as e:
        print(f"输入不可读：{e}", file=sys.stderr)
        sys.exit(2)

    hits = scan(text, a.extra)
    high = [h for h in hits if h["severity"] == "HIGH"]
    blocked = bool(high)
    if a.json:
        print(json.dumps({"clean": not hits, "blocked": blocked,
                          "findings": hits,
                          "note": "存在高风险项，已按门禁拦截（rc=1）" if blocked
                          else ("存在中风险项，建议复核" if hits else "未发现泄漏/后门信号")},
                         ensure_ascii=False, indent=2))
    else:
        if not hits:
            print("✅ 未发现泄漏/后门信号，可发布（仍建议按发布闸门走人工复核）")
        else:
            print(("⛔ 高风险，已拦截（rc=1）：" if blocked else "⚠ 中风险，建议复核：")
                  + f"{len(hits)} 项")
            for h in hits:
                print(f"  [{h['severity']}] {h['category']} @pos{h['pos']}  {h['sample']}")
    sys.exit(1 if blocked else 0)


if __name__ == "__main__":
    main()
'''


def gen_script(d):
    bodies = {"ai-content-discloser": DISCLOSER_BODY,
              "agent-boarding-pass": BOARDING_BODY,
              "prompt-leak-scanner": SCANNER_BODY}
    return bodies[d["slug"]].replace("__DN__", d["dn_zh"])


SKILLMD_TMPL = '''---
name: {slug}
description: {slug} — {func}
slug: {slug}
version: 1.0.0
display_name: {dn_zh}
display_name_en: {dn_en}
agent_created: true
author: Steven Zhao (MedXpert × SynomosAI)
license: MIT
category: AI 治理
platforms: [claude-code, codebuddy, workbuddy, openai-agents]
---

# {dn_zh}（{dn_en}）

LGD 广谱爆款配套件：把"有籍·有证·有门禁"做成人人天天用得上的工具。

## 解决什么痛点

{pain}

## 功能

{func}

## 用法

见 `scripts/` 下脚本 `--help`。零依赖（stdlib only），Windows/Linux/macOS 均可运行。

## 对应理论

- {theory}

## 免责声明

本工具为治理辅助框架，口径以监管官方最新文本为准，不构成法律意见。

---
© MedXpert × SynomosAI · LGD-Powered
'''

README_TMPL = '''# {dn_zh} / {dn_en}

{func_en}

**Pain point**: {pain_en}

{theory_en}

Part of the **LGD moat** (凡自治之物: registered / evidenced / gated).

Zero-dependency (stdlib only). See `scripts/` for CLI usage (`--help`).

© MedXpert × SynomosAI · LGD-Powered
'''


def icon_discloser():
    img = Image.new("RGB", (S, S), NAVY)
    d = ImageDraw.Draw(img)
    d.ellipse([28, 28, S - 28, S - 28], outline=TEAL, width=10)
    # 文档 + 眼睛（披露 = 让出处可见）
    d.rounded_rectangle([150, 100, 362, 412], radius=24, outline=WHITE, width=12)
    for y in (170, 220, 270):
        d.line([(190, y), (322, y)], fill=TEAL, width=10)
    d.ellipse([196, 300, 316, 372], outline=WHITE, width=10)
    d.ellipse([236, 322, 276, 352], fill=TEAL)
    return img


def icon_boarding():
    img = Image.new("RGB", (S, S), NAVY)
    d = ImageDraw.Draw(img)
    d.ellipse([28, 28, S - 28, S - 28], outline=TEAL, width=10)
    # 登机牌：带缺口票根 + 虚线 + 对勾
    d.rounded_rectangle([96, 176, 416, 336], radius=20, fill=WHITE)
    d.ellipse([96, 236, 136, 276], fill=NAVY)
    d.ellipse([376, 236, 416, 276], fill=NAVY)
    for x in range(300, 392, 18):
        d.line([(x, 216), (x, 296)], fill=TEAL, width=8)
    d.line([(140, 236), (230, 276), (256, 232)], fill=TEAL, width=14)
    d.line([(140, 292), (260, 292)], fill=NAVY, width=10)
    return img


def icon_scanner():
    img = Image.new("RGB", (S, S), NAVY)
    d = ImageDraw.Draw(img)
    d.ellipse([28, 28, S - 28, S - 28], outline=TEAL, width=10)
    # 放大镜扫文档 + 警示点
    d.rounded_rectangle([130, 130, 300, 350], radius=18, outline=WHITE, width=12)
    for y in (190, 240):
        d.line([(170, y), (262, y)], fill=TEAL, width=10)
    d.ellipse([250, 220, 370, 340], outline=TEAL, width=16)
    d.line([(352, 322), (414, 384)], fill=TEAL, width=22)
    d.ellipse([286, 256, 334, 304], fill=AMBER)
    return img


def main():
    icons = {"ai-content-discloser": icon_discloser,
             "agent-boarding-pass": icon_boarding,
             "prompt-leak-scanner": icon_scanner}
    for d in SKILLS:
        slug = d["slug"]
        root = os.path.join(BASE, slug)
        os.makedirs(os.path.join(root, "scripts"), exist_ok=True)
        (open(os.path.join(root, "scripts", d["script"] + ".py"), "w", encoding="utf-8")
         .write(gen_script(d)))
        (open(os.path.join(root, "SKILL.md"), "w", encoding="utf-8")
         .write(SKILLMD_TMPL.format(**d)))
        (open(os.path.join(root, "README.md"), "w", encoding="utf-8")
         .write(README_TMPL.format(**d)))
        icons[slug]().save(os.path.join(root, "icon.png"))
        shutil.copy(os.path.join(BASE, "lgd-fin-guard", "lgd-powered.png"),
                    os.path.join(root, "lgd-powered.png"))
        print("built", slug)
    print("Batch E done: 3 skills")


if __name__ == "__main__":
    main()
