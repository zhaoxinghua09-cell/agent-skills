#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Batch C 深工具功能冒烟：每个工具测 合规PASS(rc0) + 违规FAIL(rc1)。"""
import subprocess, sys
PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
BASE = "D:/Workbuddy/05-工具/agent-skills"

# (path, pass_args, pass_rc, fail_args, fail_rc, label)
CASES = [
 ("fin-reg-calc/scripts/fin_reg_calc.py",
   ["--suitability","3","2"], 0,
   ["--suitability","3","5"], 1, "适当性匹配"),
 ("fin-reg-calc/scripts/fin_reg_calc.py",
   ["--threshold","100"], 0,
   ["--threshold","60000"], 1, "大额阈值"),
 ("aml-sentinel/scripts/aml_sentinel.py",
   ['--tx','{"amount":100,"counterparty_kyc":true}'], 0,
   ['--tx','{"amount":80000,"counterparty_kyc":false,"cross_border":true}'], 1, "AML哨兵"),
 ("evidence-chain-check/scripts/evidence_chain_check.py",
   ['--chain','[{"time":1,"subject":"A","hash":"h1","prev":null},{"time":2,"subject":"A","hash":"h2","prev":"h1"}]'], 0,
   ['--chain','[{"time":1,"subject":"A","hash":"h1","prev":null},{"time":2,"subject":"A","hash":"h2","prev":"WRONG"}]'], 1, "证据链"),
 ("gov-disclosure-check/scripts/gov_disclosure_check.py",
   ['--text','依据XX条例 责任部门XX 时限XX 复议诉讼 数据来源XX'], 0,
   ['--text','hello'], 1, "披露校验"),
 ("travel-rule-check/scripts/travel_rule_check.py",
   ['--tx','{"originator":{"name":"a","account":"x","geo":"CN"},"beneficiary":{"name":"b","account":"y","geo":"CN"},"amount":50}'], 0,
   ['--tx','{"originator":{"name":"a"},"beneficiary":{},"amount":5000}'], 1, "旅行规则"),
]

bad = 0
for path, pa, prc, fa, frc, label in CASES:
    r1 = subprocess.run([PY, BASE+"/"+path]+pa, capture_output=True, text=True)
    ok1 = (r1.returncode == prc)
    r2 = subprocess.run([PY, BASE+"/"+path]+fa, capture_output=True, text=True)
    ok2 = (r2.returncode == frc)
    mark = "OK" if (ok1 and ok2) else "FAIL"
    if not (ok1 and ok2): bad += 1
    print(f"[{mark}] {path} :: {label}")
    print(f"    PASS rc={r1.returncode}(期望{prc}) {'✅' if ok1 else '❌'} | FAIL rc={r2.returncode}(期望{frc}) {'✅' if ok2 else '❌'}")
    if not ok1: print("    PASS out:", r1.stdout.strip()[:100], r1.stderr.strip()[:100])
    if not ok2: print("    FAIL out:", r2.stdout.strip()[:100], r2.stderr.strip()[:100])

print("\n=== 汇总:", "ALL PASS ✅" if bad==0 else f"{bad} 项异常 ❌", "===")
sys.exit(1 if bad else 0)
