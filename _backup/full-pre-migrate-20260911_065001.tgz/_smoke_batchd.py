# -*- coding: utf-8 -*-
"""Batch D 闭环冒烟：签发→验真→防篡改→拒发→坏输入。"""
import json, subprocess, sys, tempfile
from pathlib import Path

BASE = Path(__file__).resolve().parent
PY = sys.executable
TMP = Path(tempfile.mkdtemp(prefix="batchd_smoke_"))
results = []

def run(script, args, name, expect_rc=None):
    p = subprocess.run([PY, str(script)] + args, capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    ok = (expect_rc is None) or (p.returncode == expect_rc)
    results.append((name, ok, f"rc={p.returncode}" + ("" if ok else f" 期望{expect_rc} {p.stderr[-100:]}")))
    return p

issuer = BASE / "lgd-badge-issuer/scripts/badge_issuer.py"
verifier = BASE / "lgd-badge-verify/scripts/badge_verify.py"
reg = str(TMP / "reg.json")

# 1. 拒发：只有 l1 证据
p = run(issuer, ["--holder", "bad-agent", "--evidence", "l1-a=x", "--registry", reg, "--json"],
        "D1 拒发(缺l2/l3)", expect_rc=1)
check = json.loads(p.stdout)
results.append(("D1 拒发写台账", check.get("issued") is False, "issued=False"))

# 2. 坏输入：证据无等号
run(issuer, ["--holder", "x", "--evidence", "noequals", "--registry", reg],
    "D1 坏输入 rc=2", expect_rc=2)

# 3. 正式签发：三律齐
p = run(issuer, ["--holder", "good-agent", "--evidence",
                 "l1-registered=passport.json", "l2-chain=evidence.jsonl", "l3-gate=@SKILL.md",
                 "--registry", reg, "--out", str(TMP / "cert.json")],
        "D1 签发(三律齐)", expect_rc=0)
cert = json.loads((TMP / "cert.json").read_text(encoding="utf-8"))
results.append(("D1 证书字段齐全", all(k in cert for k in
                ("badge", "serial", "holder", "issuer", "issued_at", "evidence_sha256", "fingerprint")),
                "fields ok"))
results.append(("D1 台账登记", json.loads(Path(reg).read_text(encoding="utf-8"))["issued"][0]["serial"] == 1, "serial=1"))

# 4. 验真：真证书 + 台账
run(verifier, ["--cert", str(TMP / "cert.json"), "--registry", reg, "--json"],
    "D2 验真通过", expect_rc=0)

# 5. 防篡改：改 holder 后指纹不匹配
tampered = dict(cert); tampered["holder"] = "evil-agent"
tp = TMP / "tampered.json"; tp.write_text(json.dumps(tampered, ensure_ascii=False), encoding="utf-8")
run(verifier, ["--cert", str(tp), "--registry", reg], "D2 防篡改拦截", expect_rc=1)

# 6. 台账对账：未签发的 serial
forged = dict(cert); forged["serial"] = 99
# 重签指纹使其结构自洽但台账无此号
canon = json.dumps({k: forged[k] for k in ("badge", "serial", "holder", "issuer", "issued_at", "evidence_sha256")},
                   ensure_ascii=False, sort_keys=True)
import hashlib
forged["fingerprint"] = hashlib.sha256(canon.encode("utf-8")).hexdigest()
fp = TMP / "forged.json"; fp.write_text(json.dumps(forged, ensure_ascii=False), encoding="utf-8")
run(verifier, ["--cert", str(fp), "--registry", reg], "D2 伪造serial拦截", expect_rc=1)

# 7. 坏 JSON
run(verifier, ["--cert", "not-json{{{"], "D2 坏JSON rc=2", expect_rc=2)

print("=" * 60)
fails = [r for r in results if not r[1]]
for name, ok, note in results:
    print(f"{'PASS' if ok else 'FAIL'}  {name:<26} {note}")
print("=" * 60)
print(f"总计 {len(results)}  通过 {len(results)-len(fails)}  失败 {len(fails)}")
sys.exit(1 if fails else 0)
