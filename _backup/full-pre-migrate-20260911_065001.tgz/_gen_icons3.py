# -*- coding: utf-8 -*-
"""生成 10 个痛点型技能的 512 图标（LGD 视觉系统 v2：藏青底 + 青绿强调）。"""
import pathlib
from PIL import Image, ImageDraw, ImageFont

OUT = pathlib.Path("D:/Workbuddy/05-工具/agent-skills")
NAVY = (11, 31, 58)        # #0B1F3A
TEAL = (20, 184, 166)      # #14B8A6
INK = (235, 240, 248)
RED = (220, 80, 80)
FONT = "C:/Windows/Fonts/msyh.ttc"

def font(sz):
    try:
        return ImageFont.truetype(FONT, sz)
    except Exception:
        return ImageFont.load_default()

def base():
    im = Image.new("RGBA", (512, 512), NAVY)
    d = ImageDraw.Draw(im)
    d.ellipse([18, 18, 494, 494], outline=TEAL, width=6)
    return im, d

def save(im, name):
    p = OUT / name / "icon.png"
    p.parent.mkdir(parents=True, exist_ok=True)
    im.convert("RGB").save(p, "PNG")
    print("saved", p)

def glyph(im, d, ch, accent=TEAL):
    d.text((256, 256), ch, fill=accent, font=font(200), anchor="mm")

# 1 output-schema-guard: 花括号 + 勾
im, d = base()
d.text((256, 256), "{ }", fill=TEAL, font=font(120), anchor="mm")
d.line([(200, 330), (240, 370)], fill=INK, width=10)
d.line([(240, 370), (315, 280)], fill=INK, width=10)
save(im, "output-schema-guard")

# 2 tool-call-guard: 扳手 + 闸门
im, d = base()
d.text((256, 240), "具", fill=TEAL, font=font(170), anchor="mm")
d.rectangle([150, 330, 362, 372], outline=RED, width=6)
save(im, "tool-call-guard")

# 3 model-router: 路 / 分叉
im, d = base()
d.text((256, 240), "路", fill=TEAL, font=font(170), anchor="mm")
for x in (190, 256, 322):
    d.line([(256, 290), (x, 380)], fill=INK, width=5)
save(im, "model-router")

# 4 fact-check-guard: 真 + 放大镜
im, d = base()
d.text((256, 240), "真", fill=TEAL, font=font(170), anchor="mm")
d.ellipse([300, 300, 380, 380], outline=INK, width=8)
d.line([(300, 300), (300, 300)], fill=INK, width=1)
save(im, "fact-check-guard")

# 5 agent-loop-guard: 环 + 斜杠
im, d = base()
d.ellipse([150, 200, 362, 412], outline=TEAL, width=10)
d.line([(150, 200), (362, 412)], fill=RED, width=14)
save(im, "agent-loop-guard")

# 6 bias-auditor: 偏 + 天平
im, d = base()
d.text((256, 240), "偏", fill=TEAL, font=font(170), anchor="mm")
d.line([(170, 360), (342, 360)], fill=INK, width=6)
d.ellipse([150, 340, 210, 400], outline=INK, width=5)
d.ellipse([302, 340, 362, 400], outline=INK, width=5)
save(im, "bias-auditor")

# 7 prompt-version-control: 版 + 时间轴
im, d = base()
d.text((256, 230), "版", fill=TEAL, font=font(170), anchor="mm")
d.line([(150, 360), (362, 360)], fill=INK, width=6)
for x in (180, 256, 332):
    d.ellipse([x-10, 350, x+10, 370], outline=INK, width=4)
save(im, "prompt-version-control")

# 8 api-resilience: 韧 + 盾
im, d = base()
d.text((256, 230), "韧", fill=TEAL, font=font(170), anchor="mm")
d.polygon([(256, 320), (200, 350), (312, 350)], outline=INK, width=6)
save(im, "api-resilience")

# 9 mcp-security-scan: M + 盾
im, d = base()
d.text((256, 230), "M", fill=TEAL, font=font(170), anchor="mm")
d.polygon([(150, 320), (362, 320), (362, 360), (150, 360)], outline=INK, width=5)
save(im, "mcp-security-scan")

# 10 data-rights-guard: 权 + 盾
im, d = base()
d.text((256, 230), "权", fill=TEAL, font=font(170), anchor="mm")
d.polygon([(256, 320), (210, 350), (302, 350)], outline=INK, width=6)
save(im, "data-rights-guard")

print("done 10 icons")
