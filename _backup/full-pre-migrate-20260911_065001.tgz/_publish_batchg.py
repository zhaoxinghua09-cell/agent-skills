# -*- coding: utf-8 -*-
"""Batch G 行业爆款十连发：10 个技能 → SkillPie + GitHub（跳 Gitee/AtomGit）。
密钥全部经 vault.py 子进程获取，绝不进对话/打印/URL。
"""
import base64, json, pathlib, subprocess, urllib.request, urllib.error, re, time

BASE = pathlib.Path("D:/Workbuddy/05-工具/agent-skills")
VAULT_PY = "C:/Users/Administrator/.ucvault_local/vault.py"
PY = "C:/Users/Administrator/.workbuddy/binaries/python/versions/3.13.12/python.exe"
NODE = "C:/Users/Administrator/.workbuddy/binaries/node/versions/node24/node.exe"
SKILLPIE_CLI = "C:/Users/Administrator/.workbuddy/skills/skillpie/scripts/cli.js"

SLUGS = ["loan-rate-disclosure", "kyc-checklist-gen", "invoice-risk-scan", "fund-fee-calc", "wallet-address-check", "token-disclosure-check", "contract-interact-checklist", "contract-clause-check", "health-claim-guard", "data-export-check"]


def vault_get(label):
    r = subprocess.run([PY, VAULT_PY, "get", label], capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"vault {label} failed: {r.stderr[:160]}")
    return r.stdout.strip()


def gh_files(slug):
    files = ["SKILL.md", "README.md", "icon.png", "lgd-powered.png"]
    sc = list((BASE / slug / "scripts").glob("*.py"))
    files += [f"scripts/{p.name}" for p in sc]
    return files


def publish_skillpie():
    print("\n===== SkillPie =====")
    ok = 0
    for slug in SLUGS:
        sd = BASE / slug
        t = (sd / "SKILL.md").read_text(encoding="utf-8")
        m = re.search(r'display_name:\s*"?([^"\n]+)', t)
        title = (m.group(1).strip() if m else slug)
        try:
            r = subprocess.run([NODE, SKILLPIE_CLI, "submit", str(sd), "--title", title],
                               cwd=str(sd.parent), capture_output=True, text=True,
                               encoding="utf-8", errors="replace", timeout=180)
            out = (r.stdout or "") + (r.stderr or "")
        except subprocess.TimeoutExpired:
            out = "TIMEOUT"
        good = ("发布成功" in out) or ("成功" in out and "skillpie" in out.lower()) or ("submitted" in out.lower())
        print(f"  [{'OK' if good else 'FAIL'}] {slug}  {out[-140:].strip()}")
        ok += good
        time.sleep(2)
    return ok


def make_api(base_url, owner, repo, token, head_factory):
    HEAD = head_factory(token)

    def call(method, path, data=None):
        url = f"{base_url}/repos/{owner}/{repo}/contents/{path}"
        req = urllib.request.Request(url, data=(json.dumps(data).encode() if data else None),
                                     headers=HEAD, method=method)
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                return resp.status, json.loads(resp.read().decode() or "{}")
        except urllib.error.HTTPError as e:
            return e.code, {"error": e.read().decode(errors="replace")[:240]}
    return call


def push_repo(name, base_url, owner, repo, token, head_factory):
    print(f"\n===== {name} ({owner}/{repo}) =====")
    api = make_api(base_url, owner, repo, token, head_factory)
    cnt = 0
    for slug in SLUGS:
        for f in gh_files(slug):
            local = BASE / slug / f
            gh = f"skills/{slug}/{f}"
            st0, cur = api("GET", gh)
            sha = cur.get("sha") if isinstance(cur, dict) else None
            content = base64.b64encode(local.read_bytes()).decode()
            data = {"message": f"add {slug}: LGD broad-appeal companion skill (P-051)", "content": content}
            if sha:
                data["sha"] = sha
            st, resp = api("PUT", gh, data)
            good = st in (200, 201)
            cnt += good
            print(f"  [{'OK' if good else 'FAIL'}] {st} {gh}")
    # 根 README
    local = BASE / "README.md"
    st0, cur = api("GET", "README.md")
    sha = cur.get("sha") if isinstance(cur, dict) else None
    content = base64.b64encode(local.read_bytes()).decode()
    data = {"message": "update README index: add Batch G industry tools (P-051) (P-051)", "content": content}
    if sha:
        data["sha"] = sha
    st, resp = api("PUT", "README.md", data)
    cnt += (st in (200, 201))
    print(f"  [{'OK' if st in (200,201) else 'FAIL'}] {st} README.md")
    return cnt


def main():
    try:
        gh_tok = vault_get("github_api_key")
        gh = push_repo("GitHub", "https://api.github.com", "zhaoxinghua09-cell", "agent-skills",
                       gh_tok, lambda tk: {"Authorization": f"Bearer {tk}",
                                           "Accept": "application/vnd.github+json",
                                           "User-Agent": "moat-push", "X-GitHub-Api-Version": "2022-11-28"})
        print(f"\nGitHub 推送文件数：{gh}")
    except Exception as e:
        print("GitHub 发布失败：", e)
        gh = 0
    sp = publish_skillpie()
    print(f"\n结果：GitHub {gh} 文件 OK；SkillPie 成功 {sp}/{len(SLUGS)}")
    print("Gitee/AtomGit 跳过（Gitee token 待核查 / AtomGit token 待轮换，见总账）")


if __name__ == "__main__":
    main()
